// Copies the game's web files into www/, which Capacitor packages into the Android app.
const fs = require('fs'), path = require('path');
const out = path.join(__dirname, 'www');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const f of ['index.html', 'style.css', 'fonts.css', 'core.js', 'art.js', 'game.js']) fs.copyFileSync(path.join(__dirname, f), path.join(out, f));
fs.cpSync(path.join(__dirname, 'fonts'), path.join(out, 'fonts'), { recursive: true });
console.log('www/ ready:', fs.readdirSync(out).join(', '));
