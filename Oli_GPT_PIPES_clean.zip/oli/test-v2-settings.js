// Oli v2 - settings panel + whole map open (real touch, phone size)
const { chromium } = require('/tmp/legacy-pw.js');
const assert = require('assert');
const URL = process.argv[3] || 'file:///home/claude/oli/v2.html', OUT = process.argv[2] || '/tmp/oli-shots'; require('fs').mkdirSync(OUT, { recursive: true });
const log = m => console.log('ok   ' + m);
(async () => {
  const browser = await chromium.launch(), errors = [];
  const ctx = await browser.newContext({ viewport: { width: 412, height: 866 }, deviceScaleFactor: 2.625, hasTouch: true, isMobile: true }), page = await ctx.newPage();
  page.on('pageerror', e => errors.push('pageerror: ' + e.message)); page.on('console', m => { if (m.type() === 'error' && !/fonts\.g|net::ERR/.test(m.text())) errors.push('console: ' + m.text()); });
  // an OLD save with locked regions: the map must still open completely
  await page.goto(URL); await page.waitForTimeout(1200);
  await page.evaluate(() => { const g = window.__v2.game; g.s.regions.forEach((r, i) => r.unlocked = i === 0); window.__v2.save(); }); await page.reload(); await page.waitForTimeout(1500);
  const G = fn => page.evaluate(fn), wait = ms => page.waitForTimeout(ms);
  const reg = await G(() => window.__v2.game.s.regions.map(r => r.unlocked)); assert(reg.every(Boolean), JSON.stringify(reg)); log('map: every region is open (' + reg.length + ' regions), also when the save had locked ones');
  const locked = await G(() => { const v = window.__v2, g = v.game, L = v.view.scene.ground; let n = 0; for (let y = 0; y < 88; y++) for (let x = 0; x < 140; x++) if (L.getTileAt(x, y).index === 7) n++; return n; }); assert.strictEqual(locked, 0); log('map: no tile is drawn as locked');
  // the bar has room for 4 buttons
  const bar = await G(() => [...document.querySelectorAll('#bar button')].map(b => { const r = b.getBoundingClientRect(); return [Math.round(r.width), b.scrollWidth <= b.clientWidth + 1]; })); assert(bar.every(b => b[0] >= 60 && b[1]), JSON.stringify(bar)); log('bar: 4 buttons fit (' + bar.map(b => b[0]).join(', ') + ' px wide)');
  // open settings
  await page.tap('#b-settings'); await wait(200); assert(await page.locator('#settings').isVisible()); await page.screenshot({ path: `${OUT}/settings.png` }); log('settings opens');
  // speed: pause stops the simulation, 3x runs it 3x
  await page.tap('#st-speed [data-s="0"]'); await wait(100); const t0 = await G(() => window.__v2.game.s.time); await wait(600); const t1 = await G(() => window.__v2.game.s.time); assert(Math.abs(t1 - t0) < .05, 'paused ' + (t1 - t0)); log('speed: pause freezes the game time');
  await page.tap('#st-speed [data-s="1"]'); const a0 = await G(() => [performance.now(), window.__v2.game.s.time]); await wait(1000); const a1 = await G(() => [performance.now(), window.__v2.game.s.time]);
  await page.tap('#st-speed [data-s="3"]'); const b0 = await G(() => [performance.now(), window.__v2.game.s.time]); await wait(1000); const b1 = await G(() => [performance.now(), window.__v2.game.s.time]);
  const r1 = (a1[1] - a0[1]) / ((a1[0] - a0[0]) / 1000), r3 = (b1[1] - b0[1]) / ((b1[0] - b0[0]) / 1000); assert(r3 > r1 * 2.3, r1 + ' ' + r3); log('speed: 1x = ' + r1.toFixed(2) + ' game s per s, 3x = ' + r3.toFixed(2));
  assert.strictEqual(await G(() => JSON.parse(localStorage.getItem('oli2-save')).speed), 3); log('speed is saved');
  await page.tap('#st-speed [data-s="1"]');
  // save now
  await page.tap('#st-save'); await wait(150); assert(/الحفظ/.test(await page.textContent('#toast'))); log('save now: "' + (await page.textContent('#toast')).trim() + '"');
  // reset needs two presses
  await G(() => { const g = window.__v2.game; g.s.cash = 123456; for (let y = 0; y < 88; y++) for (let x = 0; x < 140; x++) if (g.canPlace('tank', x, y).ok) { g.place('tank', x, y); return; } });
  await page.tap('#st-reset'); await wait(150); assert.strictEqual(await G(() => window.__v2.game.buildings.length), 1); assert(/مرة أخرى/.test(await page.textContent('#st-reset'))); log('reset: the first press only asks to confirm');
  await page.tap('#st-reset'); await wait(300); const af = await G(() => ({ b: window.__v2.game.buildings.length, cash: window.__v2.game.s.cash, open: window.__v2.game.s.regions.every(r => r.unlocked), hidden: document.getElementById('settings').hidden }));
  assert(af.b === 0 && af.open && af.hidden && af.cash !== 123456, JSON.stringify(af)); log('reset: second press = new game (no buildings, starting cash ' + af.cash + '), whole map still open');
  assert.deepStrictEqual(errors, [], errors.join('\n')); await browser.close(); console.log('ALL V2 SETTINGS TESTS PASSED');
})().catch(e => { console.error(e); process.exit(1); });
