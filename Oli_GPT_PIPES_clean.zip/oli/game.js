/* Oli — game.js
 * Isometric canvas renderer, camera, input and UI. Game rules live in core.js.
 */
(() => {
  'use strict';
  const { CFG, Game, idx } = window.OliCore;
  const W = CFG.GRID_COLS, H = CFG.GRID_ROWS;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const money = n => '$' + Math.round(n).toLocaleString('en-US');
  const money1 = n => '$' + n.toFixed(1);
  const num = n => Math.floor(n + 1e-6).toLocaleString('en-US');
  const SAVE_KEY = 'oli-save-v1';
  const TW = 64, TH = 32;                       // isometric tile size in world pixels

  /* ================= Language (Arabic UI, English available) ================= */
  const PREFS_KEY = 'oli-prefs';
  const prefs = { lang: 'ar', confirm: true };
  try { Object.assign(prefs, JSON.parse(localStorage.getItem(PREFS_KEY) || '{}')); } catch (e) { /* defaults */ }
  const savePrefs = () => { try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); } catch (e) { /* ignore */ } };

  const STR = {
    ar: {
      cash: 'النقد', oil: 'النفط', storage: 'التخزين', price: 'سعر النفط', bbl: 'برميل', perBbl: '/ برميل', perTile: '/ مربع',
      select: 'تحديد', build: 'بناء', market: 'السوق', erase: 'إزالة', menu: 'القائمة', close: 'إغلاق', confirm: 'تأكيد', cancel: 'إلغاء', flip: 'تبديل الزاوية',
      'n.well': 'بئر نفط', 'n.tank': 'خزان', 'n.pipe': 'خط أنابيب', 'n.pipeSub': 'أنبوب فرعي', 'n.pipeMain': 'أنبوب رئيسي', 'n.pipeSubS': 'فرعي', 'n.pipeMainS': 'رئيسي',
      level: 'المستوى {n}', perMin: 'برميل / دقيقة',
      'p.well': 'بئر نفط', 'p.tank': 'خزان النفط', 'p.pipe': 'خط الأنابيب',
      'p.rate': 'معدل الإنتاج', 'p.status': 'الحالة', 'p.conn': 'متصل بخزان', 'p.yes': 'نعم', 'p.no': 'لا',
      'p.amount': 'الكمية الحالية', 'p.cap': 'السعة', 'p.fill': 'نسبة الامتلاء',
      'p.upgrade': 'ترقية', 'p.move': 'نقل', 'c.move': 'نقل {what} إلى هنا · مجاناً', 'h.move': 'اضغط أو اسحب إلى المكان الجديد، ثم أكّد', 't.moved': 'تم نقل {what}', 'x.sameSpot': 'هذا هو مكانه الحالي: اختر مكاناً آخر', 'x.noMove': 'هذا العنصر لا يمكن نقله', 'p.upgradePipes': 'ترقية كل الأنابيب', 'p.max': 'أعلى مستوى', 'p.remove': 'إزالة', 'p.removeSeg': 'إزالة قطعة',
      'p.sure': 'متأكد؟ ستخسر {n} برميل', 'p.openMarket': 'فتح السوق',
      'p.segs': 'عدد القطع', 'p.tcap': 'سعة النقل', 'p.flow': 'التدفق الحالي', 'p.now': '(الآن {n})',
      'st.producing': 'ينتج', 'st.limited': 'محدود بسعة الأنبوب', 'st.full': 'التخزين ممتلئ، الإنتاج متوقف', 'st.nopipe': 'غير متصل بأنبوب', 'st.nostorage': 'لا يوجد خزان متصل', 'st.idle': 'يبدأ…',
      'h.well': 'اضغط على الخريطة لوضع <b>بئر نفط</b> · {cost}',
      'h.tank': 'اضغط على الخريطة لوضع <b>خزان</b> (2×2) · {cost}',
      'h.pipe1': 'اضغط على <b>نقطة البداية</b>: بئر أو خزان أو مضخة أو أنبوب قائم',
      'h.pipe2': 'اضغط على <b>نقطة الوصول</b>. اللعبة تحسب المسار تلقائياً',
      'x.pickNode': 'اضغط على بئر أو خزان أو مضخة أو أنبوب قائم', 'x.sameNode': 'اختر نقطة وصول مختلفة عن البداية', 'x.duplicate': 'هاتان النقطتان متصلتان بأنبوب أصلاً', 'x.badNode': 'هذه النقطة لم تعد موجودة', 'x.noPort': 'كل جوانب هذا المبنى مشغولة: اختر أحد أنابيبه بدلاً منه', 'x.sameNet': 'هذان الأنبوبان في الشبكة نفسها أصلاً', 'x.badLink': 'تعذّر تركيب الأنبوب بشكل صحيح: لم يُبنَ ولم يُخصم شيء', 't.pipeFrom': 'البداية: {what}. الآن اضغط على نقطة الوصول',
      'h.erase': 'اضغط على مبنى أو أنبوب <b>لإزالته</b> (استرجاع 50%)',
      'h.build': 'اختر ما تريد بناءه من القائمة',
      'h.n1': 'الخطوة 1: اضغط <b>بناء</b> ثم <b>بئر نفط</b> وضعه في الصحراء.',
      'h.n2': 'الخطوة 2: ابنِ <b>خزاناً</b> لتخزين النفط.',
      'h.n3': 'الخطوة 3: اربط البئر بالخزان بـ<b>خط أنابيب</b>: نقطة بداية ثم نهاية.',
      'h.n4': 'لديك {n} برميل. افتح <b>السوق</b> للبيع أو انتظر سعراً أفضل.',
      'h.n5': 'النفط يتدفق. ابنِ المزيد أو رقِّ منشآتك.',
      'c.well': 'بناء بئر نفط {cost}', 'c.tank': 'بناء خزان {cost}', 'c.pipe': 'بناء خط أنابيب {cost}',
      cost: 'التكلفة: {cost}', noCash: 'النقد غير كافٍ', connects: 'يربط البئر بالخزان ✓', noTankYet: 'الأنبوب غير موصول بخزان بعد',
      'e.outside': 'لا يمكن البناء هنا — خارج العالم', 'e.edge': 'لا يمكن البناء هنا — جزء منه خارج العالم', 'e.overlap': 'لا يمكن البناء هنا — يتداخل مع مبنى قائم', 'e.water': 'لا يمكن البناء هنا — ماء', 'e.blocked': 'لا يمكن البناء هنا — مسدود', 'e.occupied': 'لا يمكن البناء هنا — المكان مشغول', 'e.pipe': 'لا يمكن البناء هنا — يوجد أنبوب',
      'e.cash': 'النقد غير كافٍ', 'e.crossBuilding': 'الأنبوب سيعبر مبنى', 'e.nothing': 'لا يوجد ما يُبنى هنا', 'e.crossPipe': 'الأنبوب سيعبر أنبوباً آخر بدون وصلة', 'e.pipeTouch': 'الأنبوب يلامس شبكة أخرى', 'e.floating': 'يجب أن يبدأ الأنبوب من بئر أو خزان أو أنبوب',
      'e.maxlevel': 'وصلت لأعلى مستوى', 'e.nooil': 'لا يوجد نفط للبيع', 'e.tooMany': 'عدد العقود المفتوحة كبير',
      't.built': 'تم بناء {what} · −{cost}', 't.pipe': 'تم بناء الأنبوب · {n} قطعة · −{cost}', 't.removed': 'تمت الإزالة · +{n} استرجاع', 't.upgraded': 'تمت الترقية · −{cost}',
      't.sold': 'تم بيع {n} برميل · +{rev}', 't.contract': 'تم إنشاء العقد · {rev} بعد {time}', 't.delivered': 'تم تسليم العقد الآجل · +{rev}', 't.tankFull': 'الخزان ممتلئ، الإنتاج سيتوقف',
      't.alert': 'تنبيه السعر: وصل النفط إلى {p}', 't.waiting': 'بانتظار السعر. سيصلك تنبيه عند {p}.', 't.waiting0': 'سننتظر. النفط يبقى في التخزين.',
      't.welcome': 'أهلاً بك في Oli. ابنِ بئراً وخزاناً وخط أنابيب.', 't.back': 'أهلاً بعودتك. تمت استعادة اللعبة.', 't.saved': 'تم حفظ اللعبة', 't.new': 'بدأت لعبة جديدة',
      't.pipeEnd': 'الآن اضغط على نقطة نهاية الأنبوب', 't.tankHolds': 'الخزان يحتوي {n} برميل. اضغط مرة أخرى لإزالته.',
      'm.title': 'سوق النفط', 'm.delta': 'تغير السعر', 'm.stored': 'النفط المخزّن', 'm.cash': 'المال المتاح', 'm.profit': 'الربح', 'm.revenueTot': 'الإيرادات', 'm.opcost': 'تكاليف التشغيل', 'm.costRate': 'التكلفة / دقيقة', 'm.vsNow': 'مقارنة بالسعر الآن', 'm.avail': 'متاح للعقود', 'm.stockValue': 'قيمة المخزون الآن', 'm.waitCost': 'تكلفة الانتظار / دقيقة', 'm.finished': 'العقود المنتهية', 'm.owed': 'مستحق يُدفع من الإيراد القادم: {n}', 'm.warnSell': 'سيقل المخزون عن كمية العقود المفتوحة ({n} برميل). قد تدفع غرامة.', 'm.perMin': '{n} / د',
      'c.active': 'ساري', 'c.completed': 'مكتمل', 'c.expired': 'منتهٍ', 'c.short': 'النفط في التخزين أقل من كمية العقد', 'c.vs': 'مقابل البيع الفوري {d}', 'c.pen': 'غرامة {n}', 'c.left': 'المتبقي',
      'e.nofree': 'كل النفط المتاح محجوز لعقود أخرى', 't.expired': 'انتهى العقد بدون تسليم · غرامة −{pen}', 'log.futuresExpired': 'عقد آجل منتهٍ بدون تسليم: {n} برميل (غرامة)', 'm.current': 'السعر الحالي', 'm.prev': 'السعر السابق', 'm.trend': 'الاتجاه', 'm.up': '▲ صاعد', 'm.down': '▼ هابط', 'm.flat': '▬ مستقر',
      'm.change': 'التغير (5 دقائق)', 'm.high': 'الأعلى', 'm.low': 'الأدنى',
      'm.spot': 'بيع فوري', 'm.spotDesc': 'بع النفط الآن بالسعر الحالي.', 'm.amount': 'الكمية', 'm.all': 'الكل', 'm.revenue': 'الإيراد', 'm.sell': 'بيع النفط',
      'm.fut': 'عقد آجل', 'm.futDesc': 'ثبّت سعراً الآن. يبقى النفط عندك ويُسلَّم من التخزين عند انتهاء المدة. إن لم يكن موجوداً تدفع غرامة 15%.', 'm.min': '{n} دقيقة', 'm.contractPrice': 'سعر العقد', 'm.expected': 'الإيراد المتوقع', 'm.create': 'إنشاء عقد',
      'm.wait': 'انتظار', 'm.waitDesc': 'أبقِ النفط في التخزين وراقب السعر. حدّد تنبيهاً لسعر يعجبك.', 'm.alert': 'تنبيه السعر', 'm.off': 'مطفأ', 'm.waitBtn': 'انتظار',
      'm.line': '{n} برميل @ {p}', 'm.nowShort': 'الآن', 'm.contracts': 'العقود المفتوحة', 'm.noContracts': 'لا توجد عقود مفتوحة.', 'm.recent': 'آخر النشاطات', 'm.nothing': 'لا شيء بعد. ابنِ بئراً للبدء.', 'm.exp': 'الإيراد المتوقع {rev}',
      'ago.now': 'الآن', 'ago.s': 'منذ {n} ث', 'ago.m': 'منذ {n} د',
      'log.built': 'بناء {what}', 'log.pipe': 'بناء خط أنابيب ({n} قطعة)', 'log.removed': 'إزالة {what}', 'log.removedPipe': 'إزالة قطعة أنبوب',
      'log.upgrade': 'ترقية {what} إلى المستوى {n}', 'log.upgradePipes': 'ترقية الأنابيب إلى المستوى {n}',
      'log.sold': 'بيع {n} برميل بسعر {p}', 'log.futures': 'عقد آجل: {n} برميل بسعر {p}', 'log.futuresDelivered': 'تسليم عقد آجل: {n} برميل بسعر {p}',
      's.language': 'اللغة', 's.speed': 'سرعة اللعبة', 's.pause': 'إيقاف', 's.confirmBuild': 'التأكيد قبل البناء', 's.on': 'مفعّل', 's.off': 'مطفأ',
      's.saveNote': 'يُحفظ التقدم تلقائياً في هذا المتصفح.', 's.saveNow': 'حفظ الآن', 's.resetNote': 'ابدأ من جديد برصيد {cash}', 's.reset': 'إعادة اللعبة', 's.sure': 'اضغط مرة أخرى للتأكيد',
      's.controls': 'التحكم',
      's.help1': 'اسحب لتحريك الخريطة. اقرص أو استخدم العجلة للتكبير. اضغط على أي منشأة لعرض معلوماتها.',
      's.help2': 'خط الأنابيب: اضغط نقطة البداية ثم النهاية. الأنابيب أفقية وعمودية فقط. المفاتيح: 1–5 للأدوات، R لتبديل الزاوية، Enter للتأكيد، Esc للإلغاء.'
    },
    en: {
      cash: 'Cash', oil: 'Oil', storage: 'Storage', price: 'Oil Price', bbl: 'BBL', perBbl: '/ BBL', perTile: '/ tile',
      select: 'Select', build: 'Build', market: 'Market', erase: 'Remove', menu: 'Menu', close: 'Close', confirm: 'Confirm', cancel: 'Cancel', flip: 'Flip corner',
      'n.well': 'Oil Well', 'n.tank': 'Storage Tank', 'n.pipe': 'Pipeline', 'n.pipeSub': 'Branch Pipe', 'n.pipeMain': 'Main Pipeline', 'n.pipeSubS': 'Branch', 'n.pipeMainS': 'Main',
      level: 'Lv {n}', perMin: 'BBL / min',
      'p.well': 'Oil Well', 'p.tank': 'Oil Storage', 'p.pipe': 'Pipeline',
      'p.rate': 'Production Rate', 'p.status': 'Status', 'p.conn': 'Connected to storage', 'p.yes': 'Yes', 'p.no': 'No',
      'p.amount': 'Current Amount', 'p.cap': 'Capacity', 'p.fill': 'Fill Level',
      'p.upgrade': 'Upgrade', 'p.move': 'Move', 'c.move': 'Move {what} here · free', 'h.move': 'Tap or drag to the new spot, then confirm', 't.moved': '{what} moved', 'x.sameSpot': 'That is its current spot: pick another one', 'x.noMove': 'This cannot be moved', 'p.upgradePipes': 'Upgrade all pipes', 'p.max': 'Max level', 'p.remove': 'Remove', 'p.removeSeg': 'Remove segment',
      'p.sure': 'Sure? Lose {n} BBL', 'p.openMarket': 'Open Market',
      'p.segs': 'Network Segments', 'p.tcap': 'Transfer Capacity', 'p.flow': 'Current Flow', 'p.now': '(now {n})',
      'st.producing': 'Producing', 'st.limited': 'Limited by pipeline', 'st.full': 'Storage full, production stopped', 'st.nopipe': 'Not connected to a pipe', 'st.nostorage': 'No storage connected', 'st.idle': 'Starting…',
      'h.well': 'Tap the map to place an <b>Oil Well</b> · {cost}',
      'h.tank': 'Tap the map to place a <b>Storage Tank</b> (2×2) · {cost}',
      'h.pipe1': 'Tap a <b>start point</b>: a well, tank, pump or existing pipe',
      'h.pipe2': 'Tap the <b>destination</b>. The route is worked out for you',
      'x.pickNode': 'Tap a well, tank, pump or existing pipe', 'x.sameNode': 'Pick a destination different from the start', 'x.duplicate': 'These two points are already joined by a pipe', 'x.badNode': 'That point no longer exists', 'x.noPort': 'Every side of this building is taken: pick one of its pipes instead', 'x.sameNet': 'Those pipes are already in the same network', 'x.badLink': 'The pipe could not be fitted correctly: nothing was built or charged', 't.pipeFrom': 'Start: {what}. Now tap the destination',
      'h.erase': 'Tap a building or pipe to <b>remove</b> it (50% refund)',
      'h.build': 'Pick what to build from the menu',
      'h.n1': 'Step 1: tap <b>Build</b>, then <b>Oil Well</b>, and place it in the desert.',
      'h.n2': 'Step 2: build a <b>Storage Tank</b> for your oil.',
      'h.n3': 'Step 3: join the well and tank with a <b>Pipeline</b>: a start tile, then an end tile.',
      'h.n4': 'You have {n} BBL. Open the <b>Market</b> to sell, or wait for a better price.',
      'h.n5': 'Oil is flowing. Build more or upgrade.',
      'c.well': 'Build Oil Well {cost}', 'c.tank': 'Build Storage Tank {cost}', 'c.pipe': 'Build Pipeline {cost}',
      cost: 'Cost: {cost}', noCash: 'Insufficient funds', connects: 'Joins well to tank ✓', noTankYet: 'Pipe is not connected to a tank yet',
      'e.outside': 'Cannot build here — outside the world', 'e.edge': 'Cannot build here — partly outside the world', 'e.overlap': 'Cannot build here — overlaps existing structure', 'e.water': 'Cannot build here — water', 'e.blocked': 'Cannot build here — blocked', 'e.occupied': 'Cannot build here — occupied', 'e.pipe': 'Cannot build here — a pipe is in the way',
      'e.cash': 'Insufficient funds', 'e.crossBuilding': 'Pipe would cross a building', 'e.nothing': 'Nothing to build here', 'e.crossPipe': 'The pipe would cross another pipe without a junction', 'e.pipeTouch': 'The pipe would touch another network', 'e.floating': 'A pipe must start at a well, tank or pipe',
      'e.maxlevel': 'Already at max level', 'e.nooil': 'No oil to sell', 'e.tooMany': 'Too many open contracts',
      't.built': '{what} built · −{cost}', 't.pipe': 'Pipeline built · {n} segments · −{cost}', 't.removed': 'Removed · +{n} refund', 't.upgraded': 'Upgraded · −{cost}',
      't.sold': 'Sold {n} BBL · +{rev}', 't.contract': 'Contract set · {rev} in {time}', 't.delivered': 'Futures delivered · +{rev}', 't.tankFull': 'Tank full, production will stop',
      't.alert': 'Price alert: oil reached {p}', 't.waiting': 'Waiting. You will be alerted at {p}.', 't.waiting0': 'Waiting. Oil stays in storage.',
      't.welcome': 'Welcome to Oli. Build a well, a tank and a pipeline.', 't.back': 'Welcome back. Game restored.', 't.saved': 'Game saved', 't.new': 'New game started',
      't.pipeEnd': 'Now tap where the pipeline should end', 't.tankHolds': 'Tank holds {n} BBL. Tap again to remove it.',
      'm.title': 'Oil Market', 'm.delta': 'Price change', 'm.stored': 'Stored oil', 'm.cash': 'Cash', 'm.profit': 'Profit', 'm.revenueTot': 'Revenue', 'm.opcost': 'Operating cost', 'm.costRate': 'Cost / min', 'm.vsNow': 'vs price now', 'm.avail': 'Free for contracts', 'm.stockValue': 'Stock value now', 'm.waitCost': 'Cost of waiting / min', 'm.finished': 'Finished contracts', 'm.owed': 'Owed, paid from the next revenue: {n}', 'm.warnSell': 'Stock would fall below your open contracts ({n} BBL). You may pay a penalty.', 'm.perMin': '{n} / min',
      'c.active': 'ACTIVE', 'c.completed': 'COMPLETED', 'c.expired': 'EXPIRED', 'c.short': 'Storage holds less than the contract needs', 'c.vs': 'vs spot {d}', 'c.pen': 'Penalty {n}', 'c.left': 'Left',
      'e.nofree': 'All your oil is already committed to contracts', 't.expired': 'Contract ended without delivery · penalty −{pen}', 'log.futuresExpired': 'Futures expired without delivery: {n} BBL (penalty)', 'm.current': 'Current price', 'm.prev': 'Previous price', 'm.trend': 'Trend', 'm.up': '▲ Rising', 'm.down': '▼ Falling', 'm.flat': '▬ Stable',
      'm.change': '5 min change', 'm.high': 'High', 'm.low': 'Low',
      'm.spot': 'Spot Sale', 'm.spotDesc': 'Sell immediately at the current price.', 'm.amount': 'Amount', 'm.all': 'All', 'm.revenue': 'Revenue', 'm.sell': 'Sell Oil',
      'm.fut': 'Futures Contract', 'm.futDesc': 'Lock a price now. Your oil stays with you and is delivered from storage when time is up. If it is missing you pay a 15% penalty.', 'm.min': '{n} min', 'm.contractPrice': 'Contract price', 'm.expected': 'Expected revenue', 'm.create': 'Create Contract',
      'm.wait': 'Wait', 'm.waitDesc': 'Keep your oil in storage and watch the price. Set an alert for a price you like.', 'm.alert': 'Price alert', 'm.off': 'Off', 'm.waitBtn': 'Wait',
      'm.line': '{n} BBL @ {p}', 'm.nowShort': 'Now', 'm.contracts': 'Open contracts', 'm.noContracts': 'No open contracts.', 'm.recent': 'Recent activity', 'm.nothing': 'Nothing yet. Build a well to get started.', 'm.exp': 'Expected revenue {rev}',
      'ago.now': 'just now', 'ago.s': '{n}s ago', 'ago.m': '{n}m ago',
      'log.built': 'Built {what}', 'log.pipe': 'Built Pipeline ({n} segments)', 'log.removed': 'Removed {what}', 'log.removedPipe': 'Removed pipe segment',
      'log.upgrade': 'Upgraded {what} to Lv {n}', 'log.upgradePipes': 'Upgraded Pipelines to Lv {n}',
      'log.sold': 'Sold {n} BBL at {p}', 'log.futures': 'Futures: {n} BBL at {p}', 'log.futuresDelivered': 'Futures delivered: {n} BBL at {p}',
      's.language': 'Language', 's.speed': 'Game speed', 's.pause': 'Pause', 's.confirmBuild': 'Confirm before building', 's.on': 'On', 's.off': 'Off',
      's.saveNote': 'Progress saves automatically in this browser.', 's.saveNow': 'Save now', 's.resetNote': 'Start over with {cash}', 's.reset': 'Reset game', 's.sure': 'Tap again to confirm',
      's.controls': 'Controls',
      's.help1': 'Drag to move the map. Pinch or scroll to zoom. Tap a building to see its details.',
      's.help2': 'Pipeline: tap a start tile, then an end tile. Pipes run horizontally and vertically only. Keys: 1–5 tools, R flips the corner, Enter confirms, Esc cancels.'
    }
  };

  /* Phase 3 strings: upgrades, wells types, pressure, maintenance, leaks, quality, exploration */
  const STR3 = {
    ar: {
      'from': 'من {c}', 'perMinShort': '/د', 'n.explore': 'استكشاف', 'n.well.small': 'بئر صغير', 'n.well.medium': 'بئر متوسط', 'n.well.large': 'بئر كبير',
      'k.small': 'صغير', 'k.medium': 'متوسط', 'k.large': 'كبير',
      'kd.small': 'إنتاج منخفض · ضغط مستقر · مخاطر قليلة', 'kd.medium': 'إنتاج متوسط · مخاطر متوسطة', 'kd.large': 'إنتاج عالٍ · الضغط ينخفض أسرع · مخاطر أعلى',
      'q.LOW': 'منخفضة ×0.85', 'q.MEDIUM': 'متوسطة ×1.00', 'q.HIGH': 'عالية ×1.20',
      'p.type': 'النوع', 'p.prod': 'الإنتاج الحالي', 'p.nominal': 'من أصل {n}', 'p.pressure': 'الضغط', 'p.cond': 'الحالة الفنية', 'p.quality': 'جودة النفط', 'p.reserve': 'الاحتياطي المتبقي',
      'p.maintBtn': 'صيانة {cost}', 'p.maintGood': 'الحالة ممتازة', 'p.lvlPipe': 'مستوى الشبكة', 'p.pipeType': 'نوع الأنبوب', 'pipe.sub': 'فرعي', 'pipe.main': 'رئيسي', 'p.leakState': 'حالة الأنبوب', 'p.leaks': 'تسريبات الشبكة', 'p.lost': 'نفط ضائع',
      'ls.0': 'سليم', 'ls.1': 'تسريب!', 'ls.2': 'قيد الإصلاح',
      'p.repair': 'إصلاح {cost}', 'p.repairing': 'جارٍ الإصلاح…', 'p.noLeak': 'لا يوجد تسريب', 'p.upgradeTo': 'ترقية {cost}', 'p.pipeCond': 'حالة الأنبوب',
      'a.title': 'منطقة استكشاف', 'a.status': 'الاستكشاف', 'a.s.unexplored': 'غير مستكشفة', 'a.s.exploring': 'جارٍ… {n}%', 'a.s.discovered': 'مكتشفة',
      'a.res': 'الاحتياطي', 'a.k.empty': 'فارغ', 'a.k.small': 'صغير', 'a.k.medium': 'متوسط', 'a.k.large': 'كبير', 'a.size': 'حجم الاحتياطي', 'a.left': 'المتبقي', 'a.pot': 'الإنتاج المحتمل', 'a.wells': 'الآبار هنا',
      'a.explore': 'استكشاف {cost}', 'a.build': 'بناء بئر هنا', 'a.hidden': 'قد تحتوي هذه المنطقة على نفط. ادفع لاستكشافها لتعرف.', 'a.emptyNote': 'لا يوجد نفط هنا.', 'a.unknown': '؟',
      'h.well': 'اضغط على <b>احتياطي مكتشف</b> لوضع بئر · {cost}', 'h.explore': 'اضغط على منطقة لاستكشافها · {cost} · تبقى مخفية حتى تُستكشف',
      'e.notExplored': 'استكشف المنطقة أولاً', 'e.noOil': 'المنطقة فارغة، لا يوجد نفط', 'e.depleted': 'نفد الاحتياطي', 'e.exploring': 'الاستكشاف جارٍ', 'e.known': 'المنطقة مكتشفة بالفعل',
      'e.repairing': 'الإصلاح جارٍ بالفعل', 'e.noleak': 'لا يوجد تسريب هنا', 'e.good': 'الحالة ممتازة بالفعل',
      'st.broken': 'معطّل، يحتاج صيانة', 'st.depleted': 'نفد الاحتياطي',
      't.leak': 'تسريب في الأنابيب! اضغط على العلامة الحمراء للإصلاح', 't.repaired': 'تم إصلاح الأنبوب', 't.repairStart': 'بدأ الإصلاح · −{cost}', 't.maint': 'تمت الصيانة · −{cost}',
      't.exploreStart': 'بدأ الاستكشاف · −{cost}', 't.explored': 'اكتمل الاستكشاف: {what}', 't.upgradedTo': 'ترقية إلى المستوى {n} · −{cost}', 't.lowCond': 'بئر يحتاج صيانة',
      'log.explore': 'بدء استكشاف منطقة', 'log.explored': 'اكتمل استكشاف المنطقة', 'log.leak': 'تسريب في أنبوب', 'log.repair': 'إصلاح أنبوب', 'log.maintenance': 'صيانة {what}',
      'm.quality': 'جودة المخزون', 'm.extra': 'صيانة وإصلاح', 'm.capex': 'ترقيات واستكشاف'
    },
    en: {
      'from': 'from {c}', 'perMinShort': '/min', 'n.explore': 'Explore', 'n.well.small': 'Small well', 'n.well.medium': 'Medium well', 'n.well.large': 'Large well',
      'k.small': 'Small', 'k.medium': 'Medium', 'k.large': 'Large',
      'kd.small': 'Low output · steady pressure · low risk', 'kd.medium': 'Medium output · medium risk', 'kd.large': 'High output · pressure drops faster · higher risk',
      'q.LOW': 'Low ×0.85', 'q.MEDIUM': 'Medium ×1.00', 'q.HIGH': 'High ×1.20',
      'p.type': 'Type', 'p.prod': 'Production now', 'p.nominal': 'of {n}', 'p.pressure': 'Pressure', 'p.cond': 'Condition', 'p.quality': 'Oil quality', 'p.reserve': 'Reserve left',
      'p.maintBtn': 'Maintenance {cost}', 'p.maintGood': 'Condition is perfect', 'p.lvlPipe': 'Network level', 'p.pipeType': 'Pipe type', 'pipe.sub': 'Branch', 'pipe.main': 'Main', 'p.leakState': 'Pipe state', 'p.leaks': 'Network leaks', 'p.lost': 'Oil lost',
      'ls.0': 'Normal', 'ls.1': 'LEAK!', 'ls.2': 'Repairing',
      'p.repair': 'Repair {cost}', 'p.repairing': 'Repairing…', 'p.noLeak': 'No leak', 'p.upgradeTo': 'Upgrade {cost}', 'p.pipeCond': 'Pipe condition',
      'a.title': 'Survey area', 'a.status': 'Exploration', 'a.s.unexplored': 'Unexplored', 'a.s.exploring': 'Exploring… {n}%', 'a.s.discovered': 'Discovered',
      'a.res': 'Reserve', 'a.k.empty': 'Empty', 'a.k.small': 'Small', 'a.k.medium': 'Medium', 'a.k.large': 'Large', 'a.size': 'Reserve size', 'a.left': 'Remaining', 'a.pot': 'Production potential', 'a.wells': 'Wells here',
      'a.explore': 'Explore {cost}', 'a.build': 'Build a well here', 'a.hidden': 'This area may hold oil. Pay to explore it and find out.', 'a.emptyNote': 'No oil here.', 'a.unknown': '?',
      'h.well': 'Tap a <b>discovered reserve</b> to place a well · {cost}', 'h.explore': 'Tap an area to explore it · {cost} · stays hidden until explored',
      'e.notExplored': 'Explore the area first', 'e.noOil': 'The area is empty, no oil', 'e.depleted': 'The reserve is depleted', 'e.exploring': 'Exploration in progress', 'e.known': 'Already discovered',
      'e.repairing': 'Repair already in progress', 'e.noleak': 'No leak here', 'e.good': 'Already in perfect condition',
      'st.broken': 'Broken, needs maintenance', 'st.depleted': 'Reserve depleted',
      't.leak': 'Pipe leak! Tap the red marker to repair it', 't.repaired': 'Pipe repaired', 't.repairStart': 'Repair started · −{cost}', 't.maint': 'Maintenance done · −{cost}',
      't.exploreStart': 'Exploration started · −{cost}', 't.explored': 'Exploration complete: {what}', 't.upgradedTo': 'Upgraded to level {n} · −{cost}', 't.lowCond': 'A well needs maintenance',
      'log.explore': 'Started exploring an area', 'log.explored': 'Area exploration complete', 'log.leak': 'Pipe leak', 'log.repair': 'Pipe repair', 'log.maintenance': 'Maintenance: {what}',
      'm.quality': 'Stock quality', 'm.extra': 'Maintenance + repairs', 'm.capex': 'Upgrades + exploring'
    }
  };
  Object.assign(STR.ar, STR3.ar); Object.assign(STR.en, STR3.en);

  /* Phase 4 strings: regions, terrain, supply contracts, market events, competitors */
  const STR4 = {
    ar: {
      regions: 'المناطق', 'tab.trade': 'التداول', 'tab.orders': 'عقود التوريد', 'tab.comp': 'الشركات',
      'r.title': 'المناطق', 'r.note': 'افتح مناطق جديدة لاستكشاف احتياطيات أكبر. التكلفة والتضاريس والمخاطر تختلف من منطقة لأخرى.',
      'r.1': 'المنطقة 1 — البداية', 'r.2': 'المنطقة 2 — الصحراء', 'r.3': 'المنطقة 3 — الصخور', 'r.4': 'المنطقة 4 — النائية', 'r.5': 'المنطقة 5 — الإمكانات العالية',
      'rs.LOCKED': 'مقفلة', 'rs.AVAILABLE': 'متاحة', 'rs.EXPLORED': 'مستكشفة', 'rs.ACTIVE': 'نشطة',
      'tr.SAND': 'رمل', 'tr.FLAT': 'أرض مستوية', 'tr.ROUGH': 'أرض وعرة', 'tr.ROCK': 'صخور',
      'r.terrain': 'التضاريس', 'r.build': 'تكلفة البناء', 'r.explore': 'تكلفة الاستكشاف', 'r.risk': 'المخاطر', 'r.potential': 'فرصة النفط', 'r.progress': 'المستكشف', 'r.wells': 'الآبار',
      'risk.low': 'منخفضة', 'risk.mid': 'متوسطة', 'risk.high': 'عالية',
      'r.unlock': 'فتح المنطقة {cost}', 'r.need': 'يلزم رصيد {need}', 'r.go': 'عرض على الخريطة', 'r.opened': 'تم فتح المنطقة · −{cost}', 'a.region': 'المنطقة', 'a.locked': 'هذه المنطقة مقفلة. افتحها أولاً.', 'a.openRegions': 'فتح المنطقة…',
      'e.locked': 'المنطقة مقفلة. افتحها من لوحة المناطق', 'e.needCash': 'رصيدك لا يكفي لفتح هذه المنطقة', 'e.tooManyOrders': 'وصلت للحد الأقصى من العقود السارية',
      'o.offers': 'عروض جديدة', 'o.active': 'العقود السارية', 'o.history': 'آخر العقود', 'o.none': 'لا توجد عروض الآن. تظهر عروض جديدة كل دقيقة تقريباً.', 'o.noActive': 'لا توجد عقود سارية.', 'o.noHistory': 'لا شيء بعد.',
      'o.required': 'المطلوب', 'o.delivered': 'تم تسليمه', 'o.remaining': 'المتبقي', 'o.price': 'السعر', 'o.reward': 'المكافأة', 'o.time': 'المدة', 'o.left': 'الوقت المتبقي', 'o.expires': 'ينتهي العرض بعد',
      'o.accept': 'قبول العقد', 'o.deliver': 'تسليم الكل المتاح', 'o.deliver100': 'تسليم 100', 'o.vsSpot': 'مقابل السوق {d}', 'o.min': '{n} د',
      'o.risk': 'تسليم كامل الكمية قبل الموعد وإلا تدفع غرامة 10% ولا تحصل إلا على 40% من قيمة ما سلّمته.',
      'os.AVAILABLE': 'متاح', 'os.ACTIVE': 'ساري', 'os.COMPLETED': 'مكتمل', 'os.FAILED': 'فشل', 'os.EXPIRED': 'منتهٍ',
      't.offer': 'عرض عقد جديد: {n} برميل @ {p}', 't.orderDone': 'اكتمل العقد · +{rev}', 't.orderFailed': 'فشل العقد: انتهى الوقت', 't.delivered2': 'تم تسليم {n} برميل للعقد', 't.accepted': 'تم قبول العقد',
      'ev.DEMAND_SURGE': 'ارتفاع الطلب', 'ev.SUPPLY_SHOCK': 'فائض في المعروض', 'ev.MARKET_DROP': 'هبوط السوق', 'ev.MARKET_BOOM': 'ازدهار السوق', 'ev.STABLE_MARKET': 'سوق مستقر',
      'evh.DEMAND_SURGE': 'ارتفاع مفاجئ في الطلب على النفط', 'evh.SUPPLY_SHOCK': 'زيادة مفاجئة في المعروض تضغط على الأسعار', 'evh.MARKET_DROP': 'هبوط حاد في السوق', 'evh.MARKET_BOOM': 'ازدهار في السوق ورغبة قوية بالشراء', 'evh.STABLE_MARKET': 'السوق هادئ ومستقر',
      'ev.title': 'حدث في السوق', 'ev.price': 'سعر النفط', 'ev.left': 'متبقٍ', 'ev.fading': 'يعود السوق لطبيعته', 'ev.over': 'عاد السوق إلى وضعه الطبيعي',
      'c.rank': 'الترتيب', 'c.company': 'الشركة', 'c.share': 'الحصة', 'c.prod': 'إنتاج/د', 'c.rev': 'الإيرادات', 'c.metric': 'الترتيب حسب إجمالي الإيرادات. الحصة = نصيب كل شركة من إنتاج النفط خلال آخر ~10 دقائق.',
      'c.effect': 'تأثير المنافسين على السعر', 'c.me': 'أنت', 'co.A': 'شركة A', 'co.B': 'شركة B', 'co.C': 'شركة C',
      'sg.AGGRESSIVE': 'هجومي', 'sg.BALANCED': 'متوازن', 'sg.CONSERVATIVE': 'متحفظ',
      'log.region': 'فتح المنطقة {n}', 'log.orderAccepted': 'قبول عقد توريد {n} برميل', 'log.orderDone': 'اكتمل عقد توريد {n} برميل', 'log.orderFailed': 'فشل عقد توريد (سُلّم {n})', 'log.event': 'حدث في السوق: {type}'
    },
    en: {
      regions: 'Regions', 'tab.trade': 'Trade', 'tab.orders': 'Supply contracts', 'tab.comp': 'Companies',
      'r.title': 'Regions', 'r.note': 'Unlock new regions to explore bigger reserves. Costs, terrain and risk differ between regions.',
      'r.1': 'Region 1 — Starter', 'r.2': 'Region 2 — Desert', 'r.3': 'Region 3 — Rocky', 'r.4': 'Region 4 — Remote', 'r.5': 'Region 5 — High Potential',
      'rs.LOCKED': 'Locked', 'rs.AVAILABLE': 'Available', 'rs.EXPLORED': 'Explored', 'rs.ACTIVE': 'Active',
      'tr.SAND': 'Sand', 'tr.FLAT': 'Flat ground', 'tr.ROUGH': 'Rough ground', 'tr.ROCK': 'Rock',
      'r.terrain': 'Terrain', 'r.build': 'Construction cost', 'r.explore': 'Exploration cost', 'r.risk': 'Risk', 'r.potential': 'Oil chance', 'r.progress': 'Explored', 'r.wells': 'Wells',
      'risk.low': 'Low', 'risk.mid': 'Medium', 'risk.high': 'High',
      'r.unlock': 'Unlock {cost}', 'r.need': 'Needs {need} in cash', 'r.go': 'Show on map', 'r.opened': 'Region unlocked · −{cost}', 'a.region': 'Region', 'a.locked': 'This region is locked. Unlock it first.', 'a.openRegions': 'Unlock region…',
      'e.locked': 'Region is locked. Unlock it in the Regions panel', 'e.needCash': 'Not enough cash to unlock this region', 'e.tooManyOrders': 'Too many active contracts',
      'o.offers': 'New offers', 'o.active': 'Active contracts', 'o.history': 'Recent contracts', 'o.none': 'No offers right now. New ones appear about every minute.', 'o.noActive': 'No active contracts.', 'o.noHistory': 'Nothing yet.',
      'o.required': 'Required', 'o.delivered': 'Delivered', 'o.remaining': 'Remaining', 'o.price': 'Price', 'o.reward': 'Reward', 'o.time': 'Duration', 'o.left': 'Time left', 'o.expires': 'Offer ends in',
      'o.accept': 'Accept contract', 'o.deliver': 'Deliver all available', 'o.deliver100': 'Deliver 100', 'o.vsSpot': 'vs market {d}', 'o.min': '{n} min',
      'o.risk': 'Deliver the full amount before the deadline, or pay a 10% penalty and receive only 40% of what you delivered.',
      'os.AVAILABLE': 'Available', 'os.ACTIVE': 'Active', 'os.COMPLETED': 'Completed', 'os.FAILED': 'Failed', 'os.EXPIRED': 'Expired',
      't.offer': 'New contract offer: {n} BBL @ {p}', 't.orderDone': 'Contract completed · +{rev}', 't.orderFailed': 'Contract failed: time ran out', 't.delivered2': 'Delivered {n} BBL to the contract', 't.accepted': 'Contract accepted',
      'ev.DEMAND_SURGE': 'Demand surge', 'ev.SUPPLY_SHOCK': 'Supply glut', 'ev.MARKET_DROP': 'Market drop', 'ev.MARKET_BOOM': 'Market boom', 'ev.STABLE_MARKET': 'Stable market',
      'evh.DEMAND_SURGE': 'Sudden jump in demand for oil', 'evh.SUPPLY_SHOCK': 'Sudden extra supply is pushing prices down', 'evh.MARKET_DROP': 'Sharp drop in the market', 'evh.MARKET_BOOM': 'The market is booming', 'evh.STABLE_MARKET': 'The market is calm and stable',
      'ev.title': 'MARKET EVENT', 'ev.price': 'Oil price', 'ev.left': 'left', 'ev.fading': 'Market returning to normal', 'ev.over': 'The market is back to normal',
      'c.rank': 'Rank', 'c.company': 'Company', 'c.share': 'Share', 'c.prod': 'Output/min', 'c.rev': 'Revenue', 'c.metric': 'Ranked by total revenue. Share = each company\'s part of all oil produced over the last ~10 minutes.',
      'c.effect': 'Competitors\' effect on price', 'c.me': 'You', 'co.A': 'Company A', 'co.B': 'Company B', 'co.C': 'Company C',
      'sg.AGGRESSIVE': 'Aggressive', 'sg.BALANCED': 'Balanced', 'sg.CONSERVATIVE': 'Conservative',
      'log.region': 'Unlocked region {n}', 'log.orderAccepted': 'Accepted a {n} BBL supply contract', 'log.orderDone': 'Completed a {n} BBL supply contract', 'log.orderFailed': 'Failed a supply contract ({n} delivered)', 'log.event': 'Market event: {type}'
    }
  };
  Object.assign(STR.ar, STR4.ar); Object.assign(STR.en, STR4.en);
  /* Phase 5 strings: smart help (what to do next), first-game guide, speed */
  const STR5 = {
    ar: {
      'x.notExplored': 'هذه المنطقة تحتاج استكشافاً أولاً: اختر «استكشاف» ثم اضغط عليها', 'x.noOil': 'لا نفط في هذه البقعة. ابنِ على بقعة خضراء أو استكشف منطقة أخرى', 'x.depleted': 'نفد النفط هنا. استكشف منطقة جديدة',
      'x.crossPipe': 'الأنابيب لا تتقاطع: انهِ الأنبوب على الأنبوب القائم لعمل وصلة، أو غيّر مساره', 'x.pipeTouch': 'اترك مربعاً فارغاً بين الشبكتين، أو انهِ الأنبوب على الأنبوب القائم لتوصيلهما', 'x.floating': 'ابدأ الأنبوب من بئر أو خزان أو أنبوب قائم (النقاط المضيئة)', 'x.nooil': 'لا يوجد نفط كافٍ للبيع. وصّل البئر بالخزان وانتظر قليلاً', 'x.cash': 'النقد غير كافٍ. بع بعض النفط أو اختر خياراً أرخص',
      'x.blocked': 'لا يمكن البناء هنا — مسدود. اضغط قرب بقعة خضراء', 'x.water': 'لا يمكن البناء هنا — ماء. اضغط قرب بقعة خضراء', 'x.occupied': 'لا يمكن البناء هنا — المكان مشغول. اضغط قرب بقعة خضراء', 'x.pipe': 'لا يمكن البناء هنا — يوجد أنبوب. اختر مكاناً فارغاً',
      'x.crossBuilding': 'الأنبوب سيعبر مبنى. بدّل الاتجاه بزر ⇄ أو غيّر نقطة النهاية', 'x.locked': 'المنطقة مقفلة. افتحها من زر «المناطق»', 'x.nothing': 'لا شيء جديد يُبنى هنا. اسحب إلى مكان آخر', 'x.nofree': 'نفطك كله مرتبط بعقود. انتظر انتهاءها أو أنتج المزيد',
      'x.outside': 'لا يمكن البناء هنا — خارج العالم. اضغط داخل الأرض', 'x.edge': 'لا يمكن البناء هنا — جزء منه خارج العالم. حرّكه إلى الداخل', 'x.overlap': 'لا يمكن البناء هنا — يتداخل مع مبنى قائم. حرّكه قليلاً', 'x.noleak': 'لا يوجد تسرب هنا، الأنبوب سليم',
      'p.more': 'تفاصيل أكثر ▾', 'p.less': 'تفاصيل أقل ▴',
      'co.well': 'ابنِ <b>بئراً</b>: اضغط على النقطة المضيئة', 'co.pipe': 'وصّل <b>أنبوباً</b>: اختر «أنبوب»، اضغط على <b>البئر</b> ثم على <b>الخزان</b>، ثم أكّد', 'co.tank': 'ابنِ <b>خزاناً</b> عند النقطة المضيئة، قريباً من البئر',
      'co.link': 'بقي أن <b>تصل البئر بالخزان</b>: اختر «أنبوب»، اضغط على البئر ثم على الخزان', 'co.wait': 'النفط يتدفق في الأنبوب إلى الخزان… <b>انتظر لحظات</b> حتى يمتلئ', 'co.sell': 'صار عندك نفط في الخزان! افتح <b>السوق</b> واضغط «بيع»',
      'co.done': 'أحسنت! بعت أول نفطك. أصبحت شركة نفط 🎉', 'co.skipped': 'تم إنهاء الإرشاد. يمكنك اللعب بحرية', 'co.skip': 'تخطي',
      's.paused': 'اللعبة متوقفة', 's.speedTo': 'سرعة اللعبة {n}×', 'speedBtn': 'السرعة'
    },
    en: {
      'x.notExplored': 'This area needs exploring first: pick Explore, then tap it', 'x.noOil': 'No oil on this spot. Build on a green spot or explore another area', 'x.depleted': 'The oil here ran out. Explore a new area',
      'x.crossPipe': 'Pipes do not cross: end the pipe ON the existing one to make a junction, or change its path', 'x.pipeTouch': 'Leave one empty tile between the two networks, or end the pipe on the existing one to join them', 'x.floating': 'Start the pipe at a well, tank or existing pipe (the glowing spots)', 'x.nooil': 'Not enough oil to sell. Connect the well to a tank and wait a moment', 'x.cash': 'Not enough cash. Sell some oil or choose something cheaper',
      'x.blocked': 'Cannot build here — blocked. Tap near a green spot', 'x.water': 'Cannot build here — water. Tap near a green spot', 'x.occupied': 'Cannot build here — occupied. Tap near a green spot', 'x.pipe': 'Cannot build here — a pipe is already here. Pick an empty tile',
      'x.crossBuilding': 'The pipe would cross a building. Switch direction with ⇄ or move the end point', 'x.locked': 'This region is locked. Open it from the Regions button', 'x.nothing': 'Nothing new to build here. Drag somewhere else', 'x.nofree': 'All your oil is tied to contracts. Wait for them or produce more',
      'x.outside': 'Cannot build here — outside the world. Tap on land', 'x.edge': 'Cannot build here — partly outside the world. Move it inward', 'x.overlap': 'Cannot build here — overlaps existing structure. Move it slightly', 'x.noleak': 'No leak here, the pipe is fine',
      'p.more': 'More details ▾', 'p.less': 'Fewer details ▴',
      'co.well': 'Build a <b>well</b>: tap the glowing spot', 'co.pipe': 'Connect a <b>pipe</b>: choose Pipe, tap the <b>well</b> then the <b>tank</b>, then confirm', 'co.tank': 'Build a <b>tank</b> on the glowing spot, near the well',
      'co.link': 'Now <b>join the well to the tank</b>: choose Pipe, tap the well then the tank', 'co.wait': 'Oil is flowing to the tank… <b>wait a moment</b> while it fills', 'co.sell': 'The tank has oil! Open the <b>Market</b> and tap Sell',
      'co.done': 'Well done! First sale made. You run an oil company 🎉', 'co.skipped': 'Guide finished. Play freely', 'co.skip': 'Skip',
      's.paused': 'Game paused', 's.speedTo': 'Game speed {n}×', 'speedBtn': 'Speed'
    }
  };
  Object.assign(STR.ar, STR5.ar); Object.assign(STR.en, STR5.en);
  /* Phase 6 strings: network status, construction */
  const STR6 = {
    ar: {
      'p.net': 'الشبكة', 'p.inflow': 'يصل إليه', 'p.srcs': 'الآبار', 'st.building': 'قيد الإنشاء',
      'nw.to': 'متصل ← خزان {n} · {len} مربع', 'nw.limited': 'الأنبوب يمرر {cap}/د فقط', 'nw.building': 'قيد الإنشاء {n}%',
      'nw.nopipe': 'لا يوجد أنبوب. اسحب أنبوباً من البئر إلى خزان.', 'nw.nostorage': 'لا يوجد مسار متصل إلى خزان.', 'nw.full': 'كل الخزانات المتصلة ممتلئة.', 'nw.broken': 'البئر معطّل، أصلحه بالصيانة.', 'nw.depleted': 'نفد النفط من هذا البئر.',
      'nw.srcs': 'تغذيه {a} من {b} آبار متصلة', 'nw.nosrc': 'لا بئر متصل به',
      'pi.noWell': 'لا بئر متصل بهذا الأنبوب.', 'pi.noTank': 'لا يوجد مسار متصل إلى خزان.', 'pi.full': 'الخزان ممتلئ، التدفق متوقف.', 'pi.idle': 'متصل، لكن لا يتدفق نفط حالياً.', 'pi.atCap': 'يعمل بأقصى سعته. رقِّ الأنابيب لزيادة التدفق.',
      'pi.leak': 'تسرب: يضيع جزء من النفط. أصلحه.', 'pi.repair': 'قيد الإصلاح…', 'pi.building': 'قيد الإنشاء…', 'pi.ok': 'متصل ويعمل ← خزان {n}', 'pi.ok2': 'متصل ويعمل',
      'co.build': 'جارٍ البناء… انتظر <b>ثوانٍ</b> حتى يكتمل', 'e.building': 'ما زال قيد الإنشاء'
    },
    en: {
      'p.net': 'Network', 'p.inflow': 'Incoming', 'p.srcs': 'Wells', 'st.building': 'Under construction',
      'nw.to': 'Connected → Tank {n} · {len} tiles', 'nw.limited': 'pipe carries only {cap}/min', 'nw.building': 'Under construction {n}%',
      'nw.nopipe': 'No pipe. Drag a pipe from the well to a tank.', 'nw.nostorage': 'No connected path to a tank.', 'nw.full': 'Every connected tank is full.', 'nw.broken': 'The well is broken. Repair it with maintenance.', 'nw.depleted': 'This well has run dry.',
      'nw.srcs': 'Fed by {a} of {b} connected wells', 'nw.nosrc': 'No well is connected to it',
      'pi.noWell': 'No well is connected to this pipe.', 'pi.noTank': 'No connected path to a tank.', 'pi.full': 'The tank is full, flow has stopped.', 'pi.idle': 'Connected, but no oil is flowing right now.', 'pi.atCap': 'Running at full capacity. Upgrade the pipes for more flow.',
      'pi.leak': 'Leak: some oil is lost. Repair it.', 'pi.repair': 'Being repaired…', 'pi.building': 'Under construction…', 'pi.ok': 'Connected and flowing → Tank {n}', 'pi.ok2': 'Connected and flowing',
      'co.build': 'Building… wait a <b>few seconds</b> until it is finished', 'e.building': 'Still under construction'
    }
  };
  Object.assign(STR.ar, STR6.ar); Object.assign(STR.en, STR6.en);
  /* Phase 8 strings: pressure, pumps, valves */
  const STR7 = {
    ar: {
      'n.pump': 'محطة ضخ', 'n.pumpS': 'مضخة', 'h.pump': 'اضغط على <b>جزء مستقيم من الأنبوب</b> لوضع محطة ضخ: النفط يدخل من الخلف ويخرج من الأمام · {cost}', 'c.pump': 'بناء محطة ضخ {cost}',
      'd.pump': 'ترفع ضغط النفط في الأنابيب الطويلة', 'u.bar': 'بار', 'u.kw': 'ك.و', 'u.ms': 'م/ث',
      'e.pumpNeedsPipe': 'يجب وصلها بأنبوب', 'x.pumpNeedsPipe': 'يجب أن تتصل بأنبوب: ضعها على خط أنابيب مستقيم', 'e.pumpJunction': 'لا تُبنى على تقاطع', 'x.pumpJunction': 'لا تُبنى على تقاطع. اختر جزءاً مستقيماً من الأنبوب',
      'e.pumpNotStraight': 'ضعها على جزء مستقيم', 'x.pumpNotStraight': 'ضعها على جزء مستقيم من الأنبوب (ليس عند منعطف أو طرف)', 'e.pumpSpace': 'لا يمكن البناء هنا — يتداخل مع مبنى قائم', 'x.pumpSpace': 'لا يمكن البناء هنا — يتداخل مع مبنى قائم', 'e.pumpHere': 'لا يمكن البناء هنا', 'x.pumpHere': 'لا يمكن البناء هنا',
      'ps.running': 'تعمل', 'ps.maxed': 'بأقصى طاقتها', 'ps.standby': 'جاهزة (لا تدفق)', 'ps.idle': 'غير مستخدمة', 'ps.offline': 'متوقفة', 'ps.noInput': 'لا أنبوب دخل', 'ps.noOutput': 'لا أنبوب خرج', 'ps.building': 'قيد الإنشاء',
      'p.pump': 'محطة ضخ', 'p.boost': 'رفع الضغط', 'p.pflow': 'التدفق', 'p.pin': 'ضغط الدخل', 'p.pout': 'ضغط الخرج', 'p.power': 'الطاقة', 'p.eff': 'الكفاءة', 'p.dir': 'الاتجاه',
      'p.pumpOn': 'تشغيل', 'p.pumpOff': 'إيقاف', 'p.flipPump': 'عكس الاتجاه ⇄', 'p.inout': 'دخل ← خرج', 'p.powerV': '{kw} ك.و · {cost}/د',
      'p.resP': 'ضغط المكمن', 'p.whP': 'ضغط رأس البئر', 'p.pumpHelp': 'دعم المضخات', 'p.limit': 'ما يقيّد الإنتاج', 'lim.capacity': 'سعة الأنبوب', 'lim.pressure': 'الضغط غير كافٍ', 'lim.none': 'لا شيء',
      'p.back': 'الضغط الخلفي', 'p.prs': 'الضغط', 'p.vel': 'السرعة', 'p.loss': 'فقد الضغط', 'p.valve': 'صمام: {a}', 'p.valveNext': 'صمام: {a} ← {b}',
      'v.0': 'بدون', 'v.1': 'مفتوح', 'v.2': 'جزئي', 'v.3': 'مغلق', 'nw.pressure': 'ضغط {n} بار', 'nw.pressLim': 'الضغط لا يكفي: {n} بار مطلوب', 'p.transient': 'نبضة ضغط',
      't.pumpOn': 'تم تشغيل المضخة', 't.pumpOff': 'تم إيقاف المضخة', 't.valve': 'الصمام: {a}'
    },
    en: {
      'n.pump': 'Pump Station', 'n.pumpS': 'Pump', 'h.pump': 'Tap a <b>straight piece of pipe</b> to place a pump station: oil enters at the back and leaves at the front · {cost}', 'c.pump': 'Build Pump Station {cost}',
      'd.pump': 'Boosts oil pressure in long pipelines', 'u.bar': 'bar', 'u.kw': 'kW', 'u.ms': 'm/s',
      'e.pumpNeedsPipe': 'Must connect to a pipe', 'x.pumpNeedsPipe': 'Must connect to a pipe: place it on a straight pipeline', 'e.pumpJunction': 'Cannot be built on a junction', 'x.pumpJunction': 'Not on a junction. Pick a straight piece of pipe',
      'e.pumpNotStraight': 'Needs a straight pipe', 'x.pumpNotStraight': 'Place it on a straight piece of pipe (not at a bend or an end)', 'e.pumpSpace': 'Cannot build here — overlaps an existing structure', 'x.pumpSpace': 'Cannot build here — overlaps an existing structure', 'e.pumpHere': 'Cannot build here', 'x.pumpHere': 'Cannot build here',
      'ps.running': 'Running', 'ps.maxed': 'At full capacity', 'ps.standby': 'Ready (no flow)', 'ps.idle': 'Not in use', 'ps.offline': 'Offline', 'ps.noInput': 'No input pipe', 'ps.noOutput': 'No output pipe', 'ps.building': 'Under construction',
      'p.pump': 'Pump Station', 'p.boost': 'Pressure boost', 'p.pflow': 'Flow', 'p.pin': 'Input pressure', 'p.pout': 'Output pressure', 'p.power': 'Power', 'p.eff': 'Efficiency', 'p.dir': 'Direction',
      'p.pumpOn': 'Turn on', 'p.pumpOff': 'Turn off', 'p.flipPump': 'Reverse ⇄', 'p.inout': 'IN → OUT', 'p.powerV': '{kw} kW · {cost}/min',
      'p.resP': 'Reservoir pressure', 'p.whP': 'Well head pressure', 'p.pumpHelp': 'Pump support', 'p.limit': 'Limiting factor', 'lim.capacity': 'Pipe capacity', 'lim.pressure': 'Not enough pressure', 'lim.none': 'None',
      'p.back': 'Back-pressure', 'p.prs': 'Pressure', 'p.vel': 'Velocity', 'p.loss': 'Pressure loss', 'p.valve': 'Valve: {a}', 'p.valveNext': 'Valve: {a} → {b}',
      'v.0': 'None', 'v.1': 'OPEN', 'v.2': 'PARTIAL', 'v.3': 'CLOSED', 'nw.pressure': '{n} bar', 'nw.pressLim': 'Pressure too low: needs {n} bar', 'p.transient': 'Pressure surge',
      't.pumpOn': 'Pump turned on', 't.pumpOff': 'Pump turned off', 't.valve': 'Valve: {a}'
    }
  };
  Object.assign(STR.ar, STR7.ar); Object.assign(STR.en, STR7.en);
  // Phase 6: branches, junctions, graph
  Object.assign(STR.ar, {
    'e.crossPipe': 'تقاطع الأنابيب ليس وصلة', 'x.crossPipe': 'تقاطع الأنابيب ليس وصلة: انهِ الأنبوب على الأنبوب القائم لعمل وصلة T، أو غيّر مساره',
    'e.ambiguous': 'نهاية الأنبوب تلامس شبكتين معاً', 'x.ambiguous': 'حرّك نهاية الأنبوب لتلامس شبكة واحدة فقط (أو انهِه على الأنبوب الذي تريده)',
    'pv.tiles': '{n} قطعة', 'pv.t': 'وصلة T جديدة', 'pv.x': 'وصلة رباعية', 'pv.more': 'فرع إضافي', 'pv.toTank': 'إلى خزان', 'pv.toWell': 'من بئر', 'pv.toPump': 'إلى مضخة', 'pv.toPipe': 'يتصل بأنبوب', 'pv.free': 'نهاية حرة',
    'p.removeBranch': 'إزالة الفرع', 'p.removeBranchN': 'إزالة الفرع ({n} قطعة)', 'p.node': 'العقدة', 'nd.junction': 'وصلة · {n} فروع', 'nd.end': 'نهاية الخط', 'nd.seg': 'قسم أنبوب · {n} قطعة', 'nd.seg0': 'قسم أنبوب',
    'e.noRoute': 'لا يوجد مسار صالح', 'x.noRoute': 'لا يوجد مسار صالح: غيّر الوجهة أو أزل ما يسدّ الطريق', 'e.pumpSide': 'لا يمكن التوصيل من هذا الجانب', 'x.pumpSide': 'المضخة تتصل من مقدمتها ومؤخرتها فقط (النقطتان المضيئتان)',
    'pv.turns': '{n} زاوية', 'pv.detour': 'مسار بديل حول العائق',
    'e.junction': 'هذه وصلة: أزل الفروع من حولها', 't.removedBranch': 'تمت إزالة الفرع · {n} قطعة · +{refund}', 't.simplified': 'الوصلة صارت أنبوباً عادياً', 'log.removedBranch': 'إزالة فرع أنابيب ({n} قطعة)'
  });
  Object.assign(STR.en, {
    'e.crossPipe': 'Pipe crossing is not a junction', 'x.crossPipe': 'Pipe crossing is not a junction: end the pipe ON the existing one to make a T-junction, or change its path',
    'e.ambiguous': 'The pipe end touches two networks at once', 'x.ambiguous': 'Move the pipe end so it touches only one network (or end it on the pipe you want)',
    'pv.tiles': '{n} segments', 'pv.t': 'New T-junction', 'pv.x': '4-way junction', 'pv.more': 'Extra branch', 'pv.toTank': 'to tank', 'pv.toWell': 'from well', 'pv.toPump': 'to pump', 'pv.toPipe': 'joins a pipe', 'pv.free': 'free end',
    'p.removeBranch': 'Remove branch', 'p.removeBranchN': 'Remove branch ({n} segments)', 'p.node': 'Node', 'nd.junction': 'Junction · {n} branches', 'nd.end': 'Pipe end', 'nd.seg': 'Pipe section · {n} segments', 'nd.seg0': 'Pipe section',
    'e.noRoute': 'No valid route found', 'x.noRoute': 'No valid route found: change the destination or remove what blocks the way', 'e.pumpSide': 'Cannot connect to this side of the pump', 'x.pumpSide': 'A pump connects only at its back and front (the two glowing spots)',
    'pv.turns': '{n} corners', 'pv.detour': 'detour around an obstacle',
    'e.junction': 'This is a junction: remove the branches around it', 't.removedBranch': 'Branch removed · {n} segments · +{refund}', 't.simplified': 'The junction became a plain pipe', 'log.removedBranch': 'Removed pipe branch ({n} segments)'
  });
  // t('key', {values}): translated text. In Arabic, numbers and prices are isolated so they never get reordered.
  function t(key, vars) {
    let s = STR[prefs.lang][key]; if (s == null) s = STR.en[key]; if (s == null) return key;
    if (vars) s = s.replace(/\{(\w+)\}/g, (m, k) => {
      if (vars[k] == null) return m;
      const v = String(vars[k]);
      return prefs.lang === 'ar' && /[\d$]/.test(v) ? '⁦' + v + '⁩' : v;
    });
    return s;
  }
  const err = code => t('e.' + code);
  const help = code => { const k = 'x.' + code, v = t(k); return v === k ? err(code) : v; };   // says what to DO, not just what failed
  // toolbar / HUD icons: the supplied pictures replace the line icons (a symbol can hold an <image>)
  function applyArt() {
    if (!window.ART || !ART.spr) return;
    const map = { 'i-cash': 'i_coin', 'i-drop': 'i_oil', 'i-build': 'i_wrench', 'i-search': 'i_lens', 'i-well': 'wellS2', 'i-tank': 'tank1', 'i-pipe': 'pipeX' };
    for (const id in map) {
      const sy = document.getElementById(id), a = ART.spr[map[id]]; if (!sy || !a) continue;
      sy.innerHTML = '<image href="' + a.src + '" x="0" y="0" width="24" height="24" preserveAspectRatio="xMidYMid meet"/>';
      sy.dataset.art = '1';
    }
    if (ART.pump) { const sy = document.getElementById('i-pump'); if (sy) { sy.innerHTML = '<image href="' + ART.pump.x + '" x="0" y="0" width="24" height="24" preserveAspectRatio="xMidYMid meet"/>'; sy.dataset.art = '1'; } }
  }
  function applyI18n() {
    document.documentElement.lang = prefs.lang;
    $('#app').classList.toggle('rtl', prefs.lang === 'ar');
    $$('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
    $$('[data-i18n-label]').forEach(el => { el.setAttribute('aria-label', t(el.dataset.i18nLabel)); });
    $$('[data-cost]').forEach(el => { const k = el.dataset.cost; el.textContent = k === 'explore' ? t('from', { c: money(CFG.REGIONS[0].explore) }) : k === 'well' ? t('from', { c: money(CFG.WELL_KINDS.small.cost) }) : money(CFG.COST[k]) + ((k === 'pipe' || k === 'pipeMain') ? ' ' + t('perTile') : ''); });
    $$('#kinds button').forEach(el => { const k = el.dataset.k; el.innerHTML = t('k.' + k) + '<small>' + money(CFG.WELL_KINDS[k].cost) + '</small>'; });
    const pb = $('[data-tool="pump"]'); if (pb) pb.title = t('n.pump') + ' · ' + t('d.pump');
    $('#st-reset-note').textContent = t('s.resetNote', { cash: money(CFG.START_CASH) });
  }

  const game = new Game();
  const ui = { tab: 'trade', wellKind: 'small', pipeType: 0, menu: false, tool: 'select', hover: null, pipeStart: null, pending: null, flip: false, sel: null, speed: 1, ptype: 'mouse', erase: null, removeArm: 0, reset: 0 };
  /* The one camera. x/y = the world point at the centre of the canvas, z = zoom (screen px per world px). Limits are configured here only:
     MIN_Z / MAX_Z bound the zoom, EDGE is how far past the world's outline the view may poke (a sliver of sea, never a screenful). */
  const CAM = { MIN_Z: 0.28, MAX_Z: 2, EDGE: 48, START_Z: [0.6, 1.15] };
  const cam = { x: 0, y: 0, z: 0.8, minZoom: CAM.MIN_Z, maxZoom: CAM.MAX_Z };

  /* ================= Save / load ================= */
  function save() {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify({ game: game.serialize(), cam, speed: ui.speed })); } catch (e) { /* storage may be unavailable */ }
  }
  let loaded = false;
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      const d = JSON.parse(raw);
      game.load(d.game);
      if (d.cam) { const legacy = !d.game || d.game.w !== 2; cam.x = d.cam.x + (legacy ? (CFG.WORLD.OX - CFG.WORLD.OY) * 32 : 0); cam.y = d.cam.y + (legacy ? (CFG.WORLD.OX + CFG.WORLD.OY) * 16 : 0); cam.z = d.cam.z; }
      if (typeof d.speed === 'number') ui.speed = d.speed;
      loaded = true;
    }
  } catch (e) { game.reset(); }

  /* ================= Terrain (pre-rendered once) ================= */
  function hash(x, y) {
    let h = Math.imul(x, 374761393) ^ Math.imul(y, 668265263) ^ 0x5bd1e995;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
  }
  function vnoise(x, y) {
    const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
    const s = t => t * t * (3 - 2 * t);
    const a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1);
    return a + (b - a) * s(xf) + (c - a) * s(yf) + (a - b - c + d) * s(xf) * s(yf);
  }
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  const rgb = c => 'rgb(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ')';

  /* The ground is drawn in chunks of CH x CH tiles, created only when they come into view and kept in a small cache
     (the world is 10x bigger: one huge pre-rendered image would not fit in phone memory). A tiny overview image of the whole world is the minimap
     and the placeholder shown for a chunk that has not been drawn yet. */
  const CH = 16, CWN = Math.ceil(W / CH), CHN = Math.ceil(H / CH);
  const OXY = CFG.WORLD, LX = x => x - OXY.OX, LY = y => y - OXY.OY;      // noise is sampled in old-map coordinates so the old ground looks exactly as before
  const TERR = { minX: -H * 32 - 40, minY: -12, w: (W + H) * 32 + 80, h: (W + H) * 16 + 64, mini: null, miniRes: 1 / 16, cache: new Map(), bytes: 0, budget: 56e6 };
  const SAND_A = [236, 200, 134], SAND_B = [208, 160, 86], ROCKY = [186, 140, 96], BEACH = [243, 223, 170];
  function groundColor(x, y, detail) {
    const k = idx(x, y), lx = LX(x), ly = LY(y), co = game.map.coast[k];
    if (game.map.water[k]) {
      const depth = clamp(co / 3, 0, 1);
      return mix(mix([60, 190, 205], [22, 112, 160], depth), [30, 130, 175], detail ? vnoise(lx * .5, ly * .5) * .5 : .25);
    }
    const n = detail ? vnoise(lx * .1, ly * .1) * .65 + vnoise(lx * .45, ly * .45) * .25 + hash(lx, ly) * .1 : vnoise(lx * .1, ly * .1);
    let col = mix(SAND_A, SAND_B, n);
    if (co > -1.6) col = mix(col, BEACH, .7);
    const r = OliCore.rockyAt(x, y); if (r > 0) col = mix(col, ROCKY, r);
    return col;
  }
  function buildMini() {
    const res = TERR.miniRes, cv = document.createElement('canvas');
    cv.width = Math.ceil(TERR.w * res); cv.height = Math.ceil(TERR.h * res);
    const g = cv.getContext('2d'); g.scale(res, res); g.translate(-TERR.minX, -TERR.minY);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const cx = (x - y) * 32, top = (x + y) * 16;
      g.fillStyle = rgb(groundColor(x, y, false));
      g.beginPath(); g.moveTo(cx, top); g.lineTo(cx + 33, top + 16); g.lineTo(cx, top + 33); g.lineTo(cx - 33, top + 16); g.closePath(); g.fill();
    }
    TERR.mini = cv;
  }
  function chunkBox(cx, cy) {
    const x0 = cx * CH, y0 = cy * CH, x1 = Math.min(W, x0 + CH) - 1, y1 = Math.min(H, y0 + CH) - 1;
    const minX = (x0 - y1) * 32 - 34, maxX = (x1 - y0) * 32 + 34, minY = (x0 + y0) * 16 - 2, maxY = (x1 + y1) * 16 + 32 + 22;
    return { x0, y0, x1, y1, minX, minY, w: maxX - minX, h: maxY - minY };
  }
  function buildChunk(cx, cy, res) {
    const B = chunkBox(cx, cy), cv = document.createElement('canvas');
    cv.width = Math.ceil(B.w * res); cv.height = Math.ceil(B.h * res);
    const g = cv.getContext('2d'); g.scale(res, res); g.translate(-B.minX, -B.minY);
    const path = (x, y) => { const px = (x - y) * 32, top = (x + y) * 16; g.beginPath(); g.moveTo(px, top); g.lineTo(px + 32, top + 16); g.lineTo(px, top + 32); g.lineTo(px - 32, top + 16); g.closePath(); };
    const fine = res >= .9, sandI = sprImg('sand'), shoreI = sprImg('shore'), tex = !!(sandI && shoreI) && fine;
    const tile = (g, im, px, top, fx, fy) => {          // one tile-sized picture, optionally mirrored (the 4 mirrors give the 4 shoreline directions)
      g.drawImage(im, fx ? px + 32.5 : px - 32.5, fy ? top + 32.5 : top - .5, fx ? -65 : 65, fy ? -33 : 33);      // a negative size mirrors the picture
    };
    cv.tex = tex;
    for (let s = B.x0 + B.y0; s <= B.x1 + B.y1; s++) {
      for (let y = B.y0; y <= B.y1; y++) {
        const x = s - y; if (x < B.x0 || x > B.x1) continue;
        const k = idx(x, y), water = game.map.water[k], lx = LX(x), ly = LY(y);
        path(x, y); g.fillStyle = rgb(groundColor(x, y, true)); g.fill();
        if (!fine) continue;
        if (tex) {                                     // supplied art: sand grain on land, a foaming shoreline where water meets land
          const px0 = (x - y) * 32, top0 = (x + y) * 16, hv = hash(lx * 3 + 1, ly * 5 + 2);
          if (!water) { g.globalAlpha = .5; tile(g, sandI, px0, top0, hv > .5, hv * 7 % 1 > .5); g.globalAlpha = 1; }
          else {
            const lands = [[-1, 0], [0, -1], [0, 1], [1, 0]].filter(d => inb(x + d[0], y + d[1]) && !game.map.water[idx(x + d[0], y + d[1])]);
            if (lands.length === 1) { const d = lands[0]; tile(g, shoreI, px0, top0, d[0] === 0 ? d[1] < 0 : d[0] > 0, d[1] > 0 || d[0] > 0); }
          }
        }
        g.strokeStyle = water ? 'rgba(255,255,255,.06)' : 'rgba(120,80,30,.045)'; g.lineWidth = 1; g.stroke();
        const px = (x - y) * 32, py = (x + y) * 16 + 16;
        if (water) {
          g.strokeStyle = 'rgba(255,255,255,.22)'; g.lineWidth = 1.2;
          if (hash(lx, ly) > .55) { const ox = (hash(ly, lx) - .5) * 24; g.beginPath(); g.moveTo(px + ox - 8, py); g.quadraticCurveTo(px + ox, py - 3, px + ox + 8, py); g.stroke(); }
        } else {
          for (let i = 0; i < 3; i++) {
            const qx = px + (hash(lx * 7 + i, ly * 3) - .5) * 40, qy = py + (hash(lx * 3, ly * 7 + i) - .5) * 18;
            g.fillStyle = hash(lx + i, ly * 5) > .5 ? 'rgba(255,240,200,.35)' : 'rgba(150,100,40,.25)';
            g.fillRect(qx, qy, 2, 1.4);
          }
        }
      }
    }
    if (B.y1 === H - 1) for (let x = B.x0; x <= B.x1; x++) {        // front-left cliff of the world edge
      const y = H - 1, px = (x - y) * 32, top = (x + y) * 16;
      g.fillStyle = game.map.water[idx(x, y)] ? '#0b6a8f' : '#a8743c';
      g.beginPath(); g.moveTo(px - 32, top + 16); g.lineTo(px, top + 32); g.lineTo(px, top + 48); g.lineTo(px - 32, top + 32); g.closePath(); g.fill();
    }
    if (B.x1 === W - 1) for (let y = B.y0; y <= B.y1; y++) {        // front-right cliff
      const x = W - 1, px = (x - y) * 32, top = (x + y) * 16;
      g.fillStyle = '#8a5a2c';
      g.beginPath(); g.moveTo(px, top + 32); g.lineTo(px + 32, top + 16); g.lineTo(px + 32, top + 32); g.lineTo(px, top + 48); g.closePath(); g.fill();
    }
    return { cv, B, res, tex, bytes: cv.width * cv.height * 4 };
  }
  // Draws the ground inside the current view. At most `maxBuild` new chunks are drawn per frame, the rest show the overview until ready.
  function drawGround(x0, y0, x1, y1, tier, maxBuild) {
    const res = tier ? .5 : TERR_RES, todo = [], missing = [];
    for (let cy = 0; cy < CHN; cy++) for (let cx = 0; cx < CWN; cx++) {
      const B = chunkBox(cx, cy);
      if (B.minX > x1 || B.minX + B.w < x0 || B.minY > y1 || B.minY + B.h < y0) continue;
      const key = cx + ',' + cy + ',' + tier; let c = TERR.cache.get(key);
      if (c && !c.tex && !tier && sprImg('sand') && sprImg('shore') && c.res >= .9) { TERR.bytes -= c.bytes; TERR.cache.delete(key); c = null; }   // built before the art was ready
      if (c) { TERR.cache.delete(key); TERR.cache.set(key, c); todo.push(c); continue; }
      if (todo.length + missing.length >= 40) continue;
      missing.push([cx, cy, key, B]);
    }
    let built = 0;
    for (const m of missing) {                      // a few new chunks per frame; the overview shows through until they exist
      if (built >= maxBuild) break;
      const c = buildChunk(m[0], m[1], res); built++; TERR.cache.set(m[2], c); TERR.bytes += c.bytes; todo.push(c);
      while (TERR.bytes > TERR.budget && TERR.cache.size > 1) { const k0 = TERR.cache.keys().next().value; if (k0 === m[2]) break; TERR.bytes -= TERR.cache.get(k0).bytes; TERR.cache.delete(k0); }
    }
    ctx.imageSmoothingQuality = 'low';
    if (missing.length > built) ctx.drawImage(TERR.mini, TERR.minX, TERR.minY, TERR.w, TERR.h);      // only while some chunk is still missing
    for (const c of todo) ctx.drawImage(c.cv, c.B.minX, c.B.minY, c.B.w, c.B.h);
    ctx.imageSmoothingQuality = 'high';
    return built;
  }
  let TERR_RES = 1;
  function buildTerrain() { TERR_RES = Math.min(innerWidth, innerHeight) < 600 ? 1 : 1.5; buildMini(); }

  /* ================= Canvas / camera ================= */
  const cv = $('#view'), ctx = cv.getContext('2d');
  const mini = $('#mini'), mctx = mini.getContext('2d');
  let vw = 0, vh = 0, dpr = 1, dprCap = 2, bgGrad = null;   // dprCap drops automatically on slow devices
  function resize() {
    dpr = Math.min(dprCap, window.devicePixelRatio || 1);
    const r = cv.getBoundingClientRect(); vw = r.width; vh = r.height;
    cv.width = Math.round(vw * dpr); cv.height = Math.round(vh * dpr);
    bgGrad = ctx.createLinearGradient(0, 0, 0, cv.height);
    bgGrad.addColorStop(0, '#12749a'); bgGrad.addColorStop(1, '#093756');
    const mr = mini.getBoundingClientRect();
    mini.width = Math.round(mr.width * dpr); mini.height = Math.round(mr.height * dpr);
    drawChart();
  }
  /* Bounds are computed from world size + viewport size + zoom, never hard-coded for one zoom level.
     The world is a diamond in screen space; its bounding box is BOX. The view centre stays inside the diamond, and the whole view stays
     inside BOX (+EDGE): when the view is bigger than the box on an axis it is centred on that axis instead. */
  const BOX = { minX: -H * 32, maxX: W * 32, minY: 0, maxY: (W + H) * 16 };
  function zoomLimits() {
    const fit = Math.max(vw / (BOX.maxX - BOX.minX + 2 * CAM.EDGE), vh / (BOX.maxY - BOX.minY + 2 * CAM.EDGE));   // never zoom out past the point where the world no longer fills the view
    return [Math.min(Math.max(CAM.MIN_Z, fit), CAM.MAX_Z), CAM.MAX_Z];
  }
  function fitView(x, y, z) {                                     // pure: the nearest legal camera for (x, y, z)
    const [zmin, zmax] = zoomLimits(); z = clamp(z, zmin, zmax);
    const u = clamp((x / 32 + y / 16) / 2, 0, W), v = clamp((y / 16 - x / 32) / 2, 0, H); x = (u - v) * 32; y = (u + v) * 16;
    const hw = vw / 2 / z, hh = vh / 2 / z, lx = BOX.minX + hw - CAM.EDGE, hx = BOX.maxX - hw + CAM.EDGE, ly = BOX.minY + hh - CAM.EDGE, hy = BOX.maxY - hh + CAM.EDGE;
    x = lx > hx ? (BOX.minX + BOX.maxX) / 2 : clamp(x, lx, hx); y = ly > hy ? (BOX.minY + BOX.maxY) / 2 : clamp(y, ly, hy);
    return { x, y, z };
  }
  function clampCam() {
    if (!vw || !vh) return;
    const f = fitView(cam.x, cam.y, cam.z); cam.x = f.x; cam.y = f.y; cam.z = f.z;
    const zl = zoomLimits(); cam.minZoom = zl[0]; cam.maxZoom = zl[1];
  }
  /* THE grid <-> world mapping (buildings, preview, terrain, pipes, picking, camera and touch all go through it).
     Grid corner coordinates (u, v): cell (x, y) spans u in [x, x+1] and v in [y, y+1]; world = ((u - v) * HW, (u + v) * HH). */
  const GRID = { HW: 32, HH: 16 };
  const gridToWorld = (u, v) => [(u - v) * GRID.HW, (u + v) * GRID.HH];
  const worldToGrid = (wx, wy) => [(wx / GRID.HW + wy / GRID.HH) / 2, (wy / GRID.HH - wx / GRID.HW) / 2];
  const s2w = (sx, sy) => ({ x: (sx - vw / 2) / cam.z + cam.x, y: (sy - vh / 2) / cam.z + cam.y });
  const w2s = (wx, wy) => ({ x: (wx - cam.x) * cam.z + vw / 2, y: (wy - cam.y) * cam.z + vh / 2 });
  function cellAt(sx, sy) {
    const w = s2w(sx, sy), g = worldToGrid(w.x, w.y);
    return { x: Math.floor(g[0]), y: Math.floor(g[1]) };
  }
  const inb = (x, y) => x >= 0 && y >= 0 && x < W && y < H;
  const cc = (x, y) => gridToWorld(x + .5, y + .5);          // world centre of tile (x, y)
  const footprintCenter = (type, x, y) => { const f = game.footprintOf(type); return gridToWorld(x + f[0] / 2, y + f[1] / 2); };   // world centre of a building's whole footprint

  /* ================= Drawing helpers ================= */
  const DIRS = [[1, 0, 32, 16], [-1, 0, -32, -16], [0, 1, -32, 16], [0, -1, 32, -16]]; // dx, dy, screen vector
  function diamond(g, cx, cy, rx, ry) { g.beginPath(); g.moveTo(cx, cy - ry); g.lineTo(cx + rx, cy); g.lineTo(cx, cy + ry); g.lineTo(cx - rx, cy); g.closePath(); }
  function shade(g, cx, cy, rx, ry, a) { g.fillStyle = 'rgba(60,30,0,' + a + ')'; g.beginPath(); g.ellipse(cx + 6, cy + 3, rx, ry, 0, 0, 6.2832); g.fill(); }

  /* ---- Supplied sprites (art.js): decoded once; every draw falls back to the old vector art until the image is ready ---- */
  const SPR = {};
  function sprImg(k) { let i = SPR[k]; if (!i && window.ART && ART.spr && ART.spr[k]) { i = SPR[k] = new Image(); i.src = ART.spr[k].src; } return i && i.complete && i.naturalWidth ? i : null; }
  if (window.ART && ART.spr) for (const k in ART.spr) sprImg(k);
  // draws sprite k with width dw; (ax, ay) is the point of the sprite (as a fraction of its size) that lands on (cx, cy)
  function sprite(g, k, cx, cy, dw, ax, ay, flip) {
    const i = sprImg(k); if (!i) return false;
    const dh = dw * i.naturalHeight / i.naturalWidth;
    if (flip) { g.save(); g.translate(cx, cy); g.scale(-1, 1); g.drawImage(i, -ax * dw, -ay * dh, dw, dh); g.restore(); }
    else g.drawImage(i, cx - ax * dw, cy - ay * dh, dw, dh);
    return true;
  }
  function drawPalm(g, cx, cy, v, t) {
    const sway = Math.sin(t * 1.3 + v * 20) * .018;
    g.save(); g.translate(cx, cy + 6); g.transform(1, 0, sway, 1, 0, 0);
    const ok = sprite(g, 'palm', 0, 0, 78 + v * 12, .5, .86, v > .5);
    g.restore();
    if (ok) return;
    shade(g, cx, cy, 16, 7, .18);
    const lean = (v - .5) * 16, sw = sway * 120;
    const tx = cx + lean + sw * .3, ty = cy - 38;
    g.strokeStyle = '#7b5632'; g.lineWidth = 4.2; g.lineCap = 'round';
    g.beginPath(); g.moveTo(cx, cy); g.quadraticCurveTo(cx + lean * .2, cy - 20, tx, ty); g.stroke();
    for (let i = 0; i < 7; i++) {
      const a = i / 7 * 6.2832 + v * 3, lx = Math.cos(a) * 24, ly = Math.sin(a) * 9;
      g.fillStyle = i % 2 ? '#2d8a4b' : '#3ea25d';
      g.beginPath(); g.moveTo(tx, ty);
      g.quadraticCurveTo(tx + lx * .55 + sw, ty - 13 + ly * .3, tx + lx + sw, ty + 7 + ly * .7);
      g.quadraticCurveTo(tx + lx * .5, ty - 3 + ly * .2, tx, ty); g.fill();
    }
    g.fillStyle = '#6b4a2a'; g.beginPath(); g.arc(tx - 2, ty + 2, 2.4, 0, 6.2832); g.arc(tx + 3, ty + 3, 2.4, 0, 6.2832); g.fill();
  }
  function drawRock(g, cx, cy, s, v) {
    if (sprite(g, 'rocks', cx, cy + 4, s * 3.9, .5, .72, v > .5)) return;
    shade(g, cx, cy, s * 1.1, s * .5, .2);
    const p = [[-.95, 0], [-.75, -.7], [-.2, -1.1], [.5, -.95], [.95, -.2], [.7, .1], [-.3, .25]].map(q => [cx + q[0] * s * (0.9 + v * .25), cy + q[1] * s * .9]);
    const gr = g.createLinearGradient(cx - s, cy - s, cx + s, cy);
    gr.addColorStop(0, '#c9a47a'); gr.addColorStop(1, '#8e6a48');
    g.fillStyle = gr; g.beginPath(); p.forEach((q, i) => i ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1])); g.closePath(); g.fill();
    g.fillStyle = 'rgba(70,40,15,.28)'; g.beginPath(); g.moveTo(p[2][0], p[2][1]); g.lineTo(p[3][0], p[3][1]); g.lineTo(p[4][0], p[4][1]); g.lineTo(p[5][0], p[5][1]); g.lineTo(p[6][0], p[6][1]); g.closePath(); g.fill();
    g.strokeStyle = 'rgba(60,35,15,.35)'; g.lineWidth = 1; g.stroke();
  }
  function drawShrub(g, cx, cy, v) {
    g.fillStyle = '#7f9a4a';
    for (let i = 0; i < 4; i++) { g.beginPath(); g.ellipse(cx + (i - 1.5) * 4, cy - 3 - (i % 2) * 2, 5, 4, 0, 0, 6.2832); g.fill(); }
    g.fillStyle = '#a3b866'; g.beginPath(); g.ellipse(cx - 2, cy - 6, 3, 2, 0, 0, 6.2832); g.fill();
  }


  /* ================= Animation state =================
     Everything that moves is driven by the real simulation: pump speed by a well's output, pipe flow by the
     network's output, tank level by the stored oil. Nothing here changes the game rules. */
  const anim = { wells: new Map(), tanks: new Map(), born: new Map(), cons: new Map(), dust: new Map(), fx: [], seenPipe: new Uint8Array(W * H), pr: new Float32Array(W * H), pph: new Float32Array(W * H), seenB: new Set(), primed: false };
  const BUILD_T = .55;                                         // seconds a new object takes to appear
  const easeBack = p => { const c1 = 1.9; return 1 + (c1 + 1) * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); };
  function wellAnim(b) { let a = anim.wells.get(b.id); if (!a) { a = { ph: b.id * 1.7, spd: 0, amp: 0 }; anim.wells.set(b.id, a); } return a; }
  function tankAnim(b) { let a = anim.tanks.get(b.id); if (!a) { a = { f: clamp(b.amt / game.tankCap(b), 0, 1), w: b.id * 2.3, full: 0, t: 0, was: false }; anim.tanks.set(b.id, a); } return a; }
  function spawnFx(x, y, kind, delay) { anim.fx.push({ x, y, kind, t0: tNow + (delay || 0) }); if (anim.fx.length > 40) anim.fx.shift(); }

  // Called once per frame. real = wall-clock seconds, ad = animation seconds (0 while the game is paused).
  function updateAnim(real, ad) {
    // new objects -> construction animation (the first call only records what already exists, e.g. after loading a save)
    let n = 0;
    for (let k = 0; k < game.pipe.length; k++) {
      const has = game.pipe[k];
      if (has && !anim.seenPipe[k]) {
        anim.seenPipe[k] = 1;
        if (anim.primed) { const d = Math.max(0, (game.pipeReady[k] - game.s.time) / Math.max(.5, ui.speed)); anim.born.set('p' + k, tNow + d); spawnFx(k % W, (k / W) | 0, 'pipe', d); n++; }
      } else if (!has && anim.seenPipe[k]) { anim.seenPipe[k] = 0; anim.born.delete('p' + k); anim.pr[k] = 0; }
      // oil particles: speed and density follow the REAL flow in this tile (flow / capacity), smoothed; the simulation decides, the animation only shows it
      if (has) {
        const lvl = Math.max(1, game.pipeLvl[k]), target = game.net.live[k] === 1 ? clamp((game.net.flowK[k] || 0) / (CFG.PIPE.CAP[lvl - 1] * (game.valve[k] ? Math.max(.05, game.valvePos[k]) : 1)), 0, 1) : 0;
        let r = anim.pr[k]; r += (target - r) * Math.min(1, real * 3); if (r < .004 && target === 0) r = 0; anim.pr[k] = r;
        if (r > 0) anim.pph[k] = (anim.pph[k] + (.22 + 1.05 * r) * CFG.PIPE.SPEED[lvl - 1] * ad) % 1;
      }
    }
    const live = new Set();
    for (const b of game.buildings) {
      live.add(b.id);
      const building = b.ready > game.s.time;
      if (!anim.seenB.has(b.id)) { anim.seenB.add(b.id); if (building) anim.cons.set(b.id, tNow); if (anim.primed) { if (!building) anim.born.set('b' + b.id, tNow); spawnFx(b.x, b.y, b.type); } }
      else if (building) { anim.cons.set(b.id, anim.cons.get(b.id) || tNow); const last = anim.dust.get(b.id) || 0; if (tNow - last > .9) { anim.dust.set(b.id, tNow); spawnFx(b.x, b.y, 'pipe'); } }
      else if (anim.cons.has(b.id)) { anim.cons.delete(b.id); anim.dust.delete(b.id); anim.born.set('b' + b.id, tNow); spawnFx(b.x, b.y, b.type === 'tank' ? 'sale' : 'repair'); }
    }
    for (const id of anim.seenB) if (!live.has(id)) { anim.seenB.delete(id); anim.born.delete('b' + id); anim.wells.delete(id); anim.tanks.delete(id); anim.cons.delete(id); anim.dust.delete(id); }
    anim.primed = true;
    for (const [key, t0] of anim.born) if (tNow - t0 > BUILD_T + .1) anim.born.delete(key);   // never keep entries for objects that were off screen
    for (let i = anim.fx.length - 1; i >= 0; i--) if (tNow - anim.fx[i].t0 > .95) anim.fx.splice(i, 1);

    // pump jacks: speed follows the well's real output (bbl/min); smooth start and stop
    for (const b of game.buildings) {
      if (b.type === 'well') {
        const a = wellAnim(b), out = b.out || 0;
        const target = out > .01 ? 1.5 + 2.1 * clamp(out / 40, 0, 1) : 0;          // rad/s
        a.spd += (target - a.spd) * Math.min(1, real * 2.5);
        if (a.spd < .01 && target === 0) a.spd = 0;
        a.ph += a.spd * ad;
        a.amp = clamp(a.spd / 1.5, 0, 1);
      } else if (b.type === 'tank') {
        const a = tankAnim(b), f = clamp(b.amt / game.tankCap(b), 0, 1);
        a.f += (f - a.f) * Math.min(1, real * 3);                                    // level eases to the real inventory
        if (Math.abs(f - a.f) < .0006) a.f = f;
        a.w += ad * 2.4; a.t += real;
        a.full += ((f >= .985 ? 1 : 0) - a.full) * Math.min(1, real * 6);
        if (f >= .995 && !a.was) { a.was = true; if (anim.primed) toast(t('t.tankFull'), 'info'); }
        else if (f < .9) a.was = false;
      }
    }
    // pipe networks: particle speed follows the oil actually produced into that network
    for (const comp of game.net.comps) {
      let rate = 0; for (const w of comp.wells) rate += w.out || 0;
      const target = comp.flow > 0 && rate > 0 ? (.35 + .9 * Math.min(1, rate / Math.max(1, comp.cap))) * (comp.speed || 1) * (1 - .3 * Math.min(1, comp.leaks || 0)) : 0;
      comp.spd = (comp.spd || 0) + (target - (comp.spd || 0)) * Math.min(1, real * 3);
      if (comp.spd < .01 && target === 0) comp.spd = 0;
      comp.ph = (comp.ph || 0) + comp.spd * ad;
    }
  }

  // A building that is still being built: rises out of the ground with a growing opacity and a real progress bar (game.buildProgress).
  function underConstruction(b, cx, cy, fn) {
    return g => {
      const p = game.buildProgress(b), e = easeBack(Math.min(1, p));
      g.save(); g.translate(cx, cy); g.scale(.86 + .14 * Math.min(1, e), Math.max(.2, .35 + .65 * p)); g.translate(-cx, -cy); g.globalAlpha = .38 + .5 * p; fn(g); g.restore();
      const big = b.type === 'tank', bx = cx, by = cy - (big ? 70 : 78);
      g.fillStyle = 'rgba(10,20,32,.85)'; g.beginPath(); g.roundRect(bx - 28, by - 5, 56, 10, 5); g.fill();
      g.fillStyle = '#ffb41f'; g.beginPath(); g.roundRect(bx - 26, by - 3, 52 * p, 6, 3); g.fill();
      g.strokeStyle = 'rgba(255,180,31,.8)'; g.setLineDash([6, 5]); g.lineWidth = 2; g.beginPath(); g.ellipse(cx, cy + 4, big ? 60 : 36, big ? 30 : 17, 0, 0, 6.2832); g.stroke(); g.setLineDash([]);
    };
  }

  // Construction pop-in. Returns false (draw normally), 'hide' (waiting its turn) or true (a save() was pushed).
  function popBegin(g, key, cx, cy) {
    const t0 = anim.born.get(key); if (t0 === undefined) return false;
    const age = tNow - t0;
    if (age < 0) return 'hide';
    if (age >= BUILD_T) { anim.born.delete(key); return false; }
    const p = age / BUILD_T, e = easeBack(p);
    g.save(); g.translate(cx, cy); g.scale(.78 + .22 * e, Math.max(.03, e)); g.translate(-cx, -cy); g.globalAlpha = Math.min(1, p * 2.6);
    return true;
  }
  const popped = (key, cx, cy, fn) => g => { const s = popBegin(g, key, cx, cy); if (s === 'hide') return; fn(g); if (s) g.restore(); };

  // Dust ring + puffs where something was just built.
  function drawFx() {
    for (const f of anim.fx) {
      const age = tNow - f.t0; if (age < 0) continue;
      const disc = f.kind === 'discover', good = f.kind === 'repair' || f.kind === 'sale';
      const p = clamp(age / (disc ? 1.3 : .85), 0, 1), big = f.kind === 'tank' || f.kind === 'sale', pipe = f.kind === 'pipe' || f.kind === 'repair';
      const cx = (f.x - f.y) * 32, cy = big ? (f.x + f.y + 2) * 16 : (f.x + f.y) * 16 + 16;
      const rx = (disc ? 96 : big ? 62 : pipe ? 24 : 34) * (.35 + .65 * p), ry = rx / 2, rgb = disc ? '255,214,90' : good ? '70,220,130' : '255,196,60';
      if (disc || good) {                                        // sparks rising: a discovery / a sale / a repair should feel rewarding
        for (let i = 0; i < (disc ? 10 : 6); i++) {
          const a = i * 2.4 + f.x, rr = (disc ? 70 : 34) * Math.min(1, p * 1.4) * (.5 + (i % 3) * .25);
          ctx.fillStyle = 'rgba(' + rgb + ',' + (.9 * (1 - p)).toFixed(3) + ')'; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * rr, cy - p * (disc ? 70 : 46) * (.6 + (i % 4) * .15) + Math.sin(a) * rr * .3, 3.2 * (1 - p * .6), 0, 6.2832); ctx.fill();
        }
      }
      ctx.strokeStyle = 'rgba(' + rgb + ',' + (.85 * (1 - p)).toFixed(3) + ')'; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.ellipse(cx, cy + 4, rx, ry, 0, 0, 6.2832); ctx.stroke();
      const n = disc || good ? 0 : pipe ? 4 : 8;
      for (let i = 0; i < n; i++) {
        const a = i / n * 6.2832 + .4, d = (big ? 52 : pipe ? 18 : 30) * Math.min(1, p * 1.6);
        ctx.fillStyle = 'rgba(214,178,122,' + (.5 * (1 - p)).toFixed(3) + ')';
        ctx.beginPath(); ctx.arc(cx + Math.cos(a) * d, cy + 4 + Math.sin(a) * d * .5 - p * 12, (pipe ? 3 : 5) + p * (pipe ? 4 : 8), 0, 6.2832); ctx.fill();
      }
    }
  }

  function drawPipe(g, x, y, k, t) {
    const [cx, cy0] = cc(x, y), cy = cy0 - 5, net = game.net, type = net.type, pmain = game.pipeType[k] === 1, pw = pmain ? 1.28 : .92;
    const nx = net.fnext[k], fk = net.flowK[k] || 0, ratio = anim.pr[k];
    const flowing = ratio > .015 && nx >= 0 && fk > .02, ga = flowing ? clamp(.35 + ratio * 1.2, .35, 1) : 0;
    const conn = [], vm = game.visualMask(k);                           // the SAME link rule the network graph and the solver use (core.visualMask)
    for (let d = 0; d < 4; d++) if ((vm >> d) & 1) conn.push(DIRS[d]);
    // supplied art: straight runs, the +x/+y elbow and valves are sprites; the other junctions keep the drawn pipe (same colours)
    const vs = game.valve[k], isX = conn.length === 2 && conn[0][1] === 0 && conn[1][1] === 0, isY = conn.length === 2 && conn[0][0] === 0 && conn[1][0] === 0;
    const isEl = conn.length === 2 && !isX && !isY && conn.some(d => d[0] === 1) && conn.some(d => d[1] === 1);
    let art = false;
    if (isX || isY) art = vs ? sprite(g, 'pipeTee', cx, cy0 + 8, 62 * pw, .5, .72, isY) : sprite(g, isX ? 'pipeX' : 'pipeY', cx, cy0 + 8, 60 * pw, .5, .64);
    else if (isEl) art = sprite(g, 'pipeElbow', cx, cy0 + 8, 62 * pw, .5, .62);
    if (art) {
      if (vs) { const c = vs === 1 ? '#2fd27a' : vs === 2 ? '#ffb41f' : '#ff5a4f'; g.fillStyle = c; g.strokeStyle = 'rgba(10,20,32,.9)'; g.lineWidth = 1.2; g.beginPath(); g.arc(cx + (isY ? 10 : -10), cy0 - 26, 3.4, 0, 6.2832); g.fill(); g.stroke(); }
    } else {
    g.fillStyle = 'rgba(60,30,0,.16)'; g.beginPath(); g.ellipse(cx + 3, cy0 + 1, 15, 7, 0, 0, 6.2832); g.fill();
    const seg = (w, col, oy) => {
      g.strokeStyle = col; g.lineWidth = w; g.lineCap = 'butt'; g.beginPath();
      for (const d of conn) { g.moveTo(cx, cy + oy); g.lineTo(cx + d[2] / 2, cy + d[3] / 2 + oy); }
      g.stroke();
    };
    seg(15 * pw, '#23282e', 0); seg(11 * pw, '#4b535c', 0);
    if (ga > 0) seg(6 * pw, 'rgba(255,160,20,' + (.5 * ga).toFixed(3) + ')', 0);   // oil visible inside a working pipe
    seg(3.2 * pw, '#8e98a3', -3.2);
    g.fillStyle = '#23282e'; g.beginPath(); g.arc(cx, cy, 8.4, 0, 6.2832); g.fill();
    g.fillStyle = '#5a636d'; g.beginPath(); g.arc(cx, cy, 6.2, 0, 6.2832); g.fill();
    g.fillStyle = '#9aa4ae'; g.beginPath(); g.arc(cx - 1.6, cy - 2, 2.2, 0, 6.2832); g.fill();
    g.strokeStyle = '#f5a30c'; g.lineWidth = 2.4; g.beginPath(); g.arc(cx, cy, 8.6, 0, 6.2832); g.stroke();
    if (conn.length >= 3) {                                               // a real junction node: a small red hand-wheel on the hub (same look as the supplied junction art)
      g.fillStyle = '#4b535c'; g.fillRect(cx - 1.2, cy - 11, 2.4, 8);
      g.strokeStyle = '#d6291d'; g.lineWidth = 2.6; g.beginPath(); g.ellipse(cx, cy - 11.5, 7.6, 3.5, 0, 0, 6.2832); g.stroke();
      g.strokeStyle = '#ff7e6e'; g.lineWidth = 1; g.beginPath(); g.ellipse(cx, cy - 12.2, 7.6, 3.5, 0, 3.5, 5.9); g.stroke();
      g.strokeStyle = '#a81d14'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(cx - 7, cy - 11.5); g.lineTo(cx + 7, cy - 11.5); g.moveTo(cx, cy - 15); g.lineTo(cx, cy - 8); g.stroke();
      g.fillStyle = '#c8cfd6'; g.beginPath(); g.arc(cx, cy - 11.5, 1.6, 0, 6.2832); g.fill();
    }
    }
    // Main lines are visibly heavier and carry a small orange identification collar; branch lines stay slimmer.
    // (main lines are told apart by their larger diameter; no floating ring)
    // flow
    if (flowing) {
      const nxx = nx % W, nyy = (nx / W) | 0;
      const dn = DIRS.find(d => d[0] === nxx - x && d[1] === nyy - y);
      if (!dn) return;
      let sx = -dn[2] / 2, sy = -dn[3] / 2;
      for (const d of DIRS) {
        const px = x + d[0], py = y + d[1];
        if (inb(px, py) && (type[idx(px, py)] === 1 || type[idx(px, py)] === 4) && net.fnext[idx(px, py)] === k) { sx = d[2] / 2; sy = d[3] / 2; break; }
        if (inb(px, py) && type[idx(px, py)] === 2) { sx = d[2] / 2; sy = d[3] / 2; }
      }
      const np = ratio > .66 ? 3 : ratio > .3 ? 2 : 1;                  // denser oil when the pipe is fuller
      g.globalAlpha = ga;
      for (let j = 0; j < np; j++) {
        const f = (anim.pph[k] + j / np) % 1;
        let px, py;
        if (f < .5) { const u = f * 2; px = cx + sx * (1 - u); py = cy + sy * (1 - u); }
        else { const u = (f - .5) * 2; px = cx + dn[2] / 2 * u; py = cy + dn[3] / 2 * u; }
        g.fillStyle = 'rgba(255,170,30,.35)'; g.beginPath(); g.arc(px, py, 6.5, 0, 6.2832); g.fill();
        g.fillStyle = '#ffb41f'; g.beginPath(); g.arc(px, py, 4, 0, 6.2832); g.fill();
        g.fillStyle = '#fff1c4'; g.beginPath(); g.arc(px - .7, py - .8, 1, 0, 6.2832); g.fill();
      }
      g.globalAlpha = 1;
    }
  }


  /* ---- Pump station: the supplied artwork (drawn on the pipe line), a lamp for its state and an arrow for its direction ---- */
  const pumpImgs = {};
  function pumpImg(key) { if (!pumpImgs[key] && window.ART && ART.pump) { const i = new Image(); i.src = ART.pump[key]; pumpImgs[key] = i; } return pumpImgs[key]; }
  const LAMP = { running: '#2fd27a', maxed: '#ffb41f', standby: '#9fb3c8', idle: '#9fb3c8', offline: '#7a8794', noInput: '#ff5a4f', noOutput: '#ff5a4f', building: '#ffb41f' };
  function drawPump(g, b, t, ghost) {
    const [cx, cy] = cc(b.x, b.y), d = DIRS[b.dir || 0], A = window.ART && ART.pump, img = pumpImg((b.dir || 0) < 2 ? 'x' : 'y');
    g.fillStyle = 'rgba(60,30,0,.2)'; g.beginPath(); g.ellipse(cx + 2, cy + 3, 34, 15, 0, 0, 6.2832); g.fill();
    if (img && img.complete && img.naturalWidth && A) { const w = 112, h = w * A.h / A.w; g.drawImage(img, cx - w / 2, cy - h + 26, w, h); }
    else { g.fillStyle = '#7e8a97'; g.beginPath(); g.roundRect(cx - 22, cy - 26, 44, 34, 6); g.fill(); g.fillStyle = '#d9c9a0'; g.fillRect(cx - 30, cy - 6, 60, 8); }
    const st = ghost ? 'idle' : game.pumpNet(b).status, run = !ghost && b.spin > .05;
    // direction chevron on the ground in front of the pump (the oil leaves there)
    const fx = cx + d[2] * .72, fy = cy - 2 + d[3] * .72, ang = Math.atan2(d[3], d[2]), pulse = run ? .65 + .35 * Math.sin(t * 7) : .55;
    g.save(); g.translate(fx, fy); g.rotate(ang); g.globalAlpha = pulse * (ghost ? 1 : .95);
    g.fillStyle = run ? '#ffb41f' : '#cfd8e0'; g.strokeStyle = 'rgba(20,30,40,.9)'; g.lineWidth = 1.6;
    g.beginPath(); g.moveTo(8, 0); g.lineTo(-3, -6); g.lineTo(-1, 0); g.lineTo(-3, 6); g.closePath(); g.fill(); g.stroke(); g.restore();
    // status lamp
    if (!ghost) { g.fillStyle = 'rgba(10,20,32,.85)'; g.beginPath(); g.arc(cx + 18, cy - 40, 5.2, 0, 6.2832); g.fill(); g.fillStyle = LAMP[st] || '#9fb3c8'; g.beginPath(); g.arc(cx + 18, cy - 40, 3.4, 0, 6.2832); g.fill(); }
  }

  const WELL_SPR = { small: ['wellS', 96], medium: ['wellM', 108], large: ['wellL', 118] };
  function drawWell(g, b, t) {
    const sp = WELL_SPR[b.kind] || WELL_SPR.small, key = b.kind === 'small' && (b.id & 1) ? 'wellS2' : sp[0];
    if (sprImg(key)) {
      const [cx, cy] = cc(b.x, b.y), wa = wellAnim(b), dw = sp[1], im = sprImg(key), dh = dw * im.naturalHeight / im.naturalWidth;
      const gy = cy + 6;                                                 // ground centre of the platform
      shade(g, cx + 2, gy, dw * .4, dw * .18, .12);
      g.save(); g.translate(cx, gy);
      if (b.kind !== 'large' && wa.amp > .02) g.scale(1 + Math.sin(wa.ph) * .016 * wa.amp, 1 - Math.sin(wa.ph) * .014 * wa.amp);   // the pump-jack rocks with the real stroke
      g.drawImage(im, -dw / 2, -dh + dw * .2, dw, dh);
      g.restore();
      if (wa.amp > .05) {                                                // working glow at the platform edge
        const gl = .5 + .5 * Math.sin(wa.ph + 1.2);
        g.fillStyle = 'rgba(255,180,31,' + (.28 * gl * wa.amp).toFixed(3) + ')'; g.beginPath(); g.ellipse(cx + dw * .32, gy + 2, 10 + 4 * gl, 5 + 2 * gl, 0, 0, 6.2832); g.fill();
      }
      for (let i = 0; i < b.level; i++) { g.fillStyle = '#ffb41f'; g.fillRect(cx - 10 + i * 7, gy + dw * .2 + 2, 5, 4); g.strokeStyle = 'rgba(20,30,40,.7)'; g.lineWidth = .8; g.strokeRect(cx - 10 + i * 7, gy + dw * .2 + 2, 5, 4); }
      const led = wa.amp > .3 ? '#2fd27a' : b.status === 'full' ? '#ff5a4f' : '#ffb41f', lx = cx - dw * .34, ly = gy - dh * .42;
      g.fillStyle = 'rgba(10,20,32,.85)'; g.beginPath(); g.arc(lx, ly, 4.6, 0, 6.2832); g.fill();
      g.fillStyle = led; g.beginPath(); g.arc(lx, ly, 3, 0, 6.2832); g.fill();
      if (wa.amp > .3) { g.fillStyle = 'rgba(47,210,122,.3)'; g.beginPath(); g.arc(lx, ly, 7, 0, 6.2832); g.fill(); }
      return;
    }
    const [cx, cy] = cc(b.x, b.y), working = b.status === 'producing' || b.status === 'limited';
    const ks = b.kind === 'large' ? 1.38 : b.kind === 'medium' ? 1.28 : 1.2;
    g.save(); g.translate(cx, cy + 2); g.scale(ks, ks); g.translate(-cx, -(cy + 2));
    shade(g, cx + 4, cy + 4, 36, 15, .2);
    // slab
    g.fillStyle = '#4f545c'; g.beginPath(); g.moveTo(cx - 30, cy + 2); g.lineTo(cx, cy + 16); g.lineTo(cx, cy + 22); g.lineTo(cx - 30, cy + 8); g.closePath(); g.fill();
    g.fillStyle = '#3f434a'; g.beginPath(); g.moveTo(cx, cy + 16); g.lineTo(cx + 30, cy + 2); g.lineTo(cx + 30, cy + 8); g.lineTo(cx, cy + 22); g.closePath(); g.fill();
    diamond(g, cx, cy + 2, 30, 14); g.fillStyle = '#8b9099'; g.fill();
    diamond(g, cx, cy + 2, 22, 10); g.fillStyle = '#767b84'; g.fill();
    const px = cx - 6, py = cy - 46;
    const wa = wellAnim(b), th = .06 * (1 - wa.amp) + Math.sin(wa.ph) * .2 * wa.amp;
    const c = Math.cos(th), s = Math.sin(th);
    const hx = px + 33 * c, hy = py + 33 * s, tx = px - 27 * c, ty = py - 27 * s;
    // engine box
    g.fillStyle = '#35607f'; g.fillRect(cx - 40, cy - 12, 20, 14);
    g.fillStyle = '#4b7ea3'; g.fillRect(cx - 40, cy - 12, 20, 4);
    g.fillStyle = '#ffb41f'; g.fillRect(cx - 40, cy - 3, 20, 2.5);
    // wellhead + polished rod
    const wx = cx + 26, wy = cy + 1;
    g.fillStyle = '#2f343a'; g.fillRect(wx - 5, wy - 14, 10, 14);
    g.fillStyle = '#566069'; g.beginPath(); g.ellipse(wx, wy - 14, 5, 2.4, 0, 0, 6.2832); g.fill();
    g.strokeStyle = '#c9d2db'; g.lineWidth = 2; g.beginPath(); g.moveTo(hx - 2, hy + 14); g.lineTo(wx, wy - 15); g.stroke();
    // pitman arm + samson post
    g.strokeStyle = '#55606a'; g.lineWidth = 3; g.beginPath(); g.moveTo(tx + 3, ty + 12); g.lineTo(cx - 32, cy - 10); g.stroke();
    g.strokeStyle = '#2a2e34'; g.lineWidth = 5.5; g.lineCap = 'round';
    g.beginPath(); g.moveTo(cx - 20, cy + 3); g.lineTo(px, py); g.lineTo(cx + 8, cy + 5); g.stroke();
    g.lineWidth = 3; g.beginPath(); g.moveTo(cx - 12, cy - 17); g.lineTo(cx + 1, cy - 17); g.stroke();
    // walking beam
    g.strokeStyle = '#1f2327'; g.lineWidth = 8; g.beginPath(); g.moveTo(tx, ty); g.lineTo(hx, hy); g.stroke();
    g.strokeStyle = '#4a525b'; g.lineWidth = 2.4; g.beginPath(); g.moveTo(tx, ty - 2); g.lineTo(hx, hy - 2); g.stroke();
    // counterweight
    g.save(); g.translate(tx, ty); g.rotate(th); g.fillStyle = '#c4322a'; g.fillRect(-9, -2, 13, 19); g.fillStyle = '#e24b3f'; g.fillRect(-9, -2, 13, 4); g.restore();
    // horsehead
    g.save(); g.translate(hx, hy); g.rotate(th);
    g.fillStyle = '#d93a2b'; g.beginPath(); g.moveTo(-7, -9); g.quadraticCurveTo(13, -10, 15, 15); g.lineTo(5, 15); g.quadraticCurveTo(4, 0, -7, -3); g.closePath(); g.fill();
    g.strokeStyle = '#8f1f17'; g.lineWidth = 1.2; g.stroke(); g.restore();
    g.fillStyle = '#2a2e34'; g.beginPath(); g.arc(px, py, 4.4, 0, 6.2832); g.fill();
    g.fillStyle = '#9aa4ae'; g.beginPath(); g.arc(px, py, 1.8, 0, 6.2832); g.fill();
    // pumping effect: wellhead glow on the down-stroke and little oil drops that follow the stroke speed
    if (wa.amp > .05) {
      const gl = Math.max(0, Math.sin(wa.ph + 1.2)) * wa.amp, u = ((wa.ph / 6.2832) % 1 + 1) % 1;
      g.fillStyle = 'rgba(255,180,31,' + (.4 * gl).toFixed(3) + ')'; g.beginPath(); g.arc(wx, wy - 15, 4 + 4 * gl, 0, 6.2832); g.fill();
      for (let j = 0; j < 2; j++) {
        const f = (u + j * .5) % 1;
        g.fillStyle = 'rgba(255,196,60,' + (Math.sin(f * 3.1416) * .9 * wa.amp).toFixed(3) + ')';
        g.beginPath(); g.arc(wx + (f - .5) * 13, wy - 17 - 10 * Math.sin(f * 3.1416), 1.8, 0, 6.2832); g.fill();
      }
    }
    // level pips + status light
    for (let i = 0; i < b.level; i++) { g.fillStyle = '#ffb41f'; g.fillRect(cx - 12 + i * 6, cy + 12, 4, 4); }
    const led = wa.amp > .3 ? '#2fd27a' : b.status === 'full' ? '#ff5a4f' : '#ffb41f';
    g.fillStyle = led; g.beginPath(); g.arc(px, py - 9, 3.2, 0, 6.2832); g.fill();
    if (wa.amp > .3) { g.fillStyle = 'rgba(47,210,122,.3)'; g.beginPath(); g.arc(px, py - 9, 6, 0, 6.2832); g.fill(); }
    g.restore();
  }

  const TANK_SPR = [['tank1', 138], ['tank2', 154], ['tank3', 166]];
  const TANK_TOP = 1;
  function tankTopY(b) { const sp = TANK_SPR[clamp((b.level || 1) - 1, 0, 2)], im = sprImg(sp[0]); return im ? -(sp[1] * im.naturalHeight / im.naturalWidth) + sp[1] * .22 + 6 : -46 * 1.1 - 28; }   // roof height above the footprint centre
  function drawTank(g, b) {
    const sp = TANK_SPR[clamp((b.level || 1) - 1, 0, 2)], im = sprImg(sp[0]);
    if (im) {
      const cx = (b.x - b.y) * 32, cy = (b.x + b.y + 2) * 16, dw = sp[1], dh = dw * im.naturalHeight / im.naturalWidth, ta = tankAnim(b), frac = ta.f;
      const gy = cy + 5;
      shade(g, cx + 4, gy, dw * .42, dw * .19, .1);
      g.drawImage(im, cx - dw / 2, gy - dh + dw * .22, dw, dh);
      // sight glass on the tank wall: the oil level eases to the real inventory and the surface moves gently
      const gx = cx - dw * .2, gh = Math.min(64, dh * .34), gw = 11, gy0 = gy - dh * .62, ly = gy0 + gh - 1 - (gh - 2) * frac;
      g.fillStyle = 'rgba(20,28,40,.92)'; g.fillRect(gx, gy0, gw, gh);
      if (frac > .004) {
        g.save(); g.beginPath(); g.rect(gx + 1, gy0 + 1, gw - 2, gh - 2); g.clip();
        const calm = frac > .98 ? .35 : 1, col = frac > .95 ? '#ff5a4f' : frac > .75 ? '#ffb41f' : '#2fd27a';
        g.fillStyle = col; g.globalAlpha = .55; g.beginPath(); g.moveTo(gx + 1, gy0 + gh);
        for (let xx = 0; xx <= gw - 2; xx += 2) g.lineTo(gx + 1 + xx, ly - 1 + Math.sin(ta.w * .8 + xx * .7 + 2) * 1.1 * calm);
        g.lineTo(gx + gw - 1, gy0 + gh); g.closePath(); g.fill();
        g.globalAlpha = 1; g.beginPath(); g.moveTo(gx + 1, gy0 + gh);
        for (let xx = 0; xx <= gw - 2; xx += 2) g.lineTo(gx + 1 + xx, ly + Math.sin(ta.w + xx * .9) * 1.3 * calm);
        g.lineTo(gx + gw - 1, gy0 + gh); g.closePath(); g.fill();
        g.fillStyle = 'rgba(255,255,255,.28)'; g.fillRect(gx + 2, ly + 2, 2, Math.max(0, gy0 + gh - ly - 4));
        g.restore();
      }
      const blink = ta.full > .01 ? .5 + .5 * Math.sin(ta.t * 6) : 0;
      g.strokeStyle = ta.full > .01 ? 'rgba(255,90,79,' + (.5 + .5 * blink * ta.full).toFixed(3) + ')' : 'rgba(255,255,255,.55)'; g.lineWidth = 1; g.strokeRect(gx + .5, gy0 + .5, gw - 1, gh - 1);
      if (ta.full > .01) {                                              // tank full: pulsing red beacon on the roof
        const by = gy - dh + dw * .22 + 14;
        g.fillStyle = 'rgba(255,90,79,' + (.25 * blink * ta.full).toFixed(3) + ')'; g.beginPath(); g.arc(cx, by, 16, 0, 6.2832); g.fill();
        g.fillStyle = blink > .45 ? '#ff5a4f' : '#7a2620'; g.beginPath(); g.arc(cx, by, 4.2, 0, 6.2832); g.fill();
      }
      for (let i = 0; i < b.level; i++) { g.fillStyle = '#ffb41f'; g.fillRect(cx - 14 + i * 7, gy + dw * .22 + 1, 5, 4); g.strokeStyle = 'rgba(20,30,40,.7)'; g.lineWidth = .8; g.strokeRect(cx - 14 + i * 7, gy + dw * .22 + 1, 5, 4); }
      return;
    }
    const cx = (b.x - b.y) * 32, cy = (b.x + b.y + 2) * 16;   // centre of the 2x2 footprint
    const rx = 47, ry = 23.5, h = 46;
    const ta = tankAnim(b), frac = ta.f;
    g.save(); g.translate(cx, cy + 3); g.scale(1.1, 1.1); g.translate(-cx, -(cy + 3));
    shade(g, cx + 6, cy + 4, rx + 12, ry + 4, .2);
    // base ring
    g.fillStyle = '#6d727a'; g.beginPath(); g.ellipse(cx, cy + 3, rx + 5, ry + 2.5, 0, 0, 6.2832); g.fill();
    // body
    const gr = g.createLinearGradient(cx - rx, 0, cx + rx, 0);
    gr.addColorStop(0, '#f1eee4'); gr.addColorStop(.45, '#e0ddd2'); gr.addColorStop(1, '#9b9a90');
    g.beginPath(); g.moveTo(cx - rx, cy - h); g.lineTo(cx - rx, cy); g.ellipse(cx, cy, rx, ry, 0, Math.PI, 0, true); g.lineTo(cx + rx, cy - h); g.ellipse(cx, cy - h, rx, ry, 0, 0, Math.PI, false); g.closePath();
    g.fillStyle = gr; g.fill();
    g.strokeStyle = 'rgba(80,80,70,.35)'; g.lineWidth = 1; g.beginPath(); g.ellipse(cx, cy - h * .5, rx, ry, 0, 0.05, Math.PI - .05); g.stroke();
    // top
    g.fillStyle = '#f5f2e8'; g.beginPath(); g.ellipse(cx, cy - h, rx, ry, 0, 0, 6.2832); g.fill();
    g.fillStyle = '#d9d6ca'; g.beginPath(); g.ellipse(cx, cy - h - 2, rx * .78, ry * .78, 0, 0, 6.2832); g.fill();
    g.fillStyle = '#c4c1b5'; g.beginPath(); g.ellipse(cx, cy - h - 5, rx * .42, ry * .42, 0, 0, 6.2832); g.fill();
    g.strokeStyle = '#f2b705'; g.lineWidth = 3.2; g.beginPath(); g.ellipse(cx, cy - h, rx, ry, 0, 0, 6.2832); g.stroke();
    g.strokeStyle = 'rgba(242,183,5,.75)'; g.lineWidth = 1.4; g.beginPath(); g.ellipse(cx, cy - h + 6, rx, ry, 0, 0.1, Math.PI - .1); g.stroke();
    // ladder
    g.strokeStyle = '#4b5057'; g.lineWidth = 1.6;
    g.beginPath(); g.moveTo(cx + 30, cy + 15); g.lineTo(cx + 30, cy - h + 19); g.moveTo(cx + 36, cy + 12); g.lineTo(cx + 36, cy - h + 16); g.stroke();
    g.lineWidth = 1; g.beginPath(); for (let y = cy + 12; y > cy - h + 22; y -= 7) { g.moveTo(cx + 30, y + 2); g.lineTo(cx + 36, y - 1); } g.stroke();
    // emblem
    const ex = cx - 12, ey = cy - h * .45;
    g.fillStyle = '#1d2733'; g.beginPath(); g.moveTo(ex, ey - 11); g.bezierCurveTo(ex + 10, ey + 2, ex + 8, ey + 11, ex, ey + 11); g.bezierCurveTo(ex - 8, ey + 11, ex - 10, ey + 2, ex, ey - 11); g.fill();
    g.fillStyle = 'rgba(255,255,255,.35)'; g.beginPath(); g.ellipse(ex - 3, ey + 2, 1.6, 3.4, .3, 0, 6.2832); g.fill();
    // sight glass: the oil level eases to the real inventory and the surface moves gently
    const gx = cx + 14, gy0 = cy - h + 14, gh = 52, gw = 12, ly = gy0 + gh - 1 - (gh - 2) * frac;
    g.fillStyle = '#1b2430'; g.fillRect(gx, gy0, gw, gh);
    if (frac > .004) {
      g.save(); g.beginPath(); g.rect(gx + 1, gy0 + 1, gw - 2, gh - 2); g.clip();
      const calm = frac > .98 ? .35 : 1, col = frac > .95 ? '#ff5a4f' : frac > .75 ? '#ffb41f' : '#2fd27a';
      g.fillStyle = col; g.globalAlpha = .55; g.beginPath(); g.moveTo(gx + 1, gy0 + gh);
      for (let xx = 0; xx <= gw - 2; xx += 2) g.lineTo(gx + 1 + xx, ly - 1 + Math.sin(ta.w * .8 + xx * .7 + 2) * 1.1 * calm);
      g.lineTo(gx + gw - 1, gy0 + gh); g.closePath(); g.fill();
      g.globalAlpha = 1; g.beginPath(); g.moveTo(gx + 1, gy0 + gh);
      for (let xx = 0; xx <= gw - 2; xx += 2) g.lineTo(gx + 1 + xx, ly + Math.sin(ta.w + xx * .9) * 1.3 * calm);
      g.lineTo(gx + gw - 1, gy0 + gh); g.closePath(); g.fill();
      g.fillStyle = 'rgba(255,255,255,.28)'; g.fillRect(gx + 2, ly + 2, 2, Math.max(0, gy0 + gh - ly - 4));
      g.restore();
    }
    const blink = ta.full > .01 ? .5 + .5 * Math.sin(ta.t * 6) : 0;
    g.strokeStyle = ta.full > .01 ? 'rgba(255,90,79,' + (.5 + .5 * blink * ta.full).toFixed(3) + ')' : 'rgba(255,255,255,.4)'; g.lineWidth = 1; g.strokeRect(gx + .5, gy0 + .5, gw - 1, gh - 1);
    // tank full: pulsing red rim and a beacon on the roof
    if (ta.full > .01) {
      g.strokeStyle = 'rgba(255,90,79,' + (.25 + .5 * blink).toFixed(3) * ta.full + ')'; g.lineWidth = 4.5; g.beginPath(); g.ellipse(cx, cy - h, rx, ry, 0, 0, 6.2832); g.stroke();
      g.fillStyle = 'rgba(255,90,79,' + (.25 * blink * ta.full).toFixed(3) + ')'; g.beginPath(); g.arc(cx, cy - h - 12, 14, 0, 6.2832); g.fill();
      g.fillStyle = blink > .45 ? '#ff5a4f' : '#7a2620'; g.beginPath(); g.arc(cx, cy - h - 12, 4.2, 0, 6.2832); g.fill();
    }
    // pipe stubs
    g.fillStyle = '#c4322a'; g.fillRect(cx - rx + 4, cy - 6, 9, 7);
    for (let i = 0; i < b.level; i++) { g.fillStyle = '#ffb41f'; g.fillRect(cx - 14 + i * 7, cy + 16, 5, 4); }
    g.restore();
  }

  /* ================= Scene ================= */
  let tNow = 0;
  function render() {
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = bgGrad; ctx.fillRect(0, 0, cv.width, cv.height);
    const z = cam.z * dpr;
    ctx.setTransform(z, 0, 0, z, cv.width / 2 - cam.x * z, cv.height / 2 - cam.y * z);
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    drawGround(cam.x - vw / 2 / cam.z - 40, cam.y - vh / 2 / cam.z - 40, cam.x + vw / 2 / cam.z + 40, cam.y + vh / 2 / cam.z + 40, cam.z < .6 ? 1 : 0, 2);

    const buildMode = ui.tool === 'well' || ui.tool === 'pipe' || ui.tool === 'tank' || ui.tool === 'pump' || ui.tool === 'explore';
    if (buildMode) drawGrid();
    if (ui.tool === 'explore' || ui.tool === 'well') drawAreas();

    const x0 = cam.x - vw / 2 / cam.z - 110, x1 = cam.x + vw / 2 / cam.z + 110, y0 = cam.y - vh / 2 / cam.z - 140, y1 = cam.y + vh / 2 / cam.z + 90;
    const items = [], t = tNow;
    const vis = (wx, wy) => wx > x0 && wx < x1 && wy > y0 && wy < y1;
    for (const d of game.map.decos) {
      const [cx, cy] = cc(d.x, d.y);
      if (!vis(cx, cy)) continue;
      if (d.type === 'shrub' && (game.occ[idx(d.x, d.y)] || game.pipe[idx(d.x, d.y)])) continue;
      items.push({ d: d.x + d.y, o: 1, f: g => d.type === 'palm' ? drawPalm(g, cx, cy, d.v, t) : d.type === 'shrub' ? drawShrub(g, cx, cy, d.v) : drawRock(g, cx, cy, d.type === 'bigrock' ? 30 + d.v * 14 : 14 + d.v * 6, d.v) });
    }
    leakList.length = 0;
    for (let k = 0; k < game.pipe.length; k++) {
      if (!game.pipe[k]) continue;
      if (game.pipeSt[k]) leakList.push(k);
      const x = k % W, y = (k / W) | 0, [cx, cy] = cc(x, y);
      if (!vis(cx, cy)) continue;
      items.push({ d: x + y, o: 2, f: game.net.live[k] === 0 ? g => { g.save(); g.globalAlpha = .45 + .25 * Math.sin(tNow * 9 + k); drawPipe(g, x, y, k, t); g.restore(); } : anim.born.has('p' + k) ? popped('p' + k, cx, cy, g => drawPipe(g, x, y, k, t)) : g => drawPipe(g, x, y, k, t) });
    }
    for (const b of game.buildings) {
      if (b.type === 'well') { const [cx, cy] = cc(b.x, b.y); if (vis(cx, cy)) items.push({ d: b.x + b.y, o: 1, f: b.ready > game.s.time ? underConstruction(b, cx, cy + 14, g => drawWell(g, b, t)) : anim.born.has('b' + b.id) ? popped('b' + b.id, cx, cy + 14, g => drawWell(g, b, t)) : g => drawWell(g, b, t) }); }
      else if (b.type === 'pump') { const [cx, cy] = cc(b.x, b.y); if (vis(cx, cy)) items.push({ d: b.x + b.y, o: 1, f: b.ready > game.s.time ? underConstruction(b, cx, cy + 10, g => drawPump(g, b, t)) : anim.born.has('b' + b.id) ? popped('b' + b.id, cx, cy + 10, g => drawPump(g, b, t)) : g => drawPump(g, b, t) }); }
      else { const cx = (b.x - b.y) * 32, cy = (b.x + b.y + 2) * 16; if (vis(cx, cy)) items.push({ d: b.x + b.y + 2, o: 0, f: b.ready > game.s.time ? underConstruction(b, cx, cy + 6, g => drawTank(g, b)) : anim.born.has('b' + b.id) ? popped('b' + b.id, cx, cy + 6, g => drawTank(g, b)) : g => drawTank(g, b) }); }
    }
    items.sort((a, b) => a.d - b.d || a.o - b.o);
    for (const it of items) it.f(ctx);
    drawFx();
    drawLeaks();

    drawOverlays();
    drawPills();
    drawTankLabels();
  }

  const leakList = [];
  // Leaks: a pulsing red badge (repairing: amber with a progress ring) so the problem is easy to find, plus a few drops.
  function drawLeaks() {
    for (const k of leakList) {
      const x = k % W, y = (k / W) | 0, [cx, cy] = cc(x, y), st = game.pipeSt[k], p = .5 + .5 * Math.sin(tNow * (st === 1 ? 6 : 3));
      const by = cy - 34 - 3 * p;
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(cx, cy - 4, 10, 4, 0, 0, 6.2832); ctx.fill();
      if (st === 1) {
        ctx.fillStyle = '#16110c';
        for (let i = 0; i < 3; i++) { const f = (tNow * 1.3 + i / 3) % 1; ctx.globalAlpha = 1 - f; ctx.beginPath(); ctx.ellipse(cx + (i - 1) * 6, cy - 2 + f * 14, 2, 3, 0, 0, 6.2832); ctx.fill(); }
        ctx.globalAlpha = 1;
      }
      ctx.fillStyle = st === 1 ? 'rgba(255,90,79,' + (.82 + .18 * p) + ')' : 'rgba(255,180,31,.95)';
      ctx.beginPath(); ctx.arc(cx, by, 11 + (st === 1 ? 2 * p : 0), 0, 6.2832); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
      if (st === 1) { ctx.fillStyle = '#fff'; ctx.fillRect(cx - 1.5, by - 6, 3, 8); ctx.fillRect(cx - 1.5, by + 4, 3, 3); }
      else { const f = 1 - game.pipeT[k] / CFG.PIPE.REPAIR_TIME; ctx.strokeStyle = '#2a1000'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(cx, by, 6, -1.5708, -1.5708 + 6.2832 * clamp(f, 0, 1)); ctx.stroke(); }
    }
  }

  // Exploration layer (explore / well tools): each AREA x AREA block is hidden until it has been explored.
  const KIND_COL = { empty: '120,130,140', small: '90,200,120', medium: '255,190,40', large: '255,120,50' };
  function drawAreas() {
    const A = CFG.EXPLORE.AREA, x0 = cam.x - vw / 2 / cam.z - 160, x1 = cam.x + vw / 2 / cam.z + 160, y0 = cam.y - vh / 2 / cam.z - 160, y1 = cam.y + vh / 2 / cam.z + 160;
    const sel = ui.sel && ui.sel.kind === 'area' ? ui.sel.id : -1;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.direction = 'ltr';
    for (const a of game.areas) {
      if (!a.land) continue;
      const gx = a.ax * A, gy = a.ay * A, ex = Math.min(W, gx + A), ey = Math.min(H, gy + A);
      const cxw = ((gx - gy) + (ex - ey)) * 16, cyw = ((gx + gy) + (ex + ey)) * 8;
      if (cxw < x0 || cxw > x1 || cyw < y0 || cyw > y1) continue;
      const P = (X, Y) => [(X - Y) * 32, (X + Y) * 16];
      const pts = [P(gx, gy), P(ex, gy), P(ex, ey), P(gx, ey)];
      const info = a.st === 2 ? KIND_COL[a.kind] : a.st === 1 ? '255,180,31' : '20,30,50';
      ctx.beginPath(); pts.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.closePath();
      ctx.fillStyle = 'rgba(' + info + ',' + (a.st === 2 ? (a.kind === 'empty' ? .22 : .26) : a.st === 1 ? .3 : .42) + ')'; ctx.fill();
      ctx.strokeStyle = a.id === sel ? '#fff' : 'rgba(' + (a.st === 0 ? '200,215,235' : info) + ',.85)'; ctx.lineWidth = (a.id === sel ? 3.5 : 1.8) / cam.z; ctx.setLineDash(a.st === 0 ? [10 / cam.z, 7 / cam.z] : []); ctx.stroke(); ctx.setLineDash([]);
      const locked = !game.regionOpen(a.region);
      let label = '?', sub = '';
      if (a.st === 1) { label = Math.round(game.areaInfo(a).progress * 100) + '%'; }
      else if (a.st === 2) { label = a.kind === 'empty' ? '∅' : '●'.repeat(a.kind === 'small' ? 1 : a.kind === 'medium' ? 2 : 3); sub = a.kind === 'empty' ? '' : a.quality[0]; }
      if (locked) {                                                  // padlock: the region has not been unlocked yet
        ctx.fillStyle = 'rgba(8,14,24,.45)'; ctx.fill();
        ctx.fillStyle = 'rgba(235,242,250,.9)'; ctx.fillRect(cxw - 9, cyw - 4, 18, 14); ctx.strokeStyle = 'rgba(235,242,250,.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(cxw, cyw - 4, 6, Math.PI, 0); ctx.stroke(); continue;
      }
      ctx.font = '700 ' + (a.st === 0 ? 30 : 22) + 'px "Chakra Petch", sans-serif';
      ctx.fillStyle = a.st === 0 ? 'rgba(235,242,250,.85)' : '#fff'; ctx.fillText(label, cxw, cyw);
      if (sub) { ctx.font = '600 13px "Chakra Petch", sans-serif'; ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.fillText(sub, cxw, cyw + 20); }
    }
    ctx.textAlign = 'left';
  }

  // Capacity label above every tank: current oil / capacity.
  function drawTankLabels() {
    if (cam.z < .65) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.font = '600 12px "Chakra Petch", Cairo, sans-serif'; ctx.textBaseline = 'middle'; ctx.textAlign = 'center'; ctx.direction = 'ltr';
    for (const b of game.buildings) {
      if (b.type !== 'tank') continue;
      const p = w2s((b.x - b.y) * 32, (b.x + b.y + 2) * 16 + 5 + tankTopY(b) - 14);
      if (p.x < -60 || p.x > vw + 60 || p.y < -20 || p.y > vh + 20) continue;
      const cap = game.tankCap(b), ta = tankAnim(b), f = ta.f, text = num(b.amt) + ' / ' + num(cap), w = ctx.measureText(text).width + 18;
      ctx.fillStyle = ta.full > .01 ? 'rgba(' + (10 + 110 * ta.full * (.6 + .4 * Math.sin(ta.t * 6))) + ',20,26,.92)' : 'rgba(10,20,32,.88)'; ctx.beginPath(); ctx.roundRect(p.x - w / 2, p.y - 12, w, 24, 12); ctx.fill();
      ctx.fillStyle = f > .95 ? '#ff5a4f' : f > .75 ? '#ffb41f' : '#2fd27a'; ctx.fillRect(p.x - w / 2 + 9, p.y + 7, (w - 18) * f, 2);
      ctx.fillStyle = '#fff'; ctx.fillText(text, p.x, p.y - 1);
    }
    ctx.textAlign = 'left';
  }

  function drawGrid() {          // only the lines that are on screen
    const cs = [[0, 0], [vw, 0], [0, vh], [vw, vh]].map(p => { const w = s2w(p[0], p[1]); return [(w.x / 32 + w.y / 16) / 2, (w.y / 16 - w.x / 32) / 2]; });
    const u0 = clamp(Math.floor(Math.min(...cs.map(c => c[0]))) - 1, 0, W), u1 = clamp(Math.ceil(Math.max(...cs.map(c => c[0]))) + 1, 0, W);
    const v0 = clamp(Math.floor(Math.min(...cs.map(c => c[1]))) - 1, 0, H), v1 = clamp(Math.ceil(Math.max(...cs.map(c => c[1]))) + 1, 0, H);
    ctx.strokeStyle = 'rgba(255,255,255,.16)'; ctx.lineWidth = 1 / cam.z; ctx.beginPath();
    for (let i = u0; i <= u1; i++) { ctx.moveTo((i - v0) * 32, (i + v0) * 16); ctx.lineTo((i - v1) * 32, (i + v1) * 16); }
    for (let j = v0; j <= v1; j++) { ctx.moveTo((u0 - j) * 32, (u0 + j) * 16); ctx.lineTo((u1 - j) * 32, (u1 + j) * 16); }
    ctx.stroke();
  }

  function tileFill(x, y, col, w) {
    const cx = (x - y) * 32, top = (x + y) * 16;
    ctx.beginPath(); ctx.moveTo(cx, top); ctx.lineTo(cx + 32, top + 16); ctx.lineTo(cx, top + 32); ctx.lineTo(cx - 32, top + 16); ctx.closePath();
    ctx.fillStyle = col; ctx.fill();
    if (w) { ctx.strokeStyle = w; ctx.lineWidth = 2 / cam.z; ctx.stroke(); }
  }
  function footprint(type, x, y, col, edge) {
    const [fw, fh] = game.footprintOf(type), p0 = gridToWorld(x, y), p1 = gridToWorld(x + fw, y), p2 = gridToWorld(x + fw, y + fh), p3 = gridToWorld(x, y + fh);
    ctx.beginPath(); ctx.moveTo(p0[0], p0[1]); ctx.lineTo(p1[0], p1[1]); ctx.lineTo(p2[0], p2[1]); ctx.lineTo(p3[0], p3[1]); ctx.closePath();
    ctx.fillStyle = col; ctx.fill(); ctx.strokeStyle = edge; ctx.lineWidth = 2 / cam.z; ctx.stroke();
  }

  // direction of a pump about to be built: the side that is closer to a tank is the output (auto); the flip button reverses it
  function pumpDirFor(cell) { const c = game.canPlacePump(cell.x, cell.y); if (!c.ok) return 0; return game.pumpAutoDir(cell.x, cell.y, c.axis) ^ (ui.pumpFlip ? 1 : 0); }
  function drawInOut(cell, dir) {            // "IN -> PUMP -> OUT" marks on the two neighbouring tiles
    const d = DIRS[dir], tag = (x, y, txt, col) => { const [cx, cy] = cc(x, y); ctx.save(); ctx.font = '700 ' + Math.round(13 / Math.max(.6, cam.z)) + 'px "Chakra Petch", sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(10,20,32,.9)'; const w = ctx.measureText(txt).width + 12, h = 16 / Math.max(.6, cam.z); ctx.beginPath(); ctx.roundRect(cx - w / 2, cy - 30 - h / 2, w, h + 4, 6); ctx.fill(); ctx.fillStyle = col; ctx.fillText(txt, cx, cy - 30 + h / 2 - 3 / Math.max(.6, cam.z)); ctx.restore(); };
    ctx.globalAlpha = 1; tag(cell.x - d[0], cell.y - d[1], 'IN', '#6fc3ff'); tag(cell.x + d[0], cell.y + d[1], 'OUT', '#ffb41f');
  }
  const hl = { key: '', tiles: [], blds: [] };
  let pill = null;           // { text, wx, wy, ok }
  function drawOverlays() {
    pill = null;
    const tm = tNow;
    // selection
    if (ui.sel) {
      const pulse = .55 + .25 * Math.sin(tm * 5);
      if (ui.sel.kind === 'b') {
        const b = game.buildings.find(q => q.id === ui.sel.id);
        if (b) footprint(b.type, b.x, b.y, 'rgba(255,180,31,' + (pulse * .25) + ')', 'rgba(255,180,31,' + pulse + ')');
      } else if (ui.sel.kind === 'pipe') {
        const x = ui.sel.k % W, y = (ui.sel.k / W) | 0;
        tileFill(x, y, 'rgba(255,180,31,' + (pulse * .3) + ')', 'rgba(255,180,31,' + pulse + ')');
      }
      // network highlight: only recomputed when the selection or the network changes (netVersion), never per frame
      const hk = ui.sel.kind + ':' + (ui.sel.id != null ? ui.sel.id : ui.sel.k) + ':' + game.netVersion;
      if (hl.key !== hk) {
        hl.key = hk; hl.tiles = []; hl.blds = [];
        const net = game.net;
        if (ui.sel.kind === 'b') {
          const b = game.buildings.find(q => q.id === ui.sel.id);
          if (b && b.type === 'well' && b.target != null) { const r = (net.routes.get(b.id) || []).find(q => q.tank.id === b.target); if (r) { hl.tiles = r.path.slice(); hl.blds = [r.tank]; } }
          else if (b && b.type === 'tank') { hl.blds = game.tankNet(b).feeding; for (const w of hl.blds) { const r = (net.routes.get(w.id) || []).find(q => q.tank === b); if (r) hl.tiles.push(...r.path); } }
        } else if (ui.sel.kind === 'pipe') { const c = net.comps[net.compOf[ui.sel.k]]; if (c) { hl.tiles = c.pipes.slice(); hl.blds = c.wells.concat(c.tanks); } }
      }
      const ha = .16 + .1 * Math.sin(tm * 4);
      for (const k of hl.tiles) if (!(ui.sel.kind === 'pipe' && k === ui.sel.k)) tileFill(k % W, (k / W) | 0, 'rgba(255,214,102,' + ha + ')', 'rgba(255,214,102,' + (ha + .2) + ')');
      for (const q of hl.blds) if (!(ui.sel.kind === 'b' && q.id === ui.sel.id)) footprint(q.type, q.x, q.y, 'rgba(47,210,122,' + ha + ')', 'rgba(47,210,122,.75)');
    }
    const tool = ui.tool;
    const cell = ui.pending || (tool === 'well' || tool === 'tank' || tool === 'pump' ? snapBuild(tool, ui.hover) : ui.hover);
    if (tool === 'well' || tool === 'tank' || tool === 'pump') {
      drawSpots(tool);
      if (cell && inb(cell.x, cell.y)) {
        ctx.save(); if (ui.pending) ctx.translate(gOff.x, gOff.y);
        const pl = verdict(tool, cell.x, cell.y), ok = pl.ok, poor = pl.state === 'UNAFFORDABLE';
        const col = ok ? '#2fd27a' : poor ? '#ffb41f' : '#ff5a4f';                                 // green = valid, amber = valid spot but not enough money, red = invalid
        footprint(tool, cell.x, cell.y, ok ? 'rgba(47,210,122,.35)' : poor ? 'rgba(255,180,31,.38)' : 'rgba(255,90,79,.4)', col);
        ctx.globalAlpha = pl.state === 'INVALID' ? .4 : .62;                                         // the real asset stays identifiable in every state (it is only drawn translucent, never recoloured)
        if (tool === 'well') drawWell(ctx, { id: 0, x: cell.x, y: cell.y, level: 1, status: 'idle', kind: ui.wellKind }, tm);
        else if (tool === 'pump') { const pd = pumpDirFor(cell); drawPump(ctx, { x: cell.x, y: cell.y, dir: pd, spin: 0 }, tm, true); if (pl.state !== 'INVALID') drawInOut(cell, pd); }
        else drawTank(ctx, { x: cell.x, y: cell.y, level: 1, amt: 0 });
        ctx.globalAlpha = 1;
        ctx.restore();
        const fc = footprintCenter(tool, cell.x, cell.y), fh2 = game.footprintOf(tool)[1];
        pill = { text: ok ? t('cost', { cost: money(pl.cost) }) + ' · ' + t('tr.' + CFG.TERRAIN.NAMES[game.terrainAt(cell.x, cell.y)]) : poor ? t('noCash') : help(pl.reason), wx: fc[0] + (ui.pending ? gOff.x : 0), wy: gridToWorld(cell.x, cell.y + fh2)[1] + 34 + (ui.pending ? gOff.y : 0), ok, dot: col };
      }
    } else if (tool === 'pipe') {
      // Phase 23 (node-to-node): the connection nodes glow; the chosen start is marked; the ONE route computed on the destination tap is shown
      const nodeMark = (id, col) => { const n = game.nodeById(id); if (!n) return; if (n.kind === 'b') footprint(n.b.type, n.b.x, n.b.y, 'rgba(255,180,31,.25)', col); else ringAt(n.x, n.y, col, 1, true); };
      const r = ui.pipeA && ui.pipeB ? ui.route : null;
      if (r && r.cells && r.cells.length) {
        const afford = game.s.cash >= r.cost, ok = r.ok && afford, fresh = new Set(r.fresh);
        for (const c of r.cells) { const k = idx(c[0], c[1]); tileFill(c[0], c[1], ok ? (fresh.has(k) ? 'rgba(47,210,122,.45)' : 'rgba(160,160,160,.25)') : 'rgba(255,90,79,.4)', ok ? 'rgba(120,235,160,.95)' : '#ff5a4f'); }
      }
      if (r) {
        const nB = game.nodeById(ui.pipeB), afford = game.s.cash >= r.cost, ok = r.ok && afford, dot = ok ? '#2fd27a' : '#ff5a4f';
        const info = r.ok ? game.routeInfo(r) : null;
        if (nB) { const [ex, ey] = cc(nB.x, nB.y);
          pill = { text: r.ok ? (afford ? t('cost', { cost: money(r.cost) }) : t('noCash')) + ' · ' + t('pv.tiles', { n: r.fresh.length }) + (info && info.corners ? ' · ' + t('pv.turns', { n: info.corners }) : '') : help(r.reason),
            text2: r.ok ? [r.connects ? t('connects') : t('noTankYet'), r.auto ? t('pv.detour') : ''].filter(Boolean).join(' · ') : '', wx: ex, wy: ey + 26, ok, dot };
          if (!pill.text2) delete pill.text2; nodeMark(ui.pipeB, dot); }
      }
      if (ui.pipeA) nodeMark(ui.pipeA, '#ffb41f');
      else {                                                                                   // where a pipe can start: every building is a node (soft pulse)
        const gl = .35 + .25 * Math.sin(tm * 4);
        for (const b of game.buildings) footprint(b.type, b.x, b.y, 'rgba(255,180,31,' + (gl * .22).toFixed(3) + ')', 'rgba(255,180,31,' + gl.toFixed(3) + ')');
      }
    } else if (tool === 'erase') {
      if (ui.hover && inb(ui.hover.x, ui.hover.y)) {
        const k = idx(ui.hover.x, ui.hover.y), b = (ui.mouse && pickBuilding(ui.mouse.x, ui.mouse.y)) || game.occ[k];
        if (b) footprint(b.type, b.x, b.y, 'rgba(255,90,79,.35)', '#ff5a4f');
        else if (game.pipe[k]) tileFill(ui.hover.x, ui.hover.y, 'rgba(255,90,79,.35)', '#ff5a4f');
      }
    } else if (tool === 'select' && ui.hover && ui.ptype === 'mouse' && inb(ui.hover.x, ui.hover.y)) {
      const k = idx(ui.hover.x, ui.hover.y), b = (ui.mouse && pickBuilding(ui.mouse.x, ui.mouse.y)) || game.occ[k];
      if (b) footprint(b.type, b.x, b.y, 'rgba(255,255,255,.12)', 'rgba(255,255,255,.55)');
      else if (game.pipe[k]) tileFill(ui.hover.x, ui.hover.y, 'rgba(255,255,255,.18)', 'rgba(255,255,255,.55)');
    }
    drawCoachMarks();
    if (dbg.on && game.net.graph) {                                                   // debug: graph nodes (junctions and pipe ends) with their ids and branch counts
      ctx.save(); ctx.font = '700 ' + (11 / cam.z).toFixed(2) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 3 / cam.z; let n = 0;
      for (const nd of game.net.graph.nodes) {
        if (nd.kind !== 'junction' && nd.kind !== 'end') continue; if (++n > 150) break;
        const [nx, ny] = cc(nd.x, nd.y), col = nd.kind === 'junction' ? '#7cd7ff' : '#ffd166', txt = nd.id + (nd.kind === 'junction' ? ' x' + nd.edges.length : '');
        ctx.strokeStyle = col; ctx.beginPath(); ctx.arc(nx, ny - 5, 5 / cam.z * 1.4, 0, 6.2832); ctx.stroke();
        ctx.strokeStyle = 'rgba(0,0,0,.8)'; ctx.fillStyle = col; ctx.strokeText(txt, nx, ny - 22 / cam.z * 1.1); ctx.fillText(txt, nx, ny - 22 / cam.z * 1.1);
      }
      ctx.restore();
    }
  }
  function drawPills() {
    if (!pill) return;
    const p = w2s(pill.wx, pill.wy), F1 = '600 14px "Chakra Petch", Cairo, Barlow, sans-serif', F2 = '500 12px "Chakra Petch", Cairo, Barlow, sans-serif', ar = prefs.lang === 'ar';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.font = F1; ctx.direction = ar ? 'rtl' : 'ltr'; ctx.textAlign = ar ? 'right' : 'left';
    let tw = ctx.measureText(pill.text).width; if (pill.text2) { ctx.font = F2; tw = Math.max(tw, ctx.measureText(pill.text2).width); ctx.font = F1; }
    const dotW = pill.dot ? 16 : 0, w = Math.min(vw - 16, tw + 24 + dotW), h = pill.text2 ? 46 : 28, x = clamp(p.x - w / 2, 8, vw - w - 8), y = clamp(p.y, 8, vh - h - 8);
    ctx.fillStyle = 'rgba(10,20,32,.92)'; ctx.strokeStyle = pill.ok ? '#2fd27a' : '#ff5a4f'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.roundRect(x, y, w, h, 14); ctx.fill(); ctx.stroke();
    if (pill.dot) { ctx.fillStyle = pill.dot; ctx.beginPath(); ctx.arc(ar ? x + 14 : x + w - 14, y + (pill.text2 ? 14 : h / 2), 5.5, 0, 6.2832); ctx.fill(); }
    ctx.fillStyle = '#fff'; ctx.textBaseline = 'middle'; ctx.fillText(pill.text, ar ? x + w - 12 : x + 12 + dotW, y + (pill.text2 ? 14 : h / 2) + 1);
    if (pill.text2) { ctx.font = F2; ctx.fillStyle = 'rgba(210,225,240,.85)'; ctx.fillText(pill.text2, ar ? x + w - 12 : x + 12, y + 33); }
    ctx.direction = 'ltr'; ctx.textAlign = 'left';
  }

  /* ---------- minimap ---------- */
  function drawMini() {
    const w = mini.width, h = mini.height;
    mctx.setTransform(1, 0, 0, 1, 0, 0);
    mctx.fillStyle = '#0b4766'; mctx.fillRect(0, 0, w, h);
    const tw = TERR.w, th = TERR.h;
    const sc = Math.min(w / tw, h / th), ox = (w - tw * sc) / 2, oy = (h - th * sc) / 2;
    mctx.drawImage(TERR.mini, ox, oy, tw * sc, th * sc);
    const m = (wx, wy) => [ox + (wx - TERR.minX) * sc, oy + (wy - TERR.minY) * sc];
    for (const b of game.buildings) {
      const p = b.type === 'tank' ? m((b.x - b.y) * 32, (b.x + b.y + 2) * 16) : m(...cc(b.x, b.y));
      mctx.fillStyle = b.type === 'tank' ? '#ffffff' : '#ff5a4f';
      mctx.beginPath(); mctx.arc(p[0], p[1], (b.type === 'tank' ? 3.2 : 2.4) * dpr, 0, 6.2832); mctx.fill();
    }
    mctx.fillStyle = '#4aa8ff';
    for (let k = 0; k < game.pipe.length; k++) if (game.pipe[k]) { const p = m(...cc(k % W, (k / W) | 0)); mctx.fillRect(p[0] - dpr, p[1] - dpr, 2 * dpr, 2 * dpr); }
    const a = m(cam.x - vw / 2 / cam.z, cam.y - vh / 2 / cam.z), b2 = m(cam.x + vw / 2 / cam.z, cam.y + vh / 2 / cam.z);
    mctx.strokeStyle = '#fff'; mctx.lineWidth = 1.5 * dpr; mctx.strokeRect(a[0], a[1], b2[0] - a[0], b2[1] - a[1]);
  }
  function miniNav(e) {
    const r = mini.getBoundingClientRect(), tw = TERR.w, th = TERR.h;
    const sc = Math.min(r.width / tw, r.height / th), ox = (r.width - tw * sc) / 2, oy = (r.height - th * sc) / 2;
    cam.x = (e.clientX - r.left - ox) / sc + TERR.minX; cam.y = (e.clientY - r.top - oy) / sc + TERR.minY; clampCam();
  }
  let miniDown = false;
  mini.addEventListener('pointerdown', e => { camGoal.on = false; miniDown = true; mini.setPointerCapture(e.pointerId); miniNav(e); });
  mini.addEventListener('pointermove', e => { if (miniDown) miniNav(e); });
  mini.addEventListener('pointerup', () => { miniDown = false; });
  mini.addEventListener('pointercancel', () => { miniDown = false; });

  // Tall buildings are picked by their drawn shape, not just their ground tile.
  function pickBuilding(sx, sy) {
    const w = s2w(sx, sy), list = game.buildings.slice().sort((a, b) => (b.x + b.y + (b.type === 'tank' ? 2 : 0)) - (a.x + a.y + (a.type === 'tank' ? 2 : 0)));
    for (const b of list) {
      if (b.type === 'well') { const [cx, cy] = cc(b.x, b.y); if (w.x > cx - 52 && w.x < cx + 48 && w.y > cy - 84 && w.y < cy + 28) return b; }
      else if (b.type === 'pump') { const [cx, cy] = cc(b.x, b.y); if (w.x > cx - 48 && w.x < cx + 48 && w.y > cy - 52 && w.y < cy + 24) return b; }
      else { const cx = (b.x - b.y) * 32, cy = (b.x + b.y + 2) * 16; if (w.x > cx - 56 && w.x < cx + 56 && w.y > cy - 80 && w.y < cy + 34) return b; }
    }
    return null;
  }

  /* ================= Input =================
     Touch priority: 1 modal / UI (separate DOM layers, never reach the canvas) -> 2 building placement -> 3 pipe drawing -> 4 camera pan -> tap.
     One finger in a build tool moves the preview, in the pipe tool it draws; it never pans the camera there (two fingers always pan + zoom).
     A touch becomes a drag after DRAG_PX px and is then never a tap; a long press is not a tap either. */
  const ptrs = new Map();
  let pinch = null, gesture = false;
  const local = e => { const r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  const DRAG_PX = type => type === 'mouse' ? 5 : 10;            // px of movement before a touch is a drag
  const TAP_MAX = 700, TAP_GAP = 140, CONFIRM_GAP = 450;   // ms: longest tap, shortest gap between taps, shortest gap before a second tap confirms
  const PLACE_TOOLS = ['well', 'tank', 'pump'];
  const placeTool = () => PLACE_TOOLS.includes(ui.tool);
  /* One input mode owns a gesture at a time. It is derived from the real UI state (never stored twice), in priority order:
     UI_INTERACTION (a modal is open) > PINCH_ZOOM (two fingers) > PIPE_DRAWING (pipe tool) > BUILDING_PLACEMENT (build tool)
     > SELECTING (an object is selected) > DEFAULT (camera pan / tap). */
  const IM = { DEFAULT: 'DEFAULT', SELECTING: 'SELECTING', BUILDING_PLACEMENT: 'BUILDING_PLACEMENT', PIPE_DRAWING: 'PIPE_DRAWING', PINCH_ZOOM: 'PINCH_ZOOM', UI_INTERACTION: 'UI_INTERACTION' };
  function inputMode() {
    if (!mk.hidden || !stm.hidden || !$('#regions').hidden) return IM.UI_INTERACTION;
    if (pinch || ptrs.size >= 2) return IM.PINCH_ZOOM;
    if (ui.tool === 'pipe') return IM.PIPE_DRAWING;
    if (placeTool()) return IM.BUILDING_PLACEMENT;
    return ui.sel ? IM.SELECTING : IM.DEFAULT;
  }
  const uvOf = worldToGrid;
  const gOff = { x: 0, y: 0 };                             // the preview glides: when it snaps to another cell this offset eases back to 0 (no jumps)
  const pd = { on: false, gu: 0, gv: 0, fx: 0, fy: 0 };    // placement drag state (grid units, finger)
  function setPending(c) { ui.pending = c; ui.pendT = performance.now(); }
  function placeSet(x, y) {
    const t0 = ui.pending;
    if (!inb(x, y)) return;
    if (t0 && t0.x === x && t0.y === y) return;
    if (t0) { gOff.x += ((t0.x - t0.y) - (x - y)) * 32; gOff.y += ((t0.x + t0.y) - (x + y)) * 16; }
    setPending({ x, y }); updateConfirm();
  }
  function placeMoveWorld(dxw, dyw) {                      // move the preview by a world-space delta, with hysteresis so it never flickers between cells
    const [du, dv] = uvOf(dxw, dyw); pd.gu += du; pd.gv += dv;
    const cur = ui.pending || { x: Math.floor(pd.gu), y: Math.floor(pd.gv) };
    const nx = Math.abs(pd.gu - (cur.x + .5)) < .62 ? cur.x : Math.floor(pd.gu), ny = Math.abs(pd.gv - (cur.y + .5)) < .62 ? cur.y : Math.floor(pd.gv);
    placeSet(clamp(nx, 0, W - 1), clamp(ny, 0, H - 1));
  }
  function stepPlacing(real) {
    const k = Math.exp(-Math.min(real, .05) * 14); gOff.x *= k; gOff.y *= k;
    if (Math.abs(gOff.x) < .05) gOff.x = 0; if (Math.abs(gOff.y) < .05) gOff.y = 0;
    if (!pd.on) return;                                    // dragging a preview near the screen edge scrolls the map so it can be carried further
    const mx = 46, top = 130, bot = vh - 190; let sx = 0, sy = 0;
    if (pd.fx < mx) sx = -(1 - pd.fx / mx); else if (pd.fx > vw - mx) sx = 1 - (vw - pd.fx) / mx;
    if (pd.fy < top) sy = -(1 - pd.fy / top) * .6; else if (pd.fy > bot) sy = (pd.fy - bot) / 150 * .6;
    if (!sx && !sy) return;
    const px = clamp(sx, -1, 1) * 300 * Math.min(real, .05) / cam.z, py = clamp(sy, -1, 1) * 300 * Math.min(real, .05) / cam.z;
    const x0 = cam.x, y0 = cam.y; cam.x += px; cam.y += py; clampCam(); placeMoveWorld(cam.x - x0, cam.y - y0);
  }
  function startPlaceDrag(q) {
    pd.on = true; pd.fx = q.x; pd.fy = q.y; ui.placeDrag = true;
    if (!ui.pending) { const c = cellAt(q.sx, q.sy - 48); if (inb(c.x, c.y)) { setPending(c); gOff.x = gOff.y = 0; updateConfirm(); } }   // starts above the finger so the hand does not hide it
    const c = ui.pending; if (c) { pd.gu = c.x + .5; pd.gv = c.y + .5; }
  }
  function finishPlaceDrag() {
    pd.on = false; ui.placeDrag = false;
    const c = ui.pending; if (!c) return;
    if (!game.canPlace(ui.tool, c.x, c.y).ok) {            // dropped on a bad spot: glide to the nearest good one (if any), otherwise stay and say why
      const sn = snapBuild(ui.tool, c);
      if (sn && (sn.x !== c.x || sn.y !== c.y)) { gOff.x += ((c.x - c.y) - (sn.x - sn.y)) * 32; gOff.y += ((c.x + c.y) - (sn.x + sn.y)) * 16; setPending({ x: sn.x, y: sn.y }); }
    }
    updateConfirm();
  }

  cv.addEventListener('pointerdown', e => {
    if (inputMode() === IM.UI_INTERACTION) return;                // a modal owns every touch
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* pointer already gone */ }
    const p = local(e), touch = e.pointerType !== 'mouse';
    ptrs.set(e.pointerId, { x: p.x, y: p.y, sx: p.x, sy: p.y, moved: false, type: e.pointerType, button: e.button, drag: null, t0: performance.now(), place: false, noPan: false, sink: false });
    const q = ptrs.get(e.pointerId);
    ui.ptype = touch ? 'touch' : 'mouse';
    camGoal.on = false;                                           // the player takes the camera back at once
    // Phase 23: pipes are built with two taps (start node, destination node). A drag in pipe mode is a normal camera pan, never a pipe.
    if (ptrs.size === 1 && touch && placeTool()) q.place = true;
    else if (ptrs.size === 1 && touch && pickBuilding(p.x, p.y)) q.onBld = true;   // a finger that starts ON a building never pans the camera (a tap selects it)
    if (ptrs.size === 2) {
      for (const v of ptrs.values()) { v.drag = null; v.place = false; v.noPan = false; v.onBld = false; }
      if (ui.pipeDragging) { ui.pipeDragging = false; cancelAction(); }
      if (pd.on) { pd.on = false; ui.placeDrag = false; }
      const [a, b] = [...ptrs.values()];
      pinch = { d: Math.max(8, Math.hypot(a.x - b.x, a.y - b.y)), z: cam.z };
      gesture = true;
    }
  });
  cv.addEventListener('pointermove', e => {
    const p = local(e), q = ptrs.get(e.pointerId);
    if (!q) { if (e.pointerType === 'mouse') { ui.hover = cellAt(p.x, p.y); ui.mouse = p; } return; }
    if (e.pointerType === 'mouse') { ui.hover = cellAt(p.x, p.y); ui.mouse = p; }
    if (ptrs.size === 2 && pinch) {                                // two fingers: zoom around their midpoint, and pan with it
      q.x = p.x; q.y = p.y;
      const [a, b] = [...ptrs.values()], d = Math.hypot(a.x - b.x, a.y - b.y), mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      const before = s2w(mx, my); cam.z = clamp(pinch.z * d / pinch.d, cam.minZoom, cam.maxZoom);
      const after = s2w(mx, my); cam.x += before.x - after.x; cam.y += before.y - after.y; clampCam();
      return;
    }
    if (q.sink) { q.x = p.x; q.y = p.y; return; }                  // the finger left over after a pinch does nothing until it is lifted
    const th = DRAG_PX(q.type);
    if (q.drag && ptrs.size === 1) {                               // drag a pipe: well -> tank, the path is built on the grid
      if (!q.moved && Math.hypot(p.x - q.sx, p.y - q.sy) > th) { q.moved = true; ui.pipeStart = q.drag; ui.pipeDragging = true; setPending(null); }
      if (q.moved) { const e2 = snapPipeEnd(cellAt(p.x, p.y), p.x, p.y), c = ui.pending; if (!c || c.x !== e2.x || c.y !== e2.y) { setPending(e2); updateConfirm(); } }
      q.x = p.x; q.y = p.y; return;
    }
    if (q.place && ptrs.size === 1) {                              // drag a building preview: relative movement, snapped to the grid
      if (!q.moved && Math.hypot(p.x - q.sx, p.y - q.sy) > th) { q.moved = true; q.x = q.sx; q.y = q.sy; startPlaceDrag(q); }   // the preview follows from the touch-down point: the first few pixels are not lost
      if (q.moved) { pd.fx = p.x; pd.fy = p.y; placeMoveWorld((p.x - q.x) / cam.z, (p.y - q.y) / cam.z); }
      q.x = p.x; q.y = p.y; return;
    }
    if (q.noPan) {                                                 // pipe tool, finger started away from anything a pipe can start at: no camera pan, say what to do
      if (!q.moved && Math.hypot(p.x - q.sx, p.y - q.sy) > th) { q.moved = true; const n = performance.now(); if (n - (ui.hintT || 0) > 2500) { ui.hintT = n; toast(help('floating'), 'info'); } }
      q.x = p.x; q.y = p.y; return;
    }
    if (q.onBld) { if (Math.hypot(p.x - q.sx, p.y - q.sy) > th) q.moved = true; q.x = p.x; q.y = p.y; return; }   // buildings cannot be moved: the drag does nothing (no pan, no select)
    const dx = p.x - q.x, dy = p.y - q.y;
    if (!q.moved && Math.hypot(p.x - q.sx, p.y - q.sy) > th) { q.moved = true; cv.classList.add('dragging'); }
    if (q.moved) { cam.x -= dx / cam.z; cam.y -= dy / cam.z; clampCam(); }
    q.x = p.x; q.y = p.y;
  });
  let lastTap = { t: 0, x: -99, y: -99 };
  const end = e => {
    const q = ptrs.get(e.pointerId); if (!q) return;
    ptrs.delete(e.pointerId); cv.classList.remove('dragging');
    const up = e.type === 'pointerup';
    if (q.drag && q.moved) finishPipeDrag(up && !gesture);
    if (q.place && q.moved) finishPlaceDrag();
    if (ptrs.size < 2) pinch = null;
    if (gesture && ptrs.size === 1) for (const v of ptrs.values()) { v.sink = true; v.moved = true; }
    if (ptrs.size === 0) {
      const now = performance.now();
      const isTap = !q.moved && !q.sink && !gesture && up && (q.button === 0 || q.type !== 'mouse') && now - q.t0 <= TAP_MAX;
      if (isTap && !(now - lastTap.t < TAP_GAP && Math.hypot(q.x - lastTap.x, q.y - lastTap.y) < 14)) { lastTap = { t: now, x: q.x, y: q.y }; onTap(cellAt(q.x, q.y), q.x, q.y); }
      gesture = false;
    }
  };
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  cv.addEventListener('lostpointercapture', e => { if (ptrs.has(e.pointerId)) end({ pointerId: e.pointerId, type: 'pointercancel' }); });   // the finger left the screen / the window without a pointerup
  function resetGestures() {                                       // never leave a stuck gesture behind (touchcancel, app switch, lost focus)
    ptrs.clear(); pinch = null; gesture = false; pd.on = false; ui.placeDrag = false; cv.classList.remove('dragging');
    if (ui.pipeDragging) { ui.pipeDragging = false; cancelAction(); }
  }
  cv.addEventListener('touchcancel', resetGestures);
  addEventListener('blur', resetGestures);
  // A tap on the map can change the layout under the finger (the confirm bar appears). The browser's follow-up "click" would then hit
  // whatever moved there, so it is cancelled, and a click on another control at the same spot right after a map tap is ignored.
  let lastMapTouch = { t: 0, x: -99, y: -99 };
  cv.addEventListener('touchend', e => { const c = e.changedTouches[0]; lastMapTouch = { t: performance.now(), x: c ? c.clientX : -99, y: c ? c.clientY : -99 }; if (e.cancelable) e.preventDefault(); }, { passive: false });
  document.addEventListener('click', e => {      // a ghost click lands where the finger just lifted; a real tap on a button elsewhere is never blocked
    if (e.isTrusted && performance.now() - lastMapTouch.t < 500 && !cv.contains(e.target) && Math.hypot(e.clientX - lastMapTouch.x, e.clientY - lastMapTouch.y) < 14) { e.stopPropagation(); e.preventDefault(); }
  }, true);
  cv.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') { ui.hover = null; ui.mouse = null; } });
  cv.addEventListener('contextmenu', e => e.preventDefault());
  cv.addEventListener('wheel', e => {
    e.preventDefault(); camGoal.on = false;
    const p = local(e), before = s2w(p.x, p.y);
    cam.z = clamp(cam.z * Math.exp(-(e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY) * .0015), cam.minZoom, cam.maxZoom);
    const after = s2w(p.x, p.y); cam.x += before.x - after.x; cam.y += before.y - after.y; clampCam();
  }, { passive: false });

  const keys = new Set();
  addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT') return;
    const k = e.key.toLowerCase();
    if (k === 'escape') { backStep(); return; }
    if (k === 'enter') { confirmPending(); return; }
    if (k === 'r') { if (ui.tool === 'pump') ui.pumpFlip = !ui.pumpFlip; else if (selBuilding() && selBuilding().type === 'pump') { game.flipPump(selBuilding()); updatePanel(); } else ui.flip = !ui.flip; return; }
    if (k === 'd' && e.shiftKey) { setDebug(!dbg.on); return; }
    const map = { 1: 'select', 2: 'well', 3: 'pipe', 4: 'tank', 5: 'pump', 6: 'explore', 7: 'erase' };
    if (map[k]) { setTool(map[k]); return; }
    if (k === 'm') { openMarket(); return; }
    if (k === '+' || k === '=') cam.z = clamp(cam.z * 1.15, cam.minZoom, cam.maxZoom);
    if (k === '-') cam.z = clamp(cam.z / 1.15, cam.minZoom, cam.maxZoom);
    keys.add(k);
  });
  addEventListener('keyup', e => keys.delete(e.key.toLowerCase()));

  /* ================= Phase 5 polish: easy building, drag-to-pipe, smooth camera, first-game guide ================= */
  // Valid spots for wells / tanks, recomputed only when something that matters changes (not every frame).
  const spotCache = {};
  function getSpots(tool) {
    const key = game.buildings.length + '|' + game.pipeCount() + '|' + game.areas.reduce((n, a) => n + a.st, 0) + '|' + game.s.regions.map(r => +r.unlocked).join('');
    const c = spotCache[tool];
    if (c && c.key === key) return c.list;
    const list = game.validSpots(tool); spotCache[tool] = { key, list }; return list;
  }
  // Tapping near a valid spot moves the building to it, so nobody has to hit the exact tile.
  function snapBuild(tool, cell) {
    if (!cell || !inb(cell.x, cell.y) || game.canPlace(tool, cell.x, cell.y).ok) return cell;
    const p = game.nearestValid(tool, cell.x, cell.y, 3, getSpots(tool));
    return p ? { x: p[0], y: p[1], snapped: true } : cell;
  }
  function cellOrBuilding(cell, sx, sy) {
    if (sx != null) { const pb = pickBuilding(sx, sy); if (pb) return { x: pb.x, y: pb.y }; }
    return cell;
  }
  // Pipe start: a well, tank or pipe (or the tile beside one); pipe end: snaps onto a nearby well, tank or pipe.
  function snapPipeStart(cell, sx, sy) {
    cell = cellOrBuilding(cell, sx, sy);
    if (!inb(cell.x, cell.y)) return null;
    if (game.isAnchor(cell.x, cell.y)) return cell;
    const a = game.nearestAnchor(cell.x, cell.y, 2); return a ? { x: a[0], y: a[1], snapped: true } : null;
  }
  function snapPipeEnd(cell, sx, sy) {
    cell = cellOrBuilding(cell, sx, sy);
    if (!inb(cell.x, cell.y) || game.isAnchor(cell.x, cell.y) || !ui.pipeStart) return cell;
    const a = game.nearestAnchor(cell.x, cell.y, 2);
    if (!a) return cell;
    const st = ui.pipeStart, sb = game.occ[idx(st.x, st.y)];
    if ((sb && game.occ[idx(a[0], a[1])] === sb) || Math.hypot(a[0] - st.x, a[1] - st.y) < 2) return cell;   // never snap back onto where the pipe started
    return { x: a[0], y: a[1], snapped: true };
  }
  function dragStart(sx, sy, touch) {
    const cell = cellOrBuilding(cellAt(sx, sy), sx, sy);
    if (!inb(cell.x, cell.y)) return null;
    const k = idx(cell.x, cell.y);
    if (game.occ[k] || game.pipe[k] || game.isAnchor(cell.x, cell.y)) return cell;
    if (touch) { const a = game.nearestAnchor(cell.x, cell.y, 2); if (a) return { x: a[0], y: a[1], snapped: true }; }      // fingers are fat: the start snaps to the nearest well, tank or pipe
    return null;
  }
  function finishPipeDrag(ok) {
    ui.pipeDragging = false;
    if (!ok || !ui.pending || !ui.pipeStart || (ui.pending.x === ui.pipeStart.x && ui.pending.y === ui.pipeStart.y)) { cancelAction(); return; }
    if (!needConfirm()) placePipe(ui.pending); else updateConfirm();
  }

  /* smooth camera: glide to an object instead of jumping */
  const camGoal = { on: false, x: 0, y: 0, z: 0, t: 0 };
  function focusOn(wx, wy, opt) {                                  // glide the camera to a world point; opt: { minZoom, force, instant }
    opt = opt || {};
    const narrow = vw < 700, z = Math.max(cam.z, opt.minZoom || .75);
    const p = w2s(wx, wy);
    const inside = p.x > vw * .14 && p.x < vw * .86 && p.y > vh * .16 && p.y < vh * (narrow ? .5 : .78);
    if (inside && !opt.force && cam.z >= (opt.minZoom || .75) - 1e-6) return;
    const g = fitView(wx, wy + (narrow ? vh * .17 : vh * .05) / z, z);   // the goal is always a legal camera, so the glide really ends
    if (opt.instant) { cam.x = g.x; cam.y = g.y; cam.z = g.z; camGoal.on = false; return; }
    camGoal.on = true; camGoal.x = g.x; camGoal.y = g.y; camGoal.z = g.z; camGoal.t = 0;
  }
  function stepCamera(real) {
    if (!camGoal.on) return;
    const k = 1 - Math.exp(-Math.min(real, .034) * 5.5);   // capped step: a slow frame never turns the glide into a jump
    const px = cam.x, py = cam.y;
    cam.x += (camGoal.x - cam.x) * k; cam.y += (camGoal.y - cam.y) * k; cam.z += (camGoal.z - cam.z) * k; clampCam();
    camGoal.t += real;
    if ((Math.abs(camGoal.x - cam.x) < .6 && Math.abs(camGoal.y - cam.y) < .6 && Math.abs(camGoal.z - cam.z) < .004) || camGoal.t > 2.5 || (Math.abs(px - cam.x) + Math.abs(py - cam.y) < .01 && camGoal.t > .3)) camGoal.on = false;
  }
  function focusSel(s) {
    if (!s) return;
    if (s.kind === 'b') { const b = game.buildings.find(q => q.id === s.id); if (b) { const c = b.type === 'tank' ? [(b.x - b.y) * 32, (b.x + b.y + 2) * 16 - 20] : cc(b.x, b.y); focusOn(c[0], c[1] - (b.type === 'tank' ? 0 : 30)); } }
    else if (s.kind === 'pipe') { const c = cc(s.k % W, (s.k / W) | 0); focusOn(c[0], c[1]); }
    else if (s.kind === 'area') { const a = game.areas.find(q => q.id === s.id); if (a) { const c = cc(a.ax * 4 + 2, a.ay * 4 + 2); focusOn(c[0], c[1]); } }
  }

  /* overlays: valid spots, pipe anchors, coach markers */
  function drawSpots(tool) {
    const list = getSpots(tool), pul = .22 + .1 * Math.sin(tNow * 4), n = game.footprintOf(tool)[1];
    const hw = vw / 2 / cam.z + 70, hh = vh / 2 / cam.z + 70;
    ctx.fillStyle = 'rgba(47,210,122,' + pul.toFixed(3) + ')'; ctx.beginPath();
    for (const p of list) {
      const cx = (p[0] - p[1]) * 32, cy = (p[0] + p[1]) * 16 + 16 * n;
      if (Math.abs(cx - cam.x) > hw || Math.abs(cy - cam.y) > hh) continue;
      const r = tool === 'tank' ? 9 : 22;
      ctx.moveTo(cx, cy - r / 2); ctx.lineTo(cx + r, cy); ctx.lineTo(cx, cy + r / 2); ctx.lineTo(cx - r, cy); ctx.closePath();
    }
    ctx.fill();
  }
  function ringAt(x, y, col, n, pulse) {
    const cx = (x - y) * 32, cy = (x + y) * 16 + 16 * (n || 1), r = (n === 2 ? 66 : 36) * (1 + (pulse ? .1 * Math.sin(tNow * 5) : 0));
    ctx.strokeStyle = col; ctx.lineWidth = 3 / cam.z; ctx.beginPath(); ctx.ellipse(cx, cy, r, r / 2, 0, 0, 6.2832); ctx.stroke();
  }
  function arrowAt(x, y, n) {
    const cx = (x - y) * 32, cy = (x + y) * 16 + 16 * (n || 1) - (n === 2 ? 70 : 60), b = Math.sin(tNow * 5) * 7;
    ctx.fillStyle = '#ffb41f'; ctx.strokeStyle = '#2a1a00'; ctx.lineWidth = 2 / cam.z;
    ctx.beginPath(); ctx.moveTo(cx, cy + b + 20); ctx.lineTo(cx - 13, cy + b); ctx.lineTo(cx - 5, cy + b); ctx.lineTo(cx - 5, cy + b - 16); ctx.lineTo(cx + 5, cy + b - 16); ctx.lineTo(cx + 5, cy + b); ctx.lineTo(cx + 13, cy + b); ctx.closePath(); ctx.fill(); ctx.stroke();
  }
  function drawCoachMarks() {
    if (!coach.step || !coach.marks.length) return;
    for (const m of coach.marks) {
      const pulse = .5 + .3 * Math.sin(tNow * 5);
      footprint(m.n === 2 ? 'tank' : 'well', m.x, m.y, 'rgba(255,180,31,' + (pulse * .3).toFixed(3) + ')', 'rgba(255,180,31,' + (pulse + .3).toFixed(3) + ')');
      ringAt(m.x, m.y, 'rgba(255,200,80,.9)', m.n, true); if (!m.noArrow) arrowAt(m.x, m.y, m.n);
    }
  }

  /* first-game guide: the current step comes from the real game state; finishing the first sale saves tutorialCompleted */
  const coach = { step: null, marks: [], plan: null, spot: null, focused: '' };
  function coachStep() {
    const s = game.s; if (s.tutorialDone) return null;
    const wells = game.buildings.filter(b => b.type === 'well'), tanks = game.buildings.filter(b => b.type === 'tank');
    if (!wells.length) return 'well';
    if (!tanks.length) return 'tank';
    if (!game.pipeCount()) return 'pipe';
    if (game.underConstruction() && !wells.some(w => game.isWellConnected(w))) return 'build';
    if (!wells.some(w => game.isWellConnected(w))) return 'link';
    if (game.oilTotal() < 8) return 'wait';
    return 'sell';
  }
  function coachPlan(well) {   // a tank spot with a free pipe end on the side facing the well, so "drag the pipe" has a real target
    const spots = getSpots('tank').map(p => [p, Math.hypot(p[0] - well.x, p[1] - well.y)]).filter(q => q[1] >= 5 && q[1] <= 11).sort((a, b) => a[1] - b[1]).slice(0, 40);
    for (const [T] of spots) {
      const E = well.x < T[0] ? [T[0] - 1, T[1]] : well.x > T[0] + 1 ? [T[0] + 2, T[1]] : well.y < T[1] ? [T[0], T[1] - 1] : [T[0], T[1] + 2];
      if (!inb(E[0], E[1]) || Math.hypot(E[0] - well.x, E[1] - well.y) < 3) continue;   // far enough that the drag is a real gesture
      const r = game.routePipe(well.x, well.y, E[0], E[1], false, 0);
      if (r.ok && !r.cells.some(c => c[0] >= T[0] && c[0] <= T[0] + 1 && c[1] >= T[1] && c[1] <= T[1] + 1)) return { T, E };
    }
    return null;
  }
  function tankSpotNearPipe(well) {
    let best = null, bd = 1e9;
    for (const p of getSpots('tank')) {
      let adj = false;
      for (let dy = -1; dy <= 2 && !adj; dy++) for (let dx = -1; dx <= 2; dx++) { const inside = dx >= 0 && dx <= 1 && dy >= 0 && dy <= 1; if (!inside && inb(p[0] + dx, p[1] + dy) && game.pipe[idx(p[0] + dx, p[1] + dy)]) { adj = true; break; } }
      const d = Math.hypot(p[0] - well.x, p[1] - well.y);
      if (adj && d < bd) { bd = d; best = p; }
    }
    return best;
  }
  function updateCoach() {
    const el = $('#coach'), step = coachStep();
    $$('.coach-pulse').forEach(b => b.classList.remove('coach-pulse'));
    if (!step) { if (coach.step) { coach.step = null; coach.marks = []; } el.hidden = true; return; }
    const changed = step !== coach.step; coach.step = step; coach.marks = [];
    const wells = game.buildings.filter(b => b.type === 'well'), tanks = game.buildings.filter(b => b.type === 'tank');
    const pulse = sel => { const b = $(sel); if (b) b.classList.add('coach-pulse'); };
    const tool = ui.tool, needTool = n => { if (!ui.menu) pulse('#btn-build'); else if (tool !== n) pulse('[data-tool=' + n + ']'); return tool === n; };
    let num = 1;
    if (step === 'well') {
      num = 1; needTool('well');
      if (!coach.spot || !game.canPlace('well', coach.spot[0], coach.spot[1]).ok) { const c = cellAt(vw / 2, vh / 2); coach.spot = game.nearestValid('well', c.x, c.y, 99, getSpots('well')); }
      if (coach.spot) coach.marks.push({ x: coach.spot[0], y: coach.spot[1], n: 1 });
    } else if (step === 'tank') {
      num = 2; needTool('tank');
      const w = wells[0]; if (!coach.plan || !game.canPlace('tank', coach.plan.T[0], coach.plan.T[1]).ok) coach.plan = coachPlan(w);
      const T = (coach.plan && coach.plan.T) || tankSpotNearPipe(w) || (getSpots('tank')[0]);
      if (T) coach.marks.push({ x: T[0], y: T[1], n: 2 });
    } else if (step === 'pipe' || step === 'link') {
      num = 3; needTool('pipe'); const w = wells[0], tk = tanks[0];
      const a = ui.pipeA === 'B' + w.id;                                  // first the well, then the tank
      coach.marks.push({ x: (a ? tk : w).x, y: (a ? tk : w).y, n: a ? 2 : 1 });
    } else if (step === 'build') {
      num = 3; const tk = tanks[0]; coach.marks.push({ x: tk.x, y: tk.y, n: 2, noArrow: true });
    } else if (step === 'wait') {
      num = 4; const tk = tanks[0]; coach.marks.push({ x: tk.x, y: tk.y, n: 2, noArrow: true });
    } else if (step === 'sell') {
      num = 5; if (mk.hidden) pulse('#btn-market'); else pulse('#sp-go');
    }
    el.hidden = !!ui.pending;                         // while a build is waiting for confirmation the bar below says everything needed
    $('#coach .cn').textContent = num + '/5';
    $('#coach .ct').innerHTML = t('co.' + step);
    if (changed || (coach.focused !== step + (coach.marks[0] ? coach.marks[0].x + ',' + coach.marks[0].y : ''))) {
      coach.focused = step + (coach.marks[0] ? coach.marks[0].x + ',' + coach.marks[0].y : '');
      if (coach.marks[0] && ui.ptype) { const m = coach.marks[0], c = cc(m.x, m.y); focusOn(c[0], c[1] - (m.n === 2 ? 10 : 20)); }
    }
  }
  $('#coach .cskip').addEventListener('click', () => { game.s.tutorialDone = true; updateCoach(); updateHint(); toast(t('co.skipped'), 'info'); save(); });

  /* ================= Actions ================= */
  const BUILD_TOOLS = ['well', 'pipe', 'tank', 'pump', 'explore', 'erase'];
  const costOf = (tool, cell) => cell ? (tool === 'pipe' ? (ui.pipeType ? CFG.COST.pipeMain : CFG.COST.pipe) : game.buildCost(tool, ui.wellKind, cell.x, cell.y)) : tool === 'well' ? CFG.WELL_KINDS[ui.wellKind].cost : tool === 'pipe' ? (ui.pipeType ? CFG.COST.pipeMain : CFG.COST.pipe) : CFG.COST[tool];
  function toast(msg, kind) {
    const el = document.createElement('div'); el.className = 'toast ' + (kind || 'info'); el.textContent = msg;
    const box = $('#toasts'); box.appendChild(el);
    while (box.children.length > 3) box.removeChild(box.firstChild);
    setTimeout(() => el.remove(), 3100);
  }
  function applyMenu() {
    $('#buildmenu').hidden = !ui.menu;
    $('#btn-build').classList.toggle('open', ui.menu);
    $('#app').classList.toggle('build-open', ui.menu);
    $$('.tool[data-tool]').forEach(b => b.classList.toggle('active', b.dataset.tool === ui.tool && (b.dataset.tool !== 'pipe' || (b.dataset.pipeType === (ui.pipeType ? 'main' : 'sub')))));
    $('#kinds').hidden = ui.tool !== 'well';
    $$('#kinds button').forEach(b => b.classList.toggle('on', b.dataset.k === ui.wellKind));
    if (typeof updateCoach === 'function' && coach) updateCoach();
  }
  function setTool(tool) {
    if (ui.moveId != null) endMoveUI();                                 // choosing any tool while moving abandons the move (nothing was changed)
    if (tool !== 'select' && ui.tool === 'select' && ui.sel) ui.prevSel = ui.sel;            // remember what was selected before building, so leaving the build tool can give it back
    ui.tool = tool; ui.pipeStart = null; ui.pipeA = ui.pipeB = null; ui.pending = null; ui.erase = null; ui.route = null;
    if (BUILD_TOOLS.includes(tool)) ui.menu = true; else ui.menu = false;
    if (tool !== 'select' && !(tool === 'explore' && ui.sel && ui.sel.kind === 'area')) { ui.sel = null; renderPanel(); }
    cv.className = 'tool-' + tool;
    applyMenu(); updateConfirm(); updateHint();
  }
  function leaveBuild() {                                        // back to normal play: the previous selection (if it still exists) comes back
    const ps = ui.prevSel; ui.prevSel = null; setTool('select');
    if (ps && ps.kind === 'b' && game.buildings.some(b => b.id === ps.id)) { ui.sel = ps; renderPanel(); updateHint(); }   // restored quietly: no camera move
  }
  function toggleBuild() {
    if (ui.menu) return leaveBuild();
    if (ui.sel) ui.prevSel = ui.sel;
    ui.menu = true; ui.sel = null; renderPanel(); applyMenu(); updateHint();
  }
  // Back / Escape: exactly ONE step per press, in a fixed order: a window -> the preview or pipe being drawn -> the build tool -> the selection.
  // In plain play it does nothing (and never closes the game by accident).
  function anyModal() { return !mk.hidden || !$('#settings').hidden || !$('#regions').hidden; }
  function backStep() {
    if (anyModal()) { closeModals(); return 'modal'; }
    if (ui.moveId != null) { cancelMove(); return 'cancel'; }
    if (ui.pending || ui.pipeStart) { cancelAction(); return 'cancel'; }
    if (ui.tool !== 'select' || ui.menu) { leaveBuild(); return 'tool'; }
    if (ui.sel) { select(null); return 'selection'; }
    return 'none';
  }
  try {                                                         // Android hardware Back button / browser back: one sentinel history entry that is re-armed after each press
    history.replaceState({ oli: 0 }, ''); history.pushState({ oli: 1 }, '');
    addEventListener('popstate', () => { backStep(); try { history.pushState({ oli: 1 }, ''); } catch (e) { /* ignore */ } });
  } catch (e) { /* history may be unavailable */ }
  function cancelAction() { pd.on = false; ui.placeDrag = false; ui.pipeStart = null; ui.pipeA = ui.pipeB = null; ui.pending = null; ui.route = null; updateConfirm(); updateHint(); }
  const needConfirm = () => ui.ptype === 'touch' || prefs.confirm;

  // the connection node under a tap: the building hit by the finger, else the building / pipe on that tile, else a pipe within one tile
  function pickNode(cell, sx, sy) {
    if (inb(cell.x, cell.y) && game.pipe[idx(cell.x, cell.y)]) return game.nodeAt(cell.x, cell.y);   // the finger is ON a pipe tile: that pipe (a tall building drawn behind does not steal it)
    const pb = sx != null ? pickBuilding(sx, sy) : null; if (pb) return game.nodeById('B' + pb.id);
    let n = game.nodeAt(cell.x, cell.y); if (n) return n;
    let best = null, bd = 9;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const x = cell.x + dx, y = cell.y + dy; if (!inb(x, y)) continue; const m = game.nodeAt(x, y); if (m && dx * dx + dy * dy < bd) { bd = dx * dx + dy * dy; best = m; } }
    return best;
  }
  const nodeName = n => n.kind === 'b' ? (n.b.type === 'well' ? t('n.well.' + (n.b.kind || 'small')) : t('n.' + n.b.type)) : t('n.pipe');
  function onTap(cell, sx, sy) {
    if (ui.tapGuard && performance.now() < ui.tapGuard) return;           // the touch that confirmed a build must not also select / place something
    const tool = ui.tool;
    if ((tool === 'select' || tool === 'erase') && sx != null) {
      const pb = pickBuilding(sx, sy);
      if (pb) cell = { x: pb.x, y: pb.y };
    }
    if (!inb(cell.x, cell.y)) { if (tool === 'select') select(null); return; }
    if (tool === 'select') {
      const k = idx(cell.x, cell.y), b = game.occ[k];
      if (b) select({ kind: 'b', id: b.id }); else if (game.pipe[k]) select({ kind: 'pipe', k }); else select(null);
    } else if (tool === 'well' || tool === 'tank' || tool === 'pump') {
      cell = snapBuild(tool, cell);
      if (!needConfirm()) return placeBuilding(tool, cell);
      if (ui.pending && ui.pending.x === cell.x && ui.pending.y === cell.y) { if (performance.now() - ui.pendT > CONFIRM_GAP) confirmPending(); return; }   // a fast second tap is a double tap, not a confirm
      if (ui.pending) { gOff.x += ((ui.pending.x - ui.pending.y) - (cell.x - cell.y)) * 32; gOff.y += ((ui.pending.x + ui.pending.y) - (cell.x + cell.y)) * 16; }
      setPending(cell); updateConfirm();
    } else if (tool === 'pipe') {
      const n = pickNode(cell, sx, sy);
      if (!n) { toast(help('pickNode'), 'bad'); return; }
      if (!ui.pipeA) { ui.pipeA = n.id; ui.pipeStart = { x: n.x, y: n.y }; ui.pipeB = null; ui.route = null; ui.pending = null; toast(t('t.pipeFrom', { what: nodeName(n) }), 'info'); updateHint(); updateConfirm(); return; }
      if (n.id === ui.pipeA && !ui.pipeB) { cancelAction(); return; }                       // tapping the start again = cancel
      if (n.id === ui.pipeB) return;                                                          // the same destination again: nothing new (only the Confirm button builds)
      ui.pipeB = n.id; ui.route = game.routeNodes(ui.pipeA, ui.pipeB, ui.pipeType);          // the ONE route: shown now, built on Confirm (computed only on a tap)
      ui.pending = { x: n.x, y: n.y }; ui.pendT = performance.now(); updateConfirm(); updateHint();
    } else if (tool === 'explore') {
      const a = game.areaAt(cell.x, cell.y);
      if (!a || !a.land) { toast(help('nothing'), 'bad'); return; }
      select({ kind: 'area', id: a.id });
    } else if (tool === 'erase') eraseAt(cell);
  }

  function placeBuilding(type, cell) {
    const r = game.place(type, cell.x, cell.y, ui.wellKind, type === 'pump' ? pumpDirFor(cell) : undefined);
    if (!r.ok) { toast(help(r.reason), 'bad'); updateConfirm(); return; }
    toast(t('t.built', { what: type === 'well' ? t('n.well.' + ui.wellKind) : t('n.' + type), cost: money(r.cost) }), 'good');
    ui.pending = null; refreshHud(true);
    // Phase 21: building finished -> leave Build mode, go to Selection mode and select the new building (its panel + actions open at once)
    ui.prevSel = null; ui.tapGuard = performance.now() + 250; setTool('select');
    if (r.building && r.building.id != null) select({ kind: 'b', id: r.building.id }); else { updateConfirm(); updateHint(); }
  }
  function placePipe(cell) {
    const r = game.buildLine(ui.route);
    if (!r.ok) { toast(help(r.reason), 'bad'); return; }
    toast(t('t.pipe', { n: r.segments, cost: money(r.cost) }), 'good');
    ui.pipeStart = null; ui.pending = null; ui.route = null; ui.pipeA = ui.pipeB = null; refreshHud(true);
    ui.prevSel = null; ui.tapGuard = performance.now() + 250; setTool('select');           // pipe built: back to normal play
  }
  /* ---------- move a building (Phase 22): the same preview / confirm / cancel pipeline as building, but the core's canMove decides and it costs nothing ---------- */
  const verdict = (tool, x, y) => { if (!ui.moveId) return game.placement(tool, x, y, ui.wellKind); const r = game.canMove(ui.moveId, x, y); return { ok: r.ok, state: r.ok ? 'VALID' : 'INVALID', reason: r.reason, cost: 0 }; };
  function startMove(id) {
    const b = game.buildings.find(q => q.id === id); if (!b || (b.type !== 'well' && b.type !== 'tank')) return;
    setTool(b.type); ui.moveId = id; game.beginMove(id); ui.menu = false; applyMenu(); ui.sel = null; renderPanel(); toast(t('h.move'), 'info'); updateHint(); updateConfirm();
  }
  function endMoveUI() { if (ui.moveId == null) return; ui.moveId = null; game.endMove(); }
  function cancelMove() { const id = ui.moveId; endMoveUI(); ui.prevSel = null; setTool('select'); if (id != null && game.buildings.some(b => b.id === id)) select({ kind: 'b', id }); }   // nothing changed in the game: the building simply stays where it was
  function doMove() {
    const id = ui.moveId, p = ui.pending, b = game.buildings.find(q => q.id === id); if (!b || !p) return;
    const r = game.moveBuilding(id, p.x, p.y);
    if (!r.ok) { toast(help(r.reason), 'bad'); updateConfirm(); return; }
    toast(t('t.moved', { what: b.type === 'well' ? t('n.well.' + (b.kind || 'small')) : t('n.tank') }), 'good');
    ui.moveId = null; ui.pending = null; refreshHud(true); ui.prevSel = null; ui.tapGuard = performance.now() + 250; setTool('select'); select({ kind: 'b', id });
  }
  function confirmPending() {
    if (!ui.pending) return;
    if (ui.moveId != null) return doMove();
    if (ui.tool === 'pipe') placePipe(ui.pending); else placeBuilding(ui.tool, ui.pending);
  }
  function eraseAt(cell) {
    const k = idx(cell.x, cell.y), b = game.occ[k];
    if (!b && !game.pipe[k]) return;
    if (b && b.type === 'tank' && b.amt >= 50) {
      if (!ui.erase || ui.erase !== b.id) { ui.erase = b.id; toast(t('t.tankHolds', { n: num(b.amt) }), 'info'); return; }
    }
    ui.erase = null;
    const r = game.removeAt(cell.x, cell.y);
    if (r.ok) { toast(t('t.removed', { n: money(r.refund) }), 'info'); refreshHud(true); }
  }

  /* ================= Selection panel ================= */
  const panel = $('#panel');
  const DOT = { building: 'warn', producing: '', limited: 'warn', full: 'bad', nopipe: 'bad', nostorage: 'bad', idle: 'warn', broken: 'bad', depleted: 'bad' };
  function select(s) { ui.sel = s; ui.removeArm = 0; renderPanel(); updateHint(); focusSel(s); }
  const tankNo = t2 => game.buildings.filter(q => q.type === 'tank').indexOf(t2) + 1;
  function selBuilding() { return ui.sel && ui.sel.kind === 'b' ? game.buildings.find(b => b.id === ui.sel.id) : null; }
  const pct = v => Math.round(v * 100) + '%';
  function setBar(id, f, cls) { const el = $('#' + id + '-bar'); if (!el) return; el.style.width = clamp(f, 0, 1) * 100 + '%'; if (el.className !== cls) el.className = cls; }
  const good = (f, lo, bad) => f > lo ? '' : f > bad ? 'warn' : 'bad';
  const leaksOf = c => c ? c.pipes.filter(p => game.pipeSt[p] === 1) : [];

  function renderPanel() {
    const s = ui.sel;
    if (!s) { panel.hidden = true; panel.innerHTML = ''; return; }
    const b = selBuilding();
    if (s.kind === 'b' && !b) { panel.hidden = true; ui.sel = null; return; }
    const head = (title, lv) => '<div class="ph"><h3>' + title + (lv ? '<small>' + t('level', { n: lv }) + '</small>' : '') + '</h3><button class="x" data-act="close" type="button" aria-label="' + t('close') + '"><svg class="ic"><use href="#i-close"/></svg></button></div>';
    const row = (icon, label, id) => '<li><svg class="ic"><use href="#i-' + icon + '"/></svg><div><small>' + label + '</small><b id="' + id + '"></b></div></li>';
    const mrow = (label, id) => '<li><div style="flex:1"><small>' + label + '</small><div class="mini-meter"><div class="meter"><i id="' + id + '-bar"></i></div><b id="' + id + '"></b></div></div></li>';
    const btn = (cls, act, id) => '<button class="btn ' + cls + '" data-act="' + act + '" id="' + id + '" type="button"></button>';
    const moreBtn = '<li class="morebtn"><button type="button" data-act="more">' + t(ui.more ? 'p.less' : 'p.more') + '</button></li>', sec = x => x.replace(/<li>/g, '<li class="sec">');
    let html = '';
    if (s.kind === 'b' && b.type === 'well') {
      html = head(t('n.well.' + b.kind), b.level) +
        '<ul class="rows' + (ui.more ? ' more' : '') + '">' + row('drop', t('p.prod'), 'p-rate') +
        '<li><span class="dot" id="p-dot"></span><div><small>' + t('p.status') + '</small><b id="p-status"></b></div></li>' +
        '<li class="wide"><svg class="ic"><use href="#i-pipe"/></svg><div><small>' + t('p.net') + '</small><b id="p-net"></b></div></li>' +
        mrow(t('p.pressure'), 'p-pres') + mrow(t('p.cond'), 'p-cond') + moreBtn + sec(row('drop', t('p.quality'), 'p-qual') + row('market', t('p.reserve'), 'p-res') + row('gear', t('p.resP'), 'p-rp') + row('gear', t('p.whP'), 'p-wp') + row('gear', t('p.pumpHelp'), 'p-ph') + row('pipe', t('p.limit'), 'p-lim')) + '</ul>' +
        '<div class="pbtns">' + btn('blue', 'upgrade', 'p-up') + btn('orange', 'maint', 'p-mt') + btn('ghost', 'move', 'p-mv') + btn('ghost', 'remove', 'p-rm') + '</div>';
    } else if (s.kind === 'b' && b.type === 'pump') {
      html = head(t('p.pump'), b.level) +
        '<ul class="rows' + (ui.more ? ' more' : '') + '">' +
        '<li><span class="dot" id="p-dot"></span><div><small>' + t('p.status') + '</small><b id="p-status"></b></div></li>' + row('gear', t('p.boost'), 'p-boost') +
        row('drop', t('p.pflow'), 'p-pflow') + row('pipe', t('p.dir'), 'p-pdir') + moreBtn +
        sec(row('gear', t('p.pin'), 'p-pin') + row('gear', t('p.pout'), 'p-pout') + row('cash', t('p.power'), 'p-power') + row('market', t('p.eff'), 'p-eff')) + '</ul>' +
        '<div class="pbtns">' + btn('green', 'pumpToggle', 'p-pt') + btn('ghost', 'pumpFlip', 'p-pf') + btn('blue', 'upgrade', 'p-up') + btn('ghost wide', 'remove', 'p-rm') + '</div>';
    } else if (s.kind === 'b') {
      html = head(t('p.tank'), b.level) +
        '<ul class="rows">' + row('drop', t('p.amount'), 'p-amt') + row('tank', t('p.cap'), 'p-cap') + row('drop', t('p.quality'), 'p-qual') +
        '<li><div style="flex:1"><small>' + t('p.fill') + ' · ' + t('p.back') + '</small><div style="display:flex;align-items:center;gap:10px;margin-top:4px"><div class="meter"><i id="p-bar"></i></div><b id="p-pct"></b></div></div></li>' +
        row('pipe', t('p.inflow'), 'p-in') + '<li class="wide"><svg class="ic"><use href="#i-well"/></svg><div><small>' + t('p.srcs') + '</small><b id="p-src"></b></div></li></ul>' +
        '<div class="pbtns">' + btn('blue', 'upgrade', 'p-up') + btn('ghost', 'move', 'p-mv') + btn('ghost', 'remove', 'p-rm') +
        '<button class="btn green" data-act="market" type="button">' + t('p.openMarket') + '</button></div>';
    } else if (s.kind === 'pipe') {
      const c = game.pipeNet(s.k);
      html = head(t('p.pipe'), c ? c.level : 1) +
        '<ul class="rows' + (ui.more ? ' more' : '') + '">' + '<li class="wide"><span class="dot" id="p-dot2"></span><div><small>' + t('p.net') + '</small><b id="p-net"></b></div></li>' + row('drop', t('p.flow'), 'p-flow') + row('pipe', t('p.segs'), 'p-seg') + row('pipe', t('p.node'), 'p-node') +
        mrow(t('p.pipeCond'), 'p-cond') + moreBtn + sec(row('market', t('p.tcap'), 'p-tcap') + row('drop', t('p.lost'), 'p-lost') + row('gear', t('p.prs'), 'p-prs') + row('drop', t('p.vel'), 'p-vel') + row('gear', t('p.loss'), 'p-loss')) +
        '<li><span class="dot" id="p-dot"></span><div><small>' + t('p.leakState') + '</small><b id="p-leak"></b></div></li></ul>' +
        '<div class="pbtns">' + btn('blue', 'upgrade', 'p-up') + btn('orange', 'repair', 'p-rp') + btn('ghost', 'valve', 'p-vl') + btn('ghost', 'remove', 'p-rm') + btn('ghost wide', 'removeBranch', 'p-rb') + '</div>';
    } else {
      const a = game.areas[s.id]; s.last = a.st;
      const lk = !game.regionOpen(a.region);
      html = head(t('a.title')) +
        '<ul class="rows"><li><span class="dot" id="p-dot"></span><div><small>' + t('a.region') + '</small><b>' + t('r.' + a.region) + '</b></div></li><li><div><small>' + t('a.status') + '</small><b id="a-st"></b></div></li>' +
        (a.st === 2 ? row('drop', t('a.res'), 'a-kind') + row('market', t('a.size'), 'a-size') + row('market', t('a.left'), 'a-left') + row('drop', t('p.quality'), 'a-q') + row('drop', t('a.pot'), 'a-pot') + row('well', t('a.wells'), 'a-wells') : '') + '</ul>' +
        (lk ? '<p class="note">' + t('a.locked') + '</p>' : a.st === 0 ? '<p class="note">' + t('a.hidden') + '</p>' : a.kind === 'empty' && a.st === 2 ? '<p class="note">' + t('a.emptyNote') + '</p>' : '') +
        '<div class="pbtns">' + (lk ? btn('orange wide', 'regions', 'a-rg') : a.st === 0 ? btn('orange wide', 'explore', 'a-ex') : a.st === 2 && a.kind !== 'empty' && a.remaining > 0 ? btn('green wide', 'abuild', 'a-bd') : '') + '</div>';
    }
    panel.innerHTML = html; panel.hidden = false;
    updatePanel();
  }
  function setText(id, v) { const el = $('#' + id); if (el && el.textContent !== v) el.textContent = v; }
  function setBtn(el, txt, off) { if (!el) return; if (el.textContent !== txt) el.textContent = txt; if (el.disabled !== !!off) el.disabled = !!off; }
  function updatePanel() {
    const s = ui.sel; if (!s || panel.hidden) return;
    const b = selBuilding(), rm = $('#p-rm'), cash = game.s.cash;
    if (s.kind === 'b' && !b) { select(null); return; }
    if (s.kind === 'area') {
      const a = game.areas[s.id];
      if (s.last !== a.st) return renderPanel();
      const inf = game.areaInfo(a);
      setText('a-st', inf.state === 'exploring' ? t('a.s.exploring', { n: Math.round(inf.progress * 100) }) : t('a.s.' + inf.state));
      const dot = $('#p-dot'); if (dot) dot.className = 'dot ' + (a.st === 2 ? '' : 'warn');
      if (a.st === 2) {
        setText('a-kind', t('a.k.' + a.kind)); setText('a-size', num(inf.reserveSize) + ' ' + t('bbl')); setText('a-left', num(inf.remaining) + ' ' + t('bbl'));
        setText('a-q', t('q.' + a.quality)); setText('a-pot', num(inf.productionPotential) + ' ' + t('perMin')); setText('a-wells', String(inf.wells));
      }
      setBtn($('#a-ex'), a.st === 1 ? t('a.s.exploring', { n: Math.round(inf.progress * 100) }) : t('a.explore', { cost: money(game.exploreCost(a)) }), a.st !== 0 || cash < game.exploreCost(a));
      setBtn($('#a-rg'), t('a.openRegions'), false);
      setBtn($('#a-bd'), t('a.build'), false);
      return;
    }
    let maxed, cost;
    if (s.kind === 'b' && b.type === 'well') {
      const nom = game.wellNominal(b), out = b.out || 0, ar = game.areas[b.area];
      setText('p-rate', out.toFixed(1) + ' ' + t('perMin') + ' · ' + t('p.nominal', { n: nom.toFixed(1) }));
      setText('p-status', t('st.' + (b.status || 'idle'))); $('#p-dot').className = 'dot ' + (DOT[b.status] || 'warn');
      setText('p-pres', pct(b.pressure)); setBar('p-pres', b.pressure, good(b.pressure, .5, .25));
      setText('p-cond', pct(b.condition)); setBar('p-cond', b.condition, good(b.condition, .6, .3));
      setText('p-qual', t('q.' + b.quality)); setText('p-res', ar ? num(ar.remaining) + ' ' + t('bbl') : '—');
      const wn = game.wellNet(b);
      setText('p-net', wn.why === 'building' ? t('nw.building', { n: Math.round(wn.progress * 100) }) : wn.connected && wn.target ? t('nw.to', { n: tankNo(wn.target), len: wn.pathTiles }) + (wn.why === 'limited' ? ' · ' + t('nw.limited', { cap: num(CFG.PIPE.CAP[Math.max(1, ...game.net.comps[game.net.compOf[idx(b.x, b.y)]].pipes.map(k => game.pipeLvl[k])) - 1]) }) : '') : t('nw.' + (wn.why === 'full' ? 'full' : wn.connected ? 'full' : b.status === 'nopipe' ? 'nopipe' : b.status === 'broken' || b.status === 'depleted' ? b.status : 'nostorage')));
      const wh = game.wellHyd(b);
      setText('p-rp', wh.reservoirPressure.toFixed(1) + ' ' + t('u.bar')); setText('p-wp', wh.wellHeadPressure.toFixed(1) + ' ' + t('u.bar') + (wh.transient > .05 ? ' · ' + t('p.transient') + ' +' + wh.transient.toFixed(1) : ''));
      setText('p-ph', wh.pumpContribution > .05 ? '+' + wh.pumpContribution.toFixed(1) + ' ' + t('u.bar') : '—'); setText('p-lim', wh.limit && out < nom * .995 ? t('lim.' + wh.limit) : t('lim.none'));
      const mc = game.maintenanceCost(b), mgood = b.condition >= .999;
      setBtn($('#p-mt'), mgood ? t('p.maintGood') : t('p.maintBtn', { cost: money(mc) }), mgood || cash < mc);
      maxed = b.level >= CFG.MAX_LEVEL; cost = game.upgradeCost(b);
    } else if (s.kind === 'b' && b.type === 'pump') {
      const pn = game.pumpNet(b);
      setText('p-status', t('ps.' + pn.status)); $('#p-dot').className = 'dot ' + (pn.status === 'running' ? '' : pn.status === 'noInput' || pn.status === 'noOutput' ? 'bad' : 'warn');
      setText('p-boost', pn.boost.toFixed(1) + ' ' + t('u.bar') + ' / ' + pn.boostMax.toFixed(0));
      setText('p-pflow', pn.flow.toFixed(1) + ' / ' + num(pn.maxFlow) + ' ' + t('perMin'));
      setText('p-pdir', t('p.inout'));
      setText('p-pin', pn.pIn.toFixed(1) + ' ' + t('u.bar')); setText('p-pout', pn.pOut.toFixed(1) + ' ' + t('u.bar'));
      setText('p-power', t('p.powerV', { kw: pn.kw.toFixed(1), cost: money(pn.costMin) })); setText('p-eff', pct(pn.efficiency));
      setBtn($('#p-pt'), pn.enabled ? t('p.pumpOff') : t('p.pumpOn'), !pn.ready);
      setBtn($('#p-pf'), t('p.flipPump'), false);
      maxed = b.level >= game.maxLevel(b); cost = game.upgradeCost(b);
    } else if (s.kind === 'b') {
      const cap = game.tankCap(b), f = clamp(b.amt / cap, 0, 1);
      setText('p-amt', num(b.amt) + ' ' + t('bbl')); setText('p-cap', num(cap) + ' ' + t('bbl')); setText('p-pct', Math.round(f * 100) + '% · ' + game.tankHyd(b).backPressure.toFixed(1) + ' ' + t('u.bar'));
      setText('p-qual', b.amt > 0 ? '×' + (b.qm || 1).toFixed(2) : '—');
      const tn = game.tankNet(b);
      setText('p-in', tn.ready ? tn.inflow.toFixed(1) + ' ' + t('perMin') : t('nw.building', { n: Math.round(tn.progress * 100) }));
      
      setText('p-src', tn.linked.length ? t('nw.srcs', { a: tn.feeding.length, b: tn.linked.length }) : t('nw.nosrc'));
      const bar = $('#p-bar'); bar.style.width = f * 100 + '%'; bar.className = f > .95 ? 'full' : f > .75 ? 'warn' : '';
      maxed = b.level >= CFG.MAX_LEVEL; cost = game.upgradeCost(b);
    } else {
      const c = game.pipeNet(s.k);
      if (!c || !game.pipe[s.k]) { select(null); return; }
      const dt = Math.max(game.lastDt || 1, .001), st = game.pipeSt[s.k], nl = leaksOf(c).length;
      const ps = game.pipeStat(s.k);
      setText('p-type', t('pipe.' + (game.pipeType[s.k] ? 'main' : 'sub'))); setText('p-seg', num(c.pipes.length)); setText('p-tcap', num(c.cap) + ' ' + t('perMin'));
      { const nd = game.graphNode(s.k), sg = game.graphSegment(s.k), br = game.branchOf(s.k), rb = $('#p-rb');           // what this tile is in the network graph
        setText('p-node', nd ? (nd.kind === 'junction' ? t('nd.junction', { n: nd.edges.length }) : t('nd.end')) : sg ? t('nd.seg', { n: sg.len }) : t('nd.seg0'));
        if (rb) { setBtn(rb, br ? t('p.removeBranchN', { n: br.tiles.length }) : t('p.removeBranch'), !br); rb.hidden = !br; } }
      setText('p-flow', ps.flow.toFixed(1) + ' / ' + num(ps.cap) + ' ' + t('perMin'));
      setText('p-net', ps.issue ? t('pi.' + ps.issue) : ps.from && ps.to ? t('pi.ok', { n: tankNo(ps.to) }) : t('pi.ok2'));
      const d2 = $('#p-dot2'); if (d2) d2.className = 'dot ' + (ps.issue === 'noTank' || ps.issue === 'noWell' || ps.issue === 'leak' ? 'bad' : ps.issue ? 'warn' : '');
      setText('p-lost', ((c.ext - c.flow) / dt * 60).toFixed(1) + ' ' + t('perMin'));
      const pe = game.pipeEdge(s.k);
      setText('p-prs', pe.pressure.toFixed(1) + ' ' + t('u.bar')); setText('p-vel', pe.velocity.toFixed(2) + ' ' + t('u.ms')); setText('p-loss', pe.drop.toFixed(2) + ' ' + t('u.bar'));
      { const vs = game.valve[s.k], nx = vs === 0 ? 1 : vs === 1 ? 2 : vs === 2 ? 3 : 0; setBtn($('#p-vl'), vs ? t('p.valveNext', { a: t('v.' + vs), b: t('v.' + nx) }) : t('p.valveNext', { a: t('v.0'), b: t('v.1') }) + ' ' + money(CFG.COST.valve), false); }
      setText('p-cond', pct(game.pipeCond[s.k])); setBar('p-cond', game.pipeCond[s.k], good(game.pipeCond[s.k], .6, .3));
      setText('p-leak', t('ls.' + st) + (st === 0 && nl ? ' · ' + t('p.leaks') + ' ' + nl : ''));
      $('#p-dot').className = 'dot ' + (st === 1 ? 'bad' : st === 2 ? 'warn' : nl ? 'warn' : '');
      const target = st === 1 ? s.k : leaksOf(c)[0], rcost = target != null ? game.repairCost(target) : 0;
      setBtn($('#p-rp'), st === 2 ? t('p.repairing') : target == null ? t('p.noLeak') : t('p.repair', { cost: money(rcost) }), st === 2 || target == null || cash < rcost);
      const info = game.pipeUpgradeInfo(s.k); maxed = !info || info.maxed; cost = info ? info.cost : 0;
    }
    const mvb = $('#p-mv'); if (mvb && mvb.textContent !== t('p.move')) mvb.textContent = t('p.move');
    const up = $('#p-up');
    setBtn(up, maxed ? t('p.max') : (s.kind === 'pipe' ? t('p.upgradePipes') : t('p.upgrade')) + ' ' + money(cost), maxed || cash < cost);
    if (rm) {
      const warn = s.kind === 'b' && b.type === 'tank' && b.amt >= 50 && ui.removeArm;
      const t2 = warn ? t('p.sure', { n: num(b.amt) }) : (s.kind === 'pipe' ? t('p.removeSeg') : t('p.remove'));
      if (rm.textContent !== t2) rm.textContent = t2;
    }
  }
  panel.addEventListener('click', e => {
    const btn = e.target.closest('[data-act]'); if (!btn) return;
    const a = btn.dataset.act, s = ui.sel, b = selBuilding();
    if (a === 'close') select(null);
    else if (a === 'more') { ui.more = !ui.more; renderPanel(); }
    else if (a === 'market') openMarket();
    else if (a === 'upgrade') {
      const r = s.kind === 'b' ? game.upgrade(b) : game.upgradePipes(s.k);
      if (!r.ok) toast(help(r.reason), 'bad'); else toast(t('t.upgradedTo', { n: r.level, cost: money(r.cost) }), 'good');
      renderPanel(); refreshHud(true);
    } else if (a === 'pumpToggle') {
      const r = game.setPumpEnabled(b, !b.enabled); toast(t(r.enabled ? 't.pumpOn' : 't.pumpOff'), 'info'); updatePanel();
    } else if (a === 'pumpFlip') {
      game.flipPump(b); updatePanel();
    } else if (a === 'valve') {
      const vs = game.valve[s.k], nx = vs === 0 ? 1 : vs === 1 ? 2 : vs === 2 ? 3 : 0, r = game.setValve(s.k, nx);
      if (!r.ok) toast(help(r.reason), 'bad'); else toast(t('t.valve', { a: t('v.' + nx) }), 'info');
      updatePanel(); refreshHud(true);
    } else if (a === 'maint') {
      const r = game.maintain(b);
      if (!r.ok) toast(help(r.reason), 'bad'); else toast(t('t.maint', { cost: money(r.cost) }), 'good');
      updatePanel(); refreshHud(true);
    } else if (a === 'repair') {
      const c = game.pipeNet(s.k), k = game.pipeSt[s.k] === 1 ? s.k : leaksOf(c)[0];
      if (k == null) { toast(help('noleak'), 'bad'); return; }
      const r = game.repairPipe(k);
      if (!r.ok) toast(help(r.reason), 'bad'); else { toast(t('t.repairStart', { cost: money(r.cost) }), 'good'); ui.sel = { kind: 'pipe', k }; }
      updatePanel(); refreshHud(true);
    } else if (a === 'regions') { openRegions();
    } else if (a === 'explore') {
      const r = game.explore(s.id);
      if (!r.ok) toast(help(r.reason), 'bad'); else toast(t('t.exploreStart', { cost: money(r.cost) }), 'info');
      renderPanel(); refreshHud(true);
    } else if (a === 'abuild') {
      select(null); setTool('well');
    } else if (a === 'removeBranch') {
      if (s.kind !== 'pipe') return;
      const r = game.removeBranch(s.k % W, (s.k / W) | 0);
      if (!r.ok) { toast(help(r.reason || 'nothing'), 'bad'); return; }
      toast(t('t.removedBranch', { n: r.tiles, refund: money(r.refund) }) + (r.simplified.length ? ' · ' + t('t.simplified') : ''), 'info'); select(null); refreshHud(true);
    } else if (a === 'move') {
      if (s.kind === 'b') startMove(b.id);
    } else if (a === 'remove') {
      if (s.kind === 'b') {
        if (b.type === 'tank' && b.amt >= 50 && !ui.removeArm) { ui.removeArm = 1; updatePanel(); return; }
        const r = game.removeAt(b.x, b.y); toast(t('t.removed', { n: money(r.refund) }), 'info');
      } else { const r = game.removeAt(s.k % W, (s.k / W) | 0); toast(t('t.removed', { n: money(r.refund) }), 'info'); }
      select(null); refreshHud(true);
    }
  });

  /* ================= Confirm bar + hint ================= */
  function updateConfirm() {
    const box = $('#confirm'), p = ui.pending;
    if (!p) { if (!box.hidden) box.hidden = true; return; }
    if (box.hidden) box.hidden = false;
    let txt, ok, state = 'VALID';
    if (ui.tool === 'pipe') {
      const r = ui.route || { ok: false, reason: 'pickNode', cost: 0 };
      ok = r.ok && game.s.cash >= r.cost; state = !r.ok ? 'INVALID' : ok ? 'VALID' : 'UNAFFORDABLE';
      txt = !r.ok ? help(r.reason) : game.s.cash < r.cost ? t('noCash') : t('c.pipe', { cost: money(r.cost) });
    } else {
      const pl = verdict(ui.tool, p.x, p.y); state = pl.state;
      ok = pl.ok;
      txt = ui.moveId != null && pl.ok ? t('c.move', { what: ui.tool === 'well' ? t('n.well.' + (game.buildings.find(q => q.id === ui.moveId) || {}).kind) : t('n.tank') }) : pl.state === 'INVALID' ? help(pl.reason) : pl.state === 'UNAFFORDABLE' ? t('noCash') : t('c.' + ui.tool, { cost: money(pl.cost) }) + ' · ' + t('tr.' + CFG.TERRAIN.NAMES[game.terrainAt(p.x, p.y)]);
    }
    const okB = $('#confirm-ok'), tx = $('#confirm-text'), fl = $('#confirm-flip'), hint = $('#hint'), showFlip = ui.tool === 'pump';                      // pipes: the route is automatic, there is no corner to flip   // write the DOM only when something changed
    if (okB.disabled !== !ok) okB.disabled = !ok;
    if (box.dataset.state !== state) box.dataset.state = state;              // valid / invalid / unaffordable: the bar says it with colour too
    if (tx.textContent !== txt) tx.textContent = txt;
    if (fl.hidden === showFlip) fl.hidden = !showFlip;
    if (!hint.hidden) hint.hidden = true;
  }
  let lastConfirm = 0;
  $('#confirm-ok').addEventListener('click', () => { const n = performance.now(); if (n - lastConfirm < 350) return; lastConfirm = n; confirmPending(); });   // one press = one build, however fast the second press comes
  $('#confirm-no').addEventListener('click', () => { if (ui.moveId != null) cancelMove(); else cancelAction(); });
  $('#confirm-flip').addEventListener('click', () => { if (ui.tool === 'pump') ui.pumpFlip = !ui.pumpFlip; else ui.flip = !ui.flip; updateConfirm(); });

  function nextStep() {
    const wells = game.buildings.filter(b => b.type === 'well'), tanks = game.buildings.filter(b => b.type === 'tank');
    if (!wells.length) return t('h.n1');
    if (!tanks.length) return t('h.n2');
    if (!wells.some(w => game.isWellConnected(w))) return t('h.n3');
    if (game.oilTotal() >= 100) return t('h.n4', { n: num(game.oilTotal()) });
    return t('h.n5');
  }
  function updateHint() {
    const h = $('#hint');
    h.hidden = !!ui.pending || !panel.hidden || !!coach.step;
    const tool = ui.tool;
    let s;
    if (tool === 'well') s = t('h.well', { cost: t('k.' + ui.wellKind) + ' ' + money(CFG.WELL_KINDS[ui.wellKind].cost) });
    else if (tool === 'explore') s = t('h.explore', { cost: money(CFG.REGIONS[0].explore) + '+' });
    else if (tool === 'tank') s = t('h.tank', { cost: money(CFG.COST.tank) });
    else if (tool === 'pump') s = t('h.pump', { cost: money(CFG.COST.pump) });
    else if (tool === 'pipe') s = ui.pipeStart ? t('h.pipe2') : (ui.pipeType ? t('n.pipeMain') : t('n.pipeSub')) + ' · ' + t('h.pipe1');
    else if (tool === 'erase') s = t('h.erase');
    else s = ui.menu ? t('h.build') : nextStep();
    if (h.dataset.s !== s) { h.innerHTML = s; h.dataset.s = s; }
  }


  /* ---- Development debug mode (open the page with #debug, or press Shift+D): node pressure, losses, flow, capacity, bottleneck, pumps ---- */
  const dbg = { on: false, el: null };
  function setDebug(on) {
    dbg.on = on; try { localStorage.setItem('oli.debug', on ? '1' : '0'); } catch (e) {}
    if (on && !dbg.el) { const d = document.createElement('pre'); d.id = 'dbg'; document.body.appendChild(d); dbg.el = d; }
    if (dbg.el) dbg.el.hidden = !on;
    if (on) updateDebug();
  }
  function updateDebug() {
    if (!dbg.on || !dbg.el) return;
    const d = game.debugSnapshot(), L = ['HYDRAULICS  solves ' + d.solves + '  iter ' + d.iterations + '  ' + (d.converged ? 'converged' : 'NOT converged') + '  err ' + (d.maxError || 0).toExponential(1) + '  warn ' + d.warnings];
    L.push('NETWORK  ' + (d.problems.length ? d.problems.length + ' PROBLEM(S): ' + d.problems.slice(0, 3).join(' | ') : 'graph valid'));
    if (d.graph) L.push('GRAPH  nodes ' + d.graph.nodes + '  segments ' + d.graph.segments + '  junctions ' + d.graph.junctions + (d.graph.list.length ? ' [' + d.graph.list.slice(0, 6).map(j => j.id + ':' + j.branches).join(' ') + ']' : '') + '  ends ' + d.graph.ends + '  orphans ' + d.graph.orphans);
    for (const p of d.plans) L.push('well ' + p.well + ' -> tank ' + p.tank + '  ' + p.tiles + ' tiles  Pres ' + p.reservoir.toFixed(1) + '  need ' + (p.preq || 0).toFixed(1) + '  head ' + (p.wellHead || 0).toFixed(1) + ' bar  Qt ' + p.qt.toFixed(1) + '  Q ' + p.q.toFixed(1) + (p.lim ? '  limit:' + p.lim : '') + (p.bottleneck >= 0 ? '  bottleneck@' + (p.bottleneck % W) + ',' + ((p.bottleneck / W) | 0) : ''));
    for (const p of d.pumps) L.push('pump ' + p.id + '  head ' + (p.head || 0).toFixed(1) + ' bar  flow ' + p.flow.toFixed(1) + '  ' + p.kw.toFixed(1) + ' kW  spin ' + p.spin.toFixed(2));
    for (const t2 of game.buildings) if (t2.type === 'tank') L.push('tank ' + t2.id + '  fill ' + Math.round(t2.amt / game.tankCap(t2) * 100) + '%  back-pressure ' + game.tankHyd(t2).backPressure.toFixed(1) + ' bar');
    if (ui.hover && inb(ui.hover.x, ui.hover.y)) { const k = idx(ui.hover.x, ui.hover.y); if (game.pipe[k]) { const td = game.tileDebug(k); if (td) L.push('node ' + (td.node || '-') + ' (' + td.nodeKind + ')  branches ' + td.branches + '  edges ' + (td.edges.join(',') || '-') + '  segment ' + (td.segment || '-') + (td.segment ? ' ' + td.from + '->' + td.to + ' ' + td.segTiles + ' tiles' : '') + '  net ' + td.comp + '  links ' + td.links + '  ' + (td.live ? (td.connected ? 'connected' : 'NOT connected') : 'under construction')); const e = game.pipeEdge(k); L.push('tile ' + ui.hover.x + ',' + ui.hover.y + '  P ' + e.pressure.toFixed(2) + ' bar  loss ' + e.drop.toFixed(3) + '  Q ' + e.flow.toFixed(1) + '/' + e.capacity + '  v ' + e.velocity.toFixed(2) + ' m/s  Re ' + e.reynolds.toFixed(0) + '  f ' + e.friction.toFixed(4) + (e.valve ? '  valve ' + e.valve + ' @' + e.valvePos.toFixed(2) : '')); } }
    const txt = L.join('\n'); if (dbg.el.textContent !== txt) dbg.el.textContent = txt;
  }
  try { if (/debug/.test(location.hash) || localStorage.getItem('oli.debug') === '1') setDebug(true); } catch (e) { if (/debug/.test(location.hash)) setDebug(true); }

  /* ================= HUD ================= */
  let lastPrice = 0, priceDir = 0, lastTgt = null;
  const hud = { cash: game.s.cash, oil: game.oilTotal(), lastCash: game.s.cash, lastOil: game.oilTotal(), pend: 0, pendT: 0, oilPend: 0, oilT: 0, txt: {} };
  const flash = (el, cls) => { el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); };
  function floater(el, text, kind) {
    const host = $('#app'); if (host.querySelectorAll('.floater').length > 4) return;
    const r = el.getBoundingClientRect(), f = document.createElement('div');
    f.className = 'floater ' + kind; f.textContent = text;
    f.style.left = (r.left + r.width / 2) + 'px'; f.style.top = (r.bottom + 2) + 'px';
    const rm = () => f.remove(); f.addEventListener('animationend', rm, { once: true }); setTimeout(rm, 1800);
    host.appendChild(f);
  }
  // Per-frame HUD: numbers count smoothly toward the real values, and changes get a short flash.
  function hudFrame(real) {
    const s = game.s, oilNow = game.oilTotal();
    if (s.cash !== hud.lastCash) { hud.pend += s.cash - hud.lastCash; hud.pendT = .12; hud.lastCash = s.cash; }
    if (hud.pend !== 0 && (hud.pendT -= real) <= 0) {
      const d = hud.pend; hud.pend = 0;
      if (Math.abs(d) >= 1) { const el = $('#st-cash'); flash(el, d > 0 ? 'gain' : 'loss'); floater(el, (d > 0 ? '+' : '−') + money(Math.abs(d)), d > 0 ? 'good' : 'bad'); }
    }
    if (oilNow < hud.lastOil - 1) { hud.oilPend += hud.lastOil - oilNow; hud.oilT = .12; }
    hud.lastOil = oilNow;
    if (hud.oilPend > 0 && (hud.oilT -= real) <= 0) {
      const d = hud.oilPend; hud.oilPend = 0;
      if (d >= 2) { const el = $('#st-oil'); flash(el, 'loss'); floater(el, '−' + num(d) + ' ' + t('bbl'), 'oil'); }
    }
    const k = Math.min(1, real * 7);
    hud.cash += (s.cash - hud.cash) * k; if (Math.abs(s.cash - hud.cash) < .5) hud.cash = s.cash;
    hud.oil += (oilNow - hud.oil) * k; if (Math.abs(oilNow - hud.oil) < .05) hud.oil = oilNow;
    setText('v-cash', money(hud.cash));
    const oilEl = $('#v-oil'), ot = num(hud.oil) + ' '; if (oilEl.firstChild.textContent !== ot) oilEl.firstChild.textContent = ot;
    const so = $('#st-oil'), rising = oilNow > hud.oil + .5 || (game.net.comps.some(c => c.spd > .05) && oilNow < game.storageCap() - 1);
    if (so.classList.contains('rising') !== rising) so.classList.toggle('rising', rising);
  }
  function refreshHud(snap) {
    const s = game.s, oil = game.oilTotal(), cap = game.storageCap(), pct = cap > 0 ? oil / cap : 0;
    if (snap === 'reset') { hud.cash = hud.lastCash = s.cash; hud.oil = hud.lastOil = oil; hud.pend = hud.oilPend = 0; }
    setText('v-store', Math.round(pct * 100) + '%');
    const st = $('#st-store'); st.classList.toggle('warn', pct > .75 && pct <= .98); st.classList.toggle('full', pct > .98);
    if (s.price !== lastPrice) { priceDir = s.price > lastPrice ? 1 : -1; lastPrice = s.price; }
    const pe = $('#v-price'); const pt = money1(s.price) + ' ' + (priceDir > 0 ? '▲' : priceDir < 0 ? '▼' : '') + ' '; if (pe.firstChild.textContent !== pt) pe.firstChild.textContent = pt;
    const sp = $('#st-price'); sp.classList.toggle('up', priceDir > 0); sp.classList.toggle('down', priceDir < 0);
  }

  /* ================= Market ================= */
  const mk = $('#market');
  let futIdx = 0;
  let spInit = true;                                  // smart default: when the market opens, the sell amount starts at what is free to sell
  function openMarket() { closeModals(); mk.hidden = false; spInit = true; applyTab(); layoutMarket(); if (ui.tab === 'trade') drawChart(); }
  function closeModals() { mk.hidden = true; $('#settings').hidden = true; $('#regions').hidden = true; }
  function layoutMarket() {
    const box = $('#fu-dur');
    if (!box.children.length) {
      CFG.FUT.forEach((o, i) => { const b = document.createElement('button'); b.type = 'button'; b.dataset.i = i; b.textContent = t('m.min', { n: o.sec / 60 }); box.appendChild(b); });
    }
    updateMarket();
  }
  const fmtTime = s => { s = Math.max(0, Math.ceil(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  const ago = at => { const d = Math.max(0, game.s.time - at); return d < 8 ? t('ago.now') : d < 90 ? t('ago.s', { n: Math.floor(d) }) : t('ago.m', { n: Math.floor(d / 60) }); };
  function logText(l) {
    const v = Object.assign({}, l.v);
    if (v.what) v.what = t('n.' + v.what);
    if (v.type) v.type = t('ev.' + v.type);
    if (v.p != null) v.p = money1(v.p);
    return t(l.k, v);
  }

  let spAll = false;                                  // "Sell all" was chosen: sell exactly what is stored when the button is pressed
  const signed = (n, f) => (n >= 0 ? '+' : '−') + f(Math.abs(n));
  function updateMarket() {
    if (mk.hidden) return;
    updateEventStrip();
    if (ui.tab === 'orders') { updateOrders(); return; }
    if (ui.tab === 'comp') { updateComp(); return; }
    // everything below only READS the game state (market / economy / storage views); nothing here is a source of truth
    const s = game.s, M = game.market(), E = game.economy(), S = game.storage();
    const oil = Math.floor(S.inventory), h = s.hist, first = h[0], hi = Math.max(...h), lo = Math.min(...h);
    const chg = (s.price - first) / first * 100, tr = game.priceTrend();
    setText('mk-price', money1(M.currentOilPrice)); $('#mk-price').className = priceDir < 0 ? 'down' : '';
    setText('mk-prev', money1(M.previousOilPrice));
    const iso = s => '⁦' + s + '⁩';   // keeps signs and % next to their digits in right-to-left text
    const de = $('#mk-delta'); setText('mk-delta', iso(signed(M.priceChange, v => '$' + v.toFixed(2)))); de.className = M.priceChange > 0.004 ? 'up' : M.priceChange < -0.004 ? 'dn' : '';
    const te = $('#mk-trend'); setText('mk-trend', t(tr.dir > 0 ? 'm.up' : tr.dir < 0 ? 'm.down' : 'm.flat') + ' ' + iso((tr.pct >= 0 ? '+' : '') + tr.pct.toFixed(1) + '%'));
    te.className = 'badge ' + (tr.dir > 0 ? 'up' : tr.dir < 0 ? 'down' : 'flat');
    const ce = $('#mk-chg'); setText('mk-chg', iso((chg >= 0 ? '+' : '') + chg.toFixed(1) + '%')); ce.className = chg >= 0 ? 'up' : 'dn';
    setText('mk-hi', money1(hi)); setText('mk-lo', money1(lo));
    // economy: stored oil, cash, revenue, operating cost, profit
    setText('ec-oil', iso(num(S.inventory) + ' / ' + num(S.capacity))); setText('ec-cash', money(E.money));
    const pe = $('#ec-profit'); setText('ec-profit', iso(signed(E.profit, money))); pe.className = E.profit >= 0 ? 'up' : 'dn';
    setText('ec-q', '×' + S.quality.toFixed(2)); setText('ec-extra', money(E.maintenance + E.repairs)); setText('ec-capex', money(E.upgrades + E.exploration)); setText('ec-rev', money(E.revenue)); setText('ec-cost', money(E.operatingCosts)); setText('ec-rate', iso(t('m.perMin', { n: money1(E.opexPerMin) })));
    const ow = $('#ec-owed'); ow.hidden = E.owed < 0.5; if (!ow.hidden) setText('ec-owed', t('m.owed', { n: money(E.owed) }));
    // spot sale
    const sr = $('#sp-range'); if (+sr.max !== oil) { sr.max = oil; if (+sr.value > oil) sr.value = oil; }
    if (spAll) sr.value = oil;
    else if (spInit && oil > 0) { sr.value = Math.floor(S.free > 0 ? S.free : oil); spInit = false; }
    const sa = spAll ? S.inventory : +sr.value;
    setText('sp-amt', num(sa) + ' ' + t('bbl')); setText('sp-rev', money(sa * s.price * S.quality)); $('#sp-go').disabled = sa < 0.01;
    $$('#sp-chips button').forEach(b => { const n = b.dataset.n; b.disabled = n !== 'all' && +n > oil; b.classList.toggle('on', n === 'all' ? spAll : !spAll && +sr.value === +n); });
    const sw = $('#sp-warn'), after = S.inventory - sa, bad = S.committed > 0 && sa >= 0.01 && after < S.committed - 1e-9;
    sw.hidden = !bad; if (bad) setText('sp-warn', t('m.warnSell', { n: num(S.committed) }));
    // futures
    const avail = Math.floor(S.free), fr = $('#fu-range'); if (+fr.max !== avail) { const wasZero = +fr.max === 0 && +fr.value === 0; fr.max = avail; if (+fr.value > avail) fr.value = avail; else if (wasZero && avail > 0) fr.value = Math.round(avail / 2); }
    const fa = +fr.value, q = game.contractQuote(fa, futIdx);
    setText('fu-amt', num(fa) + ' ' + t('bbl')); setText('fu-price', money1(q.price)); setText('fu-rev', money(q.revenue));
    const fe = $('#fu-edge'); setText('fu-edge', iso(signed(q.vsSpot, v => v.toFixed(1) + '%'))); fe.className = q.vsSpot >= 0 ? 'up' : 'dn';
    setText('fu-avail', num(avail) + (S.committed > 0 ? ' (' + num(S.committed) + ' ' + t('c.active') + ')' : ''));
    $$('#fu-dur button').forEach(b => {                                     // every duration shows its locked price vs the price today
      const i = +b.dataset.i, qq = game.contractQuote(0, i), txt = t('m.min', { n: CFG.FUT[i].sec / 60 }) + ' · ' + iso(signed(qq.vsSpot, v => v.toFixed(1) + '%'));
      if (b.textContent !== txt) b.textContent = txt;
      b.classList.toggle('on', i === futIdx);
    });
    $('#fu-go').disabled = fa < 1 || s.contracts.length >= CFG.MAX_CONTRACTS;
    // wait: waiting is not free
    setText('wt-val', money(S.inventory * s.price)); setText('wt-cost', iso(t('m.perMin', { n: money1(E.opexPerMin) })));
    setText('al-val', s.alert ? money(s.alert.target) : t('m.off'));
    // contracts (active, then finished)
    const cl = $('#contracts'); let ch = '';
    for (const k of s.contracts) {
      const left = k.end - s.time, pct = clamp((s.time - k.start) / (k.end - k.start), 0, 1) * 100, short = S.inventory < k.amount - 1e-9;
      ch += '<li><div class="top"><span>' + t('m.line', { n: num(k.amount), p: money1(k.price) }) + '</span><span class="st active">' + t('c.active') + '</span></div>' +
        '<div class="top sub"><span>' + t('c.left') + ' <b dir="ltr">' + fmtTime(left) + '</b></span><span>' + t('m.exp', { rev: money(k.amount * k.price) }) + '</span></div>' +
        '<div class="bar"><i style="width:' + pct.toFixed(1) + '%"></i></div>' + (short ? '<div class="warn">' + t('c.short') + '</div>' : '') + '</li>';
    }
    if (!ch) ch = '<li class="none">' + t('m.noContracts') + '</li>';
    if (cl.dataset.h !== ch) { cl.innerHTML = ch; cl.dataset.h = ch; }
    const fl = $('#finished'); let fh = '';
    for (const k of s.done) {
      const ok = k.status === 'completed';
      fh += '<li><div class="top"><span>' + t('m.line', { n: num(k.amount), p: money1(k.price) }) + '</span><span class="st ' + (ok ? 'done' : 'bad') + '">' + t(ok ? 'c.completed' : 'c.expired') + '</span></div>' +
        '<div class="top sub"><span>' + (ok ? '+' + money(k.amount * k.price) : t('c.pen', { n: money(-k.result) })) + '</span>' + (ok ? '<span>' + t('c.vs', { d: iso(signed(k.result, money)) }) + '</span>' : '') + '</div></li>';
    }
    if (!fh) fh = '<li class="none">' + t('m.nothing') + '</li>';
    if (fl.dataset.h !== fh) { fl.innerHTML = fh; fl.dataset.h = fh; }
    // activity
    const al = $('#activity'); let ah = '';
    for (const l of s.log.slice(0, 6)) ah += '<li><span>' + logText(l) + '</span><b class="' + (l.amt > 0 ? 'up' : l.amt < 0 ? 'dn' : '') + '" dir="ltr">' + (l.amt ? (l.amt > 0 ? '+' : '−') + money(Math.abs(l.amt)) : '') + '</b><em>' + ago(l.t) + '</em></li>';
    if (!ah) ah = '<li class="none">' + t('m.nothing') + '</li>';
    if (al.dataset.h !== ah) { al.innerHTML = ah; al.dataset.h = ah; }
  }

  function drawChart() {
    const c = $('#mk-chart'); if (!c || mk.hidden) return;
    const r = c.getBoundingClientRect(); if (!r.width) return;
    c.width = Math.round(r.width * dpr); c.height = Math.round(r.height * dpr);
    const g = c.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const w = r.width, h = r.height, L = 34, B = 20, T = 8, R = 8, pw = w - L - R, ph = h - B - T;
    const d = game.s.hist, lo0 = Math.min(...d), hi0 = Math.max(...d), pad = Math.max(2, (hi0 - lo0) * .15);
    const step = Math.max(2, Math.ceil((hi0 - lo0 + 2 * pad) / 4 / 2) * 2);
    const lo = Math.floor((lo0 - pad) / step) * step, hi = Math.ceil((hi0 + pad) / step) * step;
    const X = i => L + pw * i / (d.length - 1), Y = v => T + ph * (1 - (v - lo) / (hi - lo));
    g.font = '11px Barlow, Cairo, sans-serif'; g.textBaseline = 'middle'; g.textAlign = 'right'; g.direction = 'ltr';
    g.strokeStyle = 'rgba(150,185,220,.16)'; g.lineWidth = 1; g.fillStyle = '#90a7bd';
    for (let v = lo; v <= hi + .01; v += step) { const y = Math.round(Y(v)) + .5; g.beginPath(); g.moveTo(L, y); g.lineTo(w - R, y); g.stroke(); g.fillText(String(v), L - 6, y); }
    g.textAlign = 'center'; g.textBaseline = 'alphabetic';
    for (let m = 0; m <= 4; m++) { const i = d.length - 1 - m * 20; if (i < 0) continue; g.fillText(m ? '−' + m + (prefs.lang === 'ar' ? 'د' : 'm') : t('m.nowShort'), Math.min(Math.max(X(i), 20), w - 18), h - 5); }
    const up = d[d.length - 1] >= d[0], col = up ? '#2fd27a' : '#ff5a4f';
    const gr = g.createLinearGradient(0, T, 0, T + ph); gr.addColorStop(0, up ? 'rgba(47,210,122,.32)' : 'rgba(255,90,79,.32)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.beginPath(); d.forEach((v, i) => i ? g.lineTo(X(i), Y(v)) : g.moveTo(X(i), Y(v)));
    g.lineTo(X(d.length - 1), T + ph); g.lineTo(X(0), T + ph); g.closePath(); g.fillStyle = gr; g.fill();
    g.beginPath(); d.forEach((v, i) => i ? g.lineTo(X(i), Y(v)) : g.moveTo(X(i), Y(v)));
    g.strokeStyle = col; g.lineWidth = 2; g.lineJoin = 'round'; g.stroke();
    const ex = X(d.length - 1), ey = Y(d[d.length - 1]);
    g.fillStyle = col; g.beginPath(); g.arc(ex, ey, 4, 0, 6.2832); g.fill();
    g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 1.5; g.stroke();
    const a = game.s.alert; if (a && a.target >= lo && a.target <= hi) { g.setLineDash([5, 4]); g.strokeStyle = '#ffb41f'; g.beginPath(); g.moveTo(L, Y(a.target)); g.lineTo(w - R, Y(a.target)); g.stroke(); g.setLineDash([]); }
  }

  $('#sp-range').addEventListener('input', () => { spAll = false; updateMarket(); });
  $('#fu-range').addEventListener('input', updateMarket);
  $('#sp-chips').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b || b.disabled) return;
    const r = $('#sp-range');
    if (b.dataset.n === 'all') { spAll = true; r.value = r.max; } else { spAll = false; r.value = Math.min(+b.dataset.n, +r.max); }
    updateMarket();
  });
  $('#fu-dur').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { futIdx = +b.dataset.i; updateMarket(); } });
  $('#sp-go').addEventListener('click', () => {
    const r = game.sell(spAll ? game.oilTotal() : +$('#sp-range').value);
    if (!r.ok) return toast(help(r.reason), 'bad');
    toast(t('t.sold', { n: num(r.amount), rev: money(r.revenue) }), 'good');
    for (const b of game.buildings) if (b.type === 'tank') spawnFx(b.x, b.y, 'sale');
    spAll = false; $('#sp-range').value = 0; spInit = true; updateMarket(); refreshHud(true);
  });
  $('#fu-go').addEventListener('click', () => {
    const r = game.createContract(+$('#fu-range').value, futIdx);
    if (!r.ok) return toast(help(r.reason), 'bad');
    toast(t('t.contract', { rev: money(r.quote.revenue), time: fmtTime(r.quote.sec) }), 'info');
    $('#fu-range').value = 0; updateMarket(); refreshHud(true);
  });
  const alertStep = d => {
    const s = game.s; const cur = s.alert ? s.alert.target : Math.round(s.price);
    game.setAlert(clamp(cur + d, CFG.PRICE.MIN + 1, CFG.PRICE.MAX - 1)); updateMarket(); drawChart();
  };
  $('#al-up').addEventListener('click', () => alertStep(1));
  $('#al-dn').addEventListener('click', () => alertStep(-1));
  $('#al-val').addEventListener('click', () => { game.setAlert(null); updateMarket(); drawChart(); });
  $('#wt-go').addEventListener('click', () => { closeModals(); toast(game.s.alert ? t('t.waiting', { p: money(game.s.alert.target) }) : t('t.waiting0'), 'info'); });

  /* ================= Phase 4: events, supply contracts, companies, regions ================= */
  const biso = s => '⁦' + s + '⁩';
  const evDir = ev => ev.peak > 1.001 ? 'up' : ev.peak < 0.999 ? 'down' : '';
  function showEvent(ev) {                                // a small banner (no pause, no blocking popup)
    const b = $('#evbanner'); if (!ev) return;
    b.className = evDir(ev); b.hidden = false;
    b.innerHTML = '<small>' + t('ev.title') + '</small><b>' + t('evh.' + ev.type) + '</b><span>' + t('ev.price') + ': ' + biso(money1(ev.priceFrom) + ' → ' + money1(ev.priceTo)) + '</span>';
    clearTimeout(showEvent.t); showEvent.t = setTimeout(() => { b.hidden = true; }, 7500);
  }
  $('#evbanner').addEventListener('click', () => { $('#evbanner').hidden = true; ui.tab = 'trade'; openMarket(); });

  function updateEventStrip() {
    const el = $('#mk-event'), ev = game.eventView();
    if (!ev) { if (!el.hidden) { el.hidden = true; el.dataset.h = ''; } return; }
    const h = ev.type + '|' + ev.phase + '|' + Math.ceil(ev.phase === 'active' ? ev.remaining : ev.endsIn) + '|' + prefs.lang + '|' + ev.priceTo;
    el.hidden = false; if (el.dataset.h === h) return; el.dataset.h = h;
    el.className = 'evstrip ' + evDir(ev);
    el.innerHTML = '<span><b>' + t('ev.' + ev.type) + '</b> · ' + t('evh.' + ev.type) + '</span><span>' + t('ev.price') + ' ' + biso(money1(ev.priceFrom) + ' → ' + money1(ev.priceTo)) + ' · ' + (ev.phase === 'active' ? fmtTime(ev.remaining) + ' ' + t('ev.left') : t('ev.fading')) + '</span>';
  }

  function orderCard(o, kind) {
    const s = game.s;
    const head = '<div class="top"><span>' + t('m.line', { n: num(o.requiredOil), p: money1(o.price) }) + '</span><span class="st ' + (kind === 'active' ? 'active' : kind) + '">' + t('os.' + o.status) + '</span></div>';
    const vsHtml = '<span class="vs" data-vs="' + o.price + '"></span>';
    if (o.status === 'AVAILABLE') {
      return '<div class="ocard">' + head + '<dl><dt>' + t('o.reward') + '</dt><dd>' + money(o.reward) + '</dd><dt>' + t('o.time') + '</dt><dd>' + t('o.min', { n: o.duration / 60 }) + '</dd><dt>' + t('o.price') + '</dt><dd>' + vsHtml + '</dd><dt>' + t('o.expires') + '</dt><dd dir="ltr" data-end="' + o.offerEnd + '"></dd></dl>' +
        '<div class="row"><button class="btn green" type="button" data-oact="accept" data-id="' + o.id + '">' + t('o.accept') + '</button></div></div>';
    }
    if (o.status === 'ACTIVE') {
      const p = clamp(o.deliveredOil / o.requiredOil, 0, 1) * 100, free = Math.max(0, game.oilTotal() - game.committed());
      return '<div class="ocard active">' + head + '<div class="bar"><i style="width:' + p.toFixed(1) + '%"></i></div><dl><dt>' + t('o.required') + '</dt><dd>' + num(o.requiredOil) + '</dd><dt>' + t('o.delivered') + '</dt><dd>' + num(o.deliveredOil) + '</dd><dt>' + t('o.remaining') + '</dt><dd>' + num(o.remainingOil) + '</dd><dt>' + t('o.reward') + '</dt><dd>' + money(o.reward) + '</dd><dt>' + t('o.left') + '</dt><dd dir="ltr" data-end="' + o.deadline + '"></dd><dt>' + t('o.price') + '</dt><dd>' + vsHtml + '</dd></dl>' +
        '<div class="row"><button class="btn orange" type="button" data-oact="deliver" data-id="' + o.id + '"' + (free < 1 ? ' disabled' : '') + '>' + t('o.deliver') + '</button><button class="btn ghost" type="button" data-oact="deliver100" data-id="' + o.id + '"' + (free < 100 || o.remainingOil < 1 ? ' disabled' : '') + '>' + t('o.deliver100') + '</button></div></div>';
    }
    const good = o.status === 'COMPLETED';
    return '<div class="ocard ' + (good ? 'done' : 'bad') + '">' + head + '<dl><dt>' + t('o.delivered') + '</dt><dd>' + num(o.deliveredOil) + ' / ' + num(o.requiredOil) + '</dd><dt>' + t('o.reward') + '</dt><dd>' + (good ? '+' + money(o.reward) : o.paid ? '+' + money(o.paid) : '$0') + (o.penalty ? ' · −' + money(o.penalty) : '') + '</dd></dl></div>';
  }
  function updateOrders() {
    const box = $('#od-box'), s = game.s;
    const offers = s.orders.filter(o => o.status === 'AVAILABLE'), active = s.orders.filter(o => o.status === 'ACTIVE');
    const h = '<p class="rgnote">' + t('o.risk') + '</p><div class="sec">' + t('o.active') + '</div><div class="ocards">' + (active.map(o => orderCard(o, 'active')).join('') || '<p class="rgnote">' + t('o.noActive') + '</p>') + '</div>' +
      '<div class="sec">' + t('o.offers') + '</div><div class="ocards">' + (offers.map(o => orderCard(o, 'avail')).join('') || '<p class="rgnote">' + t('o.none') + '</p>') + '</div>' +
      '<div class="sec">' + t('o.history') + '</div><div class="ocards">' + (s.ordersDone.slice(0, 4).map(o => orderCard(o, o.status === 'COMPLETED' ? 'done' : 'bad')).join('') || '<p class="rgnote">' + t('o.noHistory') + '</p>') + '</div>';
    if (box.dataset.h !== h) { box.innerHTML = h; box.dataset.h = h; }
    // live numbers are refreshed in place so the buttons are never rebuilt under a finger
    box.querySelectorAll('[data-end]').forEach(el => { const v = fmtTime(+el.dataset.end - s.time); if (el.textContent !== v) el.textContent = v; });
    box.querySelectorAll('[data-vs]').forEach(el => { const d = (+el.dataset.vs / s.price - 1) * 100, v = t('o.vsSpot', { d: biso((d >= 0 ? '+' : '−') + Math.abs(d).toFixed(1) + '%') }); if (el.textContent !== v) el.textContent = v; el.className = 'vs ' + (d >= 0 ? 'up' : 'dn'); });
  }
  $('#od-box').addEventListener('click', e => {
    const b = e.target.closest('[data-oact]'); if (!b) return;
    const id = +b.dataset.id, a = b.dataset.oact;
    if (a === 'accept') { const r = game.acceptOrder(id); toast(r.ok ? t('t.accepted') : err(r.reason), r.ok ? 'good' : 'bad'); }
    else {
      const r = game.deliverOrder(id, a === 'deliver100' ? 100 : null);
      if (!r.ok) toast(help(r.reason), 'bad'); else toast(r.completed ? t('t.orderDone', { rev: money(r.reward) }) : t('t.delivered2', { n: num(r.amount) }), 'good');
    }
    $('#od-box').dataset.h = ''; updateOrders(); refreshHud(true);
  });

  function updateComp() {
    const box = $('#cp-box'), rows = game.ranking(), eff = game.s.aiMult;
    let h = '<table class="ctable"><thead><tr><th>' + t('c.rank') + '</th><th>' + t('c.company') + '</th><th>' + t('c.share') + '</th><th>' + t('c.prod') + '</th><th>' + t('c.rev') + '</th></tr></thead><tbody>';
    for (const r of rows) {
      const name = r.player ? t('c.me') : t('co.' + r.id) + ' <small class="muted">' + t('sg.' + r.strategy) + '</small>';
      h += '<tr class="' + (r.player ? 'me' : '') + '"><td>' + r.rank + '</td><td>' + name + '</td><td>' + Math.round(r.share * 100) + '%<span class="shbar"><i style="width:' + (r.share * 100).toFixed(1) + '%"></i></span></td><td>' + (r.production).toFixed(1) + '</td><td>' + money(r.revenue) + '</td></tr>';
    }
    h += '</tbody></table><p class="rgnote">' + t('c.metric') + '</p><p class="rgnote">' + t('c.effect') + ': <b dir="ltr">×' + eff.toFixed(3) + '</b></p>';
    if (box.dataset.h !== h) { box.innerHTML = h; box.dataset.h = h; }
  }
  function applyTab() {
    $$('#mtabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === ui.tab));
    $$('[data-pane]').forEach(p => { p.hidden = p.dataset.pane !== ui.tab; });
  }
  $('#mtabs').addEventListener('click', e => { const b = e.target.closest('[data-tab]'); if (!b) return; ui.tab = b.dataset.tab; applyTab(); updateMarket(); if (ui.tab === 'trade') drawChart(); });

  // ----- regions -----
  const rg = $('#regions');
  function openRegions() { closeModals(); rg.hidden = false; $('#rg-list').dataset.h = ''; updateRegions(); }
  function regionCenter(id) { let sx = 0, sy = 0, n = 0; for (const a of game.areas) if (a.region === id && a.land) { sx += a.ax * 4 + 2; sy += a.ay * 4 + 2; n++; } return n ? [sx / n, sy / n] : [CFG.WORLD.OX + 22, CFG.WORLD.OY + 14]; }
  function updateRegions() {
    if (rg.hidden) return;
    let h = '';
    for (let id = 1; id <= CFG.REGIONS.length; id++) {
      const r = game.regionInfo(id), risk = r.riskLevel <= 1.1 ? 'low' : r.riskLevel <= 1.3 ? 'mid' : 'high', cash = game.s.cash;
      h += '<li class="rg ' + r.state + '"><div class="top"><span>' + t('r.' + id) + '</span><span class="st">' + t('rs.' + r.state) + '</span></div><dl>' +
        '<dt>' + t('r.terrain') + '</dt><dd>' + t('tr.' + r.terrain) + '</dd><dt>' + t('r.build') + '</dt><dd dir="ltr">×' + r.constructionMult.toFixed(2) + '</dd>' +
        '<dt>' + t('r.explore') + '</dt><dd>' + money(r.explorationCost) + '</dd><dt>' + t('r.risk') + '</dt><dd>' + t('risk.' + risk) + ' <span dir="ltr">×' + r.riskLevel.toFixed(2) + '</span></dd>' +
        '<dt>' + t('r.potential') + '</dt><dd>' + Math.round(r.oilChance * 100) + '% · ' + r.reservePotential + t('perMinShort') + '</dd><dt>' + t('r.progress') + '</dt><dd>' + r.explored + ' / ' + r.areas + '</dd>' +
        (r.state === 'LOCKED' ? '' : '<dt>' + t('r.wells') + '</dt><dd>' + r.wells + '</dd>') + '</dl>';
      if (r.state === 'LOCKED') h += '<div class="row"><button class="btn orange" type="button" data-ract="unlock" data-id="' + id + '"' + (cash < r.unlockNeed ? ' disabled' : '') + '>' + t('r.unlock', { cost: money(r.unlockCost) }) + '</button></div>' + (cash < r.unlockNeed ? '<div class="need">' + t('r.need', { need: money(r.unlockNeed) }) + '</div>' : '');
      else h += '<div class="row"><button class="btn ghost" type="button" data-ract="go" data-id="' + id + '">' + t('r.go') + '</button></div>';
      h += '</li>';
    }
    const box = $('#rg-list'); if (box.dataset.h !== h) { box.innerHTML = h; box.dataset.h = h; }
  }
  $('#rg-list').addEventListener('click', e => {
    const b = e.target.closest('[data-ract]'); if (!b) return;
    const id = +b.dataset.id;
    if (b.dataset.ract === 'unlock') { const r = game.unlockRegion(id); if (!r.ok) toast(r.reason === 'needCash' ? err('needCash') : err(r.reason), 'bad'); refreshHud(true); updateRegions(); }
    else { const [x, y] = regionCenter(id); cam.x = (x - y) * 32; cam.y = (x + y) * 16; clampCam(); closeModals(); setTool('explore'); }
  });
  const afford = k => k === 'well' ? CFG.WELL_KINDS.small.cost : k === 'explore' ? CFG.REGIONS[0].explore : CFG.COST[k];
  function updateMenuAfford() {                                   // build menu: a tool you cannot pay for is dimmed (DOM touched only when the state flips)
    for (const el of $$('#buildmenu .tool[data-tool]')) {
      const c = afford(el.dataset.tool); if (c == null) continue;
      const poor = game.s.cash < c; if (el.classList.contains('poor') !== poor) { el.classList.toggle('poor', poor); el.title = poor ? t('noCash') : ''; }
    }
  }
  function updateBadges() {
    updateMenuAfford();
    const has = game.s.orders.some(o => o.status === 'AVAILABLE') || !!game.s.event;
    const m = $('#btn-market'); if (m.classList.contains('alerting') !== has) m.classList.toggle('alerting', has);
  }

  $('#mk-close').addEventListener('click', closeModals);
  mk.addEventListener('pointerdown', e => { if (e.target === mk) closeModals(); });
  $('#btn-market').addEventListener('click', openMarket);
  $('#btn-regions').addEventListener('click', openRegions);
  $('#rg-close').addEventListener('click', closeModals);
  $('#st-price').addEventListener('click', openMarket);

  /* ================= Menu ================= */
  const stm = $('#settings');
  const SPEEDS = [1, 2, 0];
  function syncSpeed() { const b = $('#btn-speed'); b.firstElementChild.textContent = ui.speed === 0 ? '❚❚' : ui.speed + '×'; b.classList.toggle('paused', ui.speed === 0); b.classList.toggle('fast', ui.speed === 2); }
  $('#btn-speed').addEventListener('click', () => { ui.speed = SPEEDS[(SPEEDS.indexOf(ui.speed) + 1) % 3]; syncSettings(); toast(ui.speed === 0 ? t('s.paused') : t('s.speedTo', { n: ui.speed }), 'info'); });
  function syncSettings() {
    syncSpeed();
    $$('#speed button').forEach(b => b.classList.toggle('on', +b.dataset.s === ui.speed));
    $$('#langs button').forEach(b => b.classList.toggle('on', b.dataset.l === prefs.lang));
    $$('#confirmopt button').forEach(b => b.classList.toggle('on', (+b.dataset.c === 1) === !!prefs.confirm));
  }
  $('#btn-settings').addEventListener('click', () => { closeModals(); stm.hidden = false; syncSettings(); });
  $('#st-close').addEventListener('click', closeModals);
  stm.addEventListener('pointerdown', e => { if (e.target === stm) closeModals(); });
  $('#speed').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { ui.speed = +b.dataset.s; syncSettings(); } });
  $('#confirmopt').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { prefs.confirm = +b.dataset.c === 1; savePrefs(); syncSettings(); } });
  function setLang(l) {
    prefs.lang = l; savePrefs(); applyI18n();
    $('#fu-dur').innerHTML = ''; if (!mk.hidden) layoutMarket();
    $('#contracts').dataset.h = ''; $('#activity').dataset.h = '';
    renderPanel(); $('#hint').dataset.s = ''; updateHint(); updateConfirm(); syncSettings(); refreshHud(true);
    const r = $('#st-reset'); r.textContent = t('s.reset');
  }
  $('#langs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) setLang(b.dataset.l); });
  $('#st-save').addEventListener('click', () => { save(); toast(t('t.saved'), 'good'); });
  $('#st-reset').addEventListener('click', e => {
    if (!ui.reset) { ui.reset = 1; e.target.textContent = t('s.sure'); setTimeout(() => { ui.reset = 0; e.target.textContent = t('s.reset'); }, 3000); return; }
    try { localStorage.removeItem(SAVE_KEY); } catch (err2) { /* ignore */ }
    game.reset(); ui.sel = null; renderPanel(); setTool('select'); initCamera(); closeModals(); refreshHud('reset'); toast(t('t.new'), 'info');
  });
  const menuT = new Map();                                        // one physical press = one menu action: a repeat on the SAME button within 250 ms is a duplicate; a different button is never blocked
  const menuOk = el => { const n = performance.now(); if (n - (menuT.get(el) || -1e9) < 250) return false; menuT.set(el, n); return true; };
  $('#btn-build').addEventListener('click', e => { if (menuOk(e.currentTarget)) toggleBuild(); });
  $$('.tool[data-tool]').forEach(b => b.addEventListener('click', () => {
    if (!menuOk(b)) return;
    const k = b.dataset.tool, pt = k === 'pipe' ? (b.dataset.pipeType === 'main' ? 1 : 0) : ui.pipeType;
    if (k === ui.tool && k !== 'select' && pt === ui.pipeType) return;               // choosing the tool you are already in changes nothing (the preview is kept)
    if (k === 'pipe' && pt !== ui.pipeType) { ui.pipeType = pt; if (ui.tool === 'pipe') { if (ui.pipeA && ui.pipeB) ui.route = game.routeNodes(ui.pipeA, ui.pipeB, pt); updateConfirm(); updateHint(); applyMenu(); return; } }
    ui.pipeType = pt; setTool(k);
  }));
  $$('#kinds button').forEach(b => b.addEventListener('click', () => { ui.wellKind = b.dataset.k; ui.pending = null; applyMenu(); updateConfirm(); updateHint(); }));

  /* ================= Main loop ================= */
  function initCamera() {
    cam.x = (OXY.OX - OXY.OY) * 32; cam.y = 16 * (OXY.OLD_COLS + OXY.OLD_ROWS) / 2 - 30 + (OXY.OX + OXY.OY) * 16;     // the middle of the original map
    cam.z = clamp(vw / 1150, CAM.START_Z[0], CAM.START_Z[1]);
    clampCam();
  }

  let last = performance.now(), uiClock = 0, saveClock = 0, lastTick = -1, ema = 16.7, emaClock = 0;
  let frameErr = 0, coachWas = false;
  function frame(now) {
    try { tick(now); } catch (e) { if (frameErr++ < 3) console.error(e); }   // one bad frame must never stop the game loop
    requestAnimationFrame(frame);
  }
  function tick(now) {
    const raw = (now - last) / 1000, real = Math.min(.25, raw); last = now;
    tNow = now / 1000;
    const ad = ui.speed > 0 ? real * Math.min(ui.speed, 2) : 0;   // animation clock: frozen when paused, capped when fast-forwarding
    if (raw < .2) { ema += (raw * 1000 - ema) * .05; emaClock += raw; if (emaClock > 3) { emaClock = 0; if (ema > 30 && dprCap > 1) { dprCap = Math.max(1, dprCap - .5); resize(); clampCam(); } } }
    if (ui.speed > 0) {
      let left = real * ui.speed;      // sub-step so big speed-ups stay accurate
      while (left > 0) { const d = Math.min(left, 1); game.step(d); left -= d; }
    }
    for (const ev of game.drainEvents()) {
      if (ev.type === 'alert') { toast(t('t.alert', { p: money1(ev.price) }), 'info'); const sp = $('#st-price'); sp.classList.remove('alert'); void sp.offsetWidth; sp.classList.add('alert'); }
      if (ev.type === 'marketEvent') { if (ev.phase === 'start') showEvent(ev.event); else toast(t('ev.over'), 'info'); }
      if (ev.type === 'order' && ev.status === 'AVAILABLE') { const o = game.s.orders.find(q => q.id === ev.id); if (o) toast(t('t.offer', { n: num(o.requiredOil), p: money1(o.price) }), 'info'); }
      if (ev.type === 'order' && ev.status === 'FAILED') toast(t('t.orderFailed'), 'bad');
      if (ev.type === 'region') toast(t('r.opened', { cost: money(CFG.REGIONS[ev.id - 1].unlock) }), 'good');
      if (ev.type === 'leak') { toast(t('t.leak'), 'bad'); spawnFx(ev.k % W, (ev.k / W) | 0, 'pipe'); }
      if (ev.type === 'repaired') { toast(t('t.repaired'), 'good'); spawnFx(ev.k % W, (ev.k / W) | 0, 'repair'); }
      if (ev.type === 'explored') { const ea = game.areas.find(q => q.id === ev.id); if (ea) spawnFx(ea.ax * 4 + 2, ea.ay * 4 + 2, ev.kind === 'empty' ? 'dust' : 'discover'); }
      if (ev.type === 'explored') toast(t('t.explored', { what: ev.kind === 'empty' ? t('a.k.empty') : t('a.k.' + ev.kind) + ' · ' + t('q.' + ev.quality) }), ev.kind === 'empty' ? 'info' : 'good');
      if (ev.type === 'upgrade') {                                            // short, cheap feedback: a pop on the object and a ring
        if (ev.kind === 'pipe') spawnFx(ev.k % W, (ev.k / W) | 0, 'pipe');
        else { const ub = game.buildings.find(q => q.id === ev.id); if (ub) { anim.born.set('b' + ub.id, tNow - .22); spawnFx(ub.x, ub.y, ub.type); } }
      }
      if (ev.type === 'contract') toast(ev.status === 'expired' ? t('t.expired', { pen: money(ev.penalty) }) : t('t.delivered', { rev: money(ev.revenue) }), ev.status === 'expired' ? 'bad' : 'good');
    }
    if (keys.size) {
      camGoal.on = false;
      const sp = 700 * real / cam.z;
      if (keys.has('arrowleft') || keys.has('a')) cam.x -= sp;
      if (keys.has('arrowright') || keys.has('d')) cam.x += sp;
      if (keys.has('arrowup') || keys.has('w')) cam.y -= sp;
      if (keys.has('arrowdown') || keys.has('s')) cam.y += sp;
      clampCam();
    }
    stepCamera(real); stepPlacing(real); updateAnim(real, ad); hudFrame(real);
    uiClock += real; saveClock += real;
    if (uiClock > .2) {
      uiClock = 0; refreshHud(); updatePanel(); updateMarket(); updateRegions(); updateBadges(); updateCoach(); updateHint();
      if (coachWas && game.s.tutorialDone) { toast(t('co.done'), 'good'); save(); }
      coachWas = !game.s.tutorialDone;
      const tick = Math.floor(game.s.time / CFG.PRICE_TICK);
      if (!mk.hidden && tick !== lastTick) { lastTick = tick; drawChart(); }
      if (ui.pending) updateConfirm();
      drawMini(); updateDebug();
    }
    if (saveClock > 5) { saveClock = 0; save(); }
    render();
  }

  /* ================= Boot ================= */
  addEventListener('resize', () => { resize(); clampCam(); });
  if (window.ResizeObserver) { let rw = 0, rh = 0; new ResizeObserver(() => { const r = cv.getBoundingClientRect(); if (Math.abs(r.width - rw) < .5 && Math.abs(r.height - rh) < .5) return; rw = r.width; rh = r.height; if (Math.abs(r.width - vw) > .5 || Math.abs(r.height - vh) > .5) { resize(); clampCam(); } }).observe(cv); }   // WebView layout changes that fire no window resize
  addEventListener('beforeunload', save);
  document.addEventListener('visibilitychange', () => { if (document.hidden) { resetGestures(); save(); } else last = performance.now(); });
  buildTerrain();
  applyArt(); applyI18n(); syncSettings();
  resize();
  if (!loaded) initCamera(); else clampCam();
  setTool('select');
  if (!game.buildings.length) { ui.menu = true; applyMenu(); updateHint(); }   // first run: show the build menu
  refreshHud('reset');
  drawMini();
  toast(loaded ? t('t.back') : t('t.welcome'), 'info');
  requestAnimationFrame(frame);

  // small hook for debugging and automated tests
  window.__oli = { select, renderPanel, updatePanel, game, ui, cam, prefs, anim, hud, onTap, setTool, cellAt, openMarket, openRegions, closeModals, setLang, t, coach, camGoal, getSpots, focusOn, backStep, leaveBuild, gridToWorld, worldToGrid, footprintCenter, cc, pickBuilding, pumpDirFor, help, updateMenuAfford, gOff, pd, inputMode, resetGestures, ptrs, clampCam, s2w, w2s, fitView, focusSel, CAM, BOX, zoomLimits, drawMini, camGoal, stepCamera, pill: () => pill, setDebug, updateDebug };
})();
