# Oli — Main & Branch Pipe Update

## What changed
- Added two construction choices: **Branch Pipe (أنبوب فرعي)** and **Main Pipeline (أنبوب رئيسي)**.
- Building remains **drag-from-icon only**; tapping an icon alone never builds.
- Main pipeline has 2x base capacity and 1.32x hydraulic diameter at the same level.
- Main pipeline costs 2x the branch-pipe base cost per tile.
- Rendering distinguishes main lines with a heavier visual treatment and identification collar.
- Pipe selection panel now reports whether the selected pipe is Main or Branch.
- Pipe type is stored per tile and survives save/load.
- Hydraulic edge capacity/diameter use the actual pipe type.
- Mixed networks are governed by their real per-tile bottleneck capacity.
- Existing saves remain compatible: old pipes load as Branch pipes.

## Tests
- `node test-pipe-types.js` — PASS
- Existing full core regression suite — PASS
- `node -c core.js` — PASS
- `node -c game.js` — PASS
- `node -c www/core.js` — PASS
- `node -c www/game.js` — PASS
- `npm test` — PASS
- `npm run build:web` equivalent (`node build-www.js`) — PASS

## Notes
The update intentionally keeps the existing level system. Pipe Level still controls upgrade progression; Main/Branch controls the base class, capacity, diameter, cost, and visual weight.
