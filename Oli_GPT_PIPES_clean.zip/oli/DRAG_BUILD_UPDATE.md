# Oli — Drag-to-Build Update

## COMPLETED
- Build icons for Well, Tank, Pump, and Pipe now require a real drag gesture from the icon to the map.
- A simple tap/click on a build icon no longer selects the construction tool or starts construction.
- Well/Tank/Pump construction occurs only after dragging the icon onto a valid map cell and releasing there.
- Invalid drop locations do not build and show the existing placement reason.
- Building previews still snap to the grid before placement.
- Pipe icon drag establishes the pipe start only when the dragged icon is released on a valid anchor; the pipe route is then completed by dragging on the map.
- Added Arabic and English guidance for the new drag-only interaction.
- Updated the Web build and Android bundled Web assets.

## PARTIALLY COMPLETED
- This change enforces the interaction in the game code, but a real finger test on a physical Android device was not possible in this environment.

## NOT COMPLETED
- No APK was generated.
- No visual redesign of the construction icons was made; this update is behavioral.

## TESTS RUN
- JavaScript syntax check: PASS.
- Full existing npm test suite: PASS.
- Web build: PASS.

## RESULT
The construction interaction is now drag-from-icon only. Tapping an icon by itself cannot start building.
